import os
import glob
import re
import sys
import signal
import traceback
from collections import Counter

sys.path.insert(0, ".")

from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items, extract_condition_names
from cobol_transpile import transpile_procedure_division, UnsupportedCobolConstruct

FILES = sorted(glob.glob(os.environ.get("NIST_COBOL85_DIR", "./nist_cobol85") + "/*.CBL"))[:75]


class PerFileTimeout(Exception):
    pass


def _handler(signum, frame):
    raise PerFileTimeout()


signal.signal(signal.SIGALRM, _handler)

extract_ok = 0
extract_fail = Counter()
transpile_ok = 0
transpile_unsupported = Counter()
transpile_crash = Counter()
transpile_ok_names = []
timeouts = 0

for i, path in enumerate(FILES):
    name = path.split("/")[-1]
    if i % 25 == 0:
        print(f"... {i}/{len(FILES)}", flush=True)
    src = open(path, errors="replace").read()

    signal.alarm(1)  # max. 1s per file -- a hanging parser must not block the batch
    try:
        try:
            items = extract_data_items(src)
            extract_ok += 1
        except PerFileTimeout:
            timeouts += 1
            continue
        except Exception as e:
            extract_fail[f"{type(e).__name__}: {str(e)[:80]}"] += 1
            continue

        try:
            params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
            program = CobolParserRunner().analyze(src, params)
            field_scales = {it["name"]: (it["field"].decimal_digits if hasattr(it["field"], "decimal_digits") else 0)
                             for it in items if it["field"]}
            known_cobol_names = {it["name"] for it in items}
            from engine import PicX
            field_lengths = {it["name"]: it["field"].length for it in items if isinstance(it["field"], PicX)}
            condition_name_map = extract_condition_names(src)
            transpile_procedure_division(program, "dummy_fn", ["dummy"], "dummy", field_scales,
                                          known_cobol_names=known_cobol_names, field_lengths=field_lengths,
                                          condition_name_map=condition_name_map)
            transpile_ok += 1
            transpile_ok_names.append(name)
        except PerFileTimeout:
            timeouts += 1
        except UnsupportedCobolConstruct as e:
            msg = str(e)
            if "Unsupported statement" in msg:
                m = re.search(r"Statement: (\w+)", msg)
                reason = f"Statement: {m.group(1)}" if m else "Statement: ?"
            elif "paragraphs found" in msg:
                reason = "No paragraphs/sections found"
            else:
                reason = msg[:60]
            transpile_unsupported[reason] += 1
        except Exception as e:
            transpile_crash[f"{type(e).__name__}: {str(e)[:100]}"] += 1
    finally:
        signal.alarm(0)

print("=" * 78)
print(f"Total: {len(FILES)} files, timeouts (>5s/file): {timeouts}")
print(f"DATA DIVISION extraction succeeded: {extract_ok} ({extract_ok*100//len(FILES)}%)")
print(f"DATA DIVISION extraction failed: {sum(extract_fail.values())}")
for reason, count in extract_fail.most_common(10):
    print(f"   {count:4d}x  {reason}")
print()
print(f"PROCEDURE DIVISION transpilation SUCCEEDED (complete!): {transpile_ok}")
for n in transpile_ok_names[:30]:
    print(f"   -> {n}")
print()
print(f"PROCEDURE DIVISION -- expected unsupported (clean rejection): {sum(transpile_unsupported.values())}")
for reason, count in transpile_unsupported.most_common(15):
    print(f"   {count:4d}x  {reason}")
print()
print(f"PROCEDURE DIVISION -- UNEXPECTED crash (needs investigation!): {sum(transpile_crash.values())}")
for reason, count in transpile_crash.most_common(15):
    print(f"   {count:4d}x  {reason}")
