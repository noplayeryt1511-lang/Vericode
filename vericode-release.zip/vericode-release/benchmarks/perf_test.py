"""
Performance characterization: how does Z3 proof time scale with growing
program size? Synthetic COBOL (EVALUATE with many WHEN branches).
IMPORTANT: modern_fn is built as an ACTUAL source-text string (with the
number embedded literally), NOT as a Python closure -- our engine reads
loop bounds from the actual source text (inspect.getsource); a closure
variable would only be a name there, not a literal, and would be
incorrectly rejected as "not bounded".
"""
import linecache
import sys
import time
sys.path.insert(0, ".")

import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify


def build_cobol(n_branches):
    lines = [
        "       IDENTIFICATION DIVISION.",
        "       PROGRAM-ID. PERFTEST.",
        "       DATA DIVISION.",
        "       WORKING-STORAGE SECTION.",
        "       01  WS-INC     PIC 9(9).",
        "       01  WS-RESULT  PIC 9(9).",
        "       PROCEDURE DIVISION.",
        "       P.",
        "           EVALUATE TRUE",
    ]
    for i in range(n_branches):
        threshold = (i + 1) * 1000
        lines.append(f"               WHEN WS-INC <= {threshold}")
        lines.append(f"                   COMPUTE WS-RESULT = WS-INC * {i + 1}")
    lines.append("               WHEN OTHER")
    lines.append(f"                   COMPUTE WS-RESULT = WS-INC * {n_branches}")
    lines.append("           END-EVALUATE.")
    lines.append("           STOP RUN.")
    return "\n".join(lines)


def build_modern_source(n_branches):
    lines = ["def perf_test(ws_inc):"]
    for i in range(n_branches):
        threshold = (i + 1) * 1000
        kw = "if" if i == 0 else "elif"
        lines.append(f"    {kw} ws_inc <= {threshold}:")
        lines.append(f"        return ws_inc * {i + 1}")
    lines.append("    else:")
    lines.append(f"        return ws_inc * {n_branches}")
    return "\n".join(lines) + "\n"


def load_modern(n_branches):
    src = build_modern_source(n_branches)
    filename = f"<perftest_modern_{n_branches}>"
    linecache.cache[filename] = (len(src), None, src.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(src, filename, "exec"), ns)
    return ns["perf_test"]


results = []
for n in [5, 10, 20, 40, 80, 160, 320, 640]:
    cobol_src = build_cobol(n)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        cobol_src, "perf_test", ["ws_inc"], "ws_result")
    modern_fn = load_modern(n)
    modern_fn.field_types = dict(legacy_fn.field_types)

    start = time.time()
    res = verify(legacy_fn, modern_fn, arg_type=z3.IntSort())
    elapsed = time.time() - start
    results.append((n, elapsed, res.label.value))
    print(f"n={n:4d} Verzweigungen: {elapsed:8.3f}s -> {res.label.value}", flush=True)

print()
print("Zusammenfassung:")
for n, elapsed, label in results:
    print(f"  {n:4d} Verzweigungen: {elapsed:8.3f}s ({label})")
