import os
import glob
import re
import signal
import sys
import time
from collections import Counter

sys.path.insert(0, ".")

from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items, extract_condition_names
from cobol_transpile import transpile_procedure_division, UnsupportedCobolConstruct
from engine import PicX

FILES = sorted(glob.glob(os.environ.get("NIST_COBOL85_DIR", "./nist_cobol85") + "/*.CBL"))
LOG_PATH = "./nist_full_run.log"
PER_FILE_TIMEOUT = 6


class PerFileTimeout(Exception):
    pass


def _handler(signum, frame):
    raise PerFileTimeout()


signal.signal(signal.SIGALRM, _handler)

extract_ok = 0
extract_fail = Counter()
transpile_ok = 0
transpile_unsupported = Counter()
transpile_crash = Counter()
transpile_ok_names = []
timeouts = 0
start_time = time.time()

with open(LOG_PATH, "w") as log:
    log.write(f"Full NIST run started: {len(FILES)} files, {PER_FILE_TIMEOUT}s/file\n")
    log.flush()

    for i, path in enumerate(FILES):
        name = path.split("/")[-1]
        src = open(path, errors="replace").read()

        signal.alarm(PER_FILE_TIMEOUT)
        try:
            try:
                items = extract_data_items(src)
                extract_ok += 1
            except PerFileTimeout:
                timeouts += 1
                log.write(f"{i+1}/{len(FILES)} {name}: TIMEOUT (extract)\n")
                continue
            except Exception as e:
                extract_fail[f"{type(e).__name__}: {str(e)[:80]}"] += 1
                log.write(f"{i+1}/{len(FILES)} {name}: extract=ERROR {type(e).__name__}\n")
                continue

            try:
                params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
                program = CobolParserRunner().analyze(src, params)
                field_scales = {it["name"]: (it["field"].decimal_digits if hasattr(it["field"], "decimal_digits") else 0)
                                 for it in items if it["field"]}
                known_cobol_names = {it["name"] for it in items}
                field_lengths = {it["name"]: it["field"].length for it in items if isinstance(it["field"], PicX)}
                condition_name_map = extract_condition_names(src)
                transpile_procedure_division(program, "dummy_fn", ["dummy"], "dummy", field_scales,
                                              known_cobol_names=known_cobol_names, field_lengths=field_lengths,
                                              condition_name_map=condition_name_map)
                transpile_ok += 1
                transpile_ok_names.append(name)
                log.write(f"{i+1}/{len(FILES)} {name}: extract=OK transpile=COMPLETE\n")
            except PerFileTimeout:
                timeouts += 1
                log.write(f"{i+1}/{len(FILES)} {name}: extract=OK transpile=TIMEOUT\n")
            except UnsupportedCobolConstruct as e:
                msg = str(e)
                if "Unsupported statement" in msg:
                    m = re.search(r"Statement: (\w+)", msg)
                    reason = f"Statement: {m.group(1)}" if m else "Statement: ?"
                elif "paragraphs found" in msg:
                    reason = "No paragraphs/sections found"
                else:
                    reason = msg[:60]
                transpile_unsupported[reason] += 1
                log.write(f"{i+1}/{len(FILES)} {name}: extract=OK transpile=REJECTED ({reason})\n")
            except Exception as e:
                transpile_crash[f"{type(e).__name__}: {str(e)[:100]}"] += 1
                log.write(f"{i+1}/{len(FILES)} {name}: extract=OK transpile=CRASH {type(e).__name__}: {str(e)[:80]}\n")
        finally:
            signal.alarm(0)

        if (i + 1) % 20 == 0:
            elapsed = time.time() - start_time
            log.write(f"--- Progress after {i+1}/{len(FILES)}, {elapsed:.0f}s: "
                       f"extract_ok={extract_ok} transpile_ok={transpile_ok} timeouts={timeouts} ---\n")
            log.flush()

    elapsed = time.time() - start_time
    log.write(f"\n=== DONE: {len(FILES)} files in {elapsed:.0f}s ===\n")
    log.write(f"Extraction succeeded: {extract_ok}/{len(FILES)} ({100*extract_ok/len(FILES):.0f}%)\n")
    log.write(f"Extraction failed: {sum(extract_fail.values())}\n")
    for reason, count in extract_fail.most_common(10):
        log.write(f"   {count:4d}x  {reason}\n")
    log.write(f"\nComplete transpilation: {transpile_ok}/{len(FILES)} ({100*transpile_ok/len(FILES):.0f}%)\n")
    log.write(f"Rejected (expected): {sum(transpile_unsupported.values())}\n")
    for reason, count in transpile_unsupported.most_common(15):
        log.write(f"   {count:4d}x  {reason}\n")
    log.write(f"\nUnexpected crashes: {sum(transpile_crash.values())}\n")
    for reason, count in transpile_crash.most_common(10):
        log.write(f"   {count:4d}x  {reason}\n")
    log.write(f"\nTimeouts: {timeouts}\n")
    log.flush()

print(f"Done, see {LOG_PATH}")
