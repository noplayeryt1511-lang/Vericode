import time
import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items
from cobol_transpile import transpile_procedure_division
from engine import verify, PicX


def char_at(s, i):
    return s[i:i + 1]


SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-TEXT    PIC X(3).
       PROCEDURE DIVISION.
       P.
           INSPECT WS-TEXT REPLACING ALL "A" BY "B".
           STOP RUN.
"""


def modern_correct(ws_text):
    r = ("B" if char_at(ws_text, 0) == "A" else char_at(ws_text, 0))
    r = r + ("B" if char_at(ws_text, 1) == "A" else char_at(ws_text, 1))
    r = r + ("B" if char_at(ws_text, 2) == "A" else char_at(ws_text, 2))
    return r


if __name__ == "__main__":
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(SRC, params)
    items = extract_data_items(SRC)
    field_types = {it["name"]: it["field"] for it in items if it["field"]}
    field_lengths = {k: v.length for k, v in field_types.items() if isinstance(v, PicX)}
    source = transpile_procedure_division(program, "repl3", ["ws_text"], "ws_text", {}, field_lengths=field_lengths)
    filename = "<repl3>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(source, filename, "exec"), ns)
    legacy_fn = ns["repl3"]
    legacy_fn.field_types = {"ws_text": field_types["ws_text"], "return": field_types["ws_text"]}
    modern_correct.field_types = dict(legacy_fn.field_types)

    t0 = time.time()
    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print("3 characters:", res.label.value, f"{time.time()-t0:.1f}s")
