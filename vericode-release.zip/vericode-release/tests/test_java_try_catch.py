import linecache
import z3
from java_bridge import transpile_java_method, UnsupportedJavaConstruct
from engine import verify, PicField

JAVA_TRY_CATCH_SOURCE = """
public class X {
    public static int safeDivide(int a, int b) {
        int result;
        try {
            result = a / b;
        } catch (ArithmeticException e) {
            result = 0;
        }
        return result;
    }
}
"""

JAVA_TRY_CATCH_BUGGY = """
public class X {
    public static int safeDivide(int a, int b) {
        int result;
        try {
            result = a / b;
        } catch (ArithmeticException e) {
            result = 1;
        }
        return result;
    }
}
"""


def legacy_safe_divide(a, b):
    if b == 0:
        result = 0
    else:
        result = a // b
    return result


def _load(src):
    py = transpile_java_method(src, "safeDivide", param_names=["a", "b"])
    filename = f"<java:safeDivide:{id(src)}>"
    linecache.cache[filename] = (len(py), None, py.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py, filename, "exec"), ns)
    return ns["safeDivide"]


def test_try_catch_division_by_zero():
    print("=" * 78)
    print("TEST: Java try/catch -- division with a zero guard (ArithmeticException)")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    legacy_safe_divide.field_types = {"return": field}

    correct_fn = _load(JAVA_TRY_CATCH_SOURCE)
    correct_fn.field_types = {"return": field}
    py_source = transpile_java_method(JAVA_TRY_CATCH_SOURCE, "safeDivide", param_names=["a", "b"])
    print(py_source)

    res = verify(legacy_safe_divide, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = _load(JAVA_TRY_CATCH_BUGGY)
    buggy_fn.field_types = {"return": field}
    res = verify(legacy_safe_divide, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (fallback value 1 instead of 0): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> try/catch with a zero guard works end-to-end.")


def test_try_catch_rejects_complex_cases():
    print("=" * 78)
    print("TEST: more complex try/catch cases are cleanly rejected, not guessed at")
    print("=" * 78)
    multi_stmt = """
    public class X {
        public static int f(int a, int b) {
            int result;
            try {
                int temp = a;
                result = temp / b;
            } catch (ArithmeticException e) {
                result = 0;
            }
            return result;
        }
    }
    """
    try:
        transpile_java_method(multi_stmt, "f", param_names=["a", "b"])
        raise AssertionError("Should have raised UnsupportedJavaConstruct!")
    except UnsupportedJavaConstruct as e:
        print(f"Correctly rejected (multiple statements in try block): {e}")
    print()


if __name__ == "__main__":
    test_try_catch_division_by_zero()
    test_try_catch_rejects_complex_cases()
    print("Both tests passed.")
