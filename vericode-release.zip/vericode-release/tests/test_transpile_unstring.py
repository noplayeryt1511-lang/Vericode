import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items
from cobol_transpile import transpile_procedure_division
from engine import verify


def unstring_before(source, delim):
    idx = source.find(delim)
    return source if idx == -1 else source[:idx]


def build_legacy_fn(cobol_source, function_name, param_names, return_field_py):
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(cobol_source, params)
    items = extract_data_items(cobol_source)
    field_types = {it["name"]: it["field"] for it in items if it["field"]}
    field_scales = {k: 0 for k in field_types}
    source = transpile_procedure_division(
        program, function_name, param_names,
        return_field_py=return_field_py, field_decimal_scales=field_scales,
    )
    print(source)
    namespace = {}
    filename = f"<{function_name}>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    exec(compile(source, filename, "exec"), namespace)
    fn = namespace[function_name]
    fn.field_types = {p: field_types[p] for p in param_names if p in field_types}
    fn.field_types["return"] = field_types[return_field_py]
    return fn, field_types


UNSTRING_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SPLIT.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-FULL    PIC X(21).
       01  WS-FIRST   PIC X(10).
       01  WS-LAST    PIC X(10).
       PROCEDURE DIVISION.
       P.
           UNSTRING WS-FULL DELIMITED BY " "
               INTO WS-FIRST WS-LAST.
           STOP RUN.
"""


def test_unstring():
    print("=" * 78)
    print("TEST: UNSTRING (splitting on a space)")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(UNSTRING_SOURCE, "split_test", ["ws_full"], "ws_first")

    def modern_correct(ws_full):
        ws_first = unstring_before(ws_full, " ")
        return ws_first
    modern_correct.field_types = dict(legacy_fn.field_types)

    def modern_buggy(ws_full):
        # Bug: wrong delimiter ("-" instead of " ")
        ws_first = unstring_before(ws_full, "-")
        return ws_first
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"  Counterexample: {{k: v.as_string()}} ->", {k: v.as_string() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> UNSTRING works end-to-end\n")


if __name__ == "__main__":
    test_unstring()
    print("UNSTRING test passed.")
