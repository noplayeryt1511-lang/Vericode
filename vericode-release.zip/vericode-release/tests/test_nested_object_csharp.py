import linecache
import z3
from csharp_bridge import transpile_csharp_method
from engine import verify, PicField

CSHARP_NESTED_SOURCE = """
public class Address {
    public int Zip;
}
public class Person {
    public int Age;
    public Address Addr;
}
public class X {
    public static int GetZip(Person p) {
        return p.Addr.Zip;
    }
}
"""

CSHARP_NESTED_BUGGY = """
public class Address {
    public int Zip;
}
public class Person {
    public int Age;
    public Address Addr;
}
public class X {
    public static int GetZip(Person p) {
        return p.Age;
    }
}
"""

_FIELD_RENAME = {"Addr": "addr", "Zip": "zip", "Age": "age"}


def _load(src, field_types, record_types):
    py = transpile_csharp_method(src, "GetZip", param_names=["person"], field_rename=_FIELD_RENAME)
    fn_name = f"<csharp:GetZip:{id(src)}>"
    linecache.cache[fn_name] = (len(py), None, py.splitlines(keepends=True), fn_name)
    ns = {}
    exec(compile(py, fn_name, "exec"), ns)
    fn = ns["GetZip"]
    fn.field_types = dict(field_types)
    fn.record_types = dict(record_types)
    return fn


def test_nested_record():
    print("=" * 78)
    print("TEST: nested object in C# (Person contains Address)")
    print("=" * 78)
    zip_field = PicField(total_digits=5, decimal_digits=0)
    age_field = PicField(total_digits=3, decimal_digits=0)
    person_spec = {"age": age_field, "addr": {"zip": zip_field}}

    def legacy_get_zip(person):
        return person.addr.zip
    legacy_get_zip.field_types = {"return": zip_field}
    legacy_get_zip.record_types = {"person": person_spec}

    print(transpile_csharp_method(CSHARP_NESTED_SOURCE, "GetZip", param_names=["person"], field_rename=_FIELD_RENAME))

    correct_fn = _load(CSHARP_NESTED_SOURCE, {"return": zip_field}, {"person": person_spec})
    res = verify(legacy_get_zip, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = _load(CSHARP_NESTED_BUGGY, {"return": zip_field}, {"person": person_spec})
    res = verify(legacy_get_zip, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (reads .Age instead of .Addr.Zip): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> nested object in C# works end-to-end -- parity with Java\n")


if __name__ == "__main__":
    test_nested_record()
    print("Nested object (C#) test passed.")
