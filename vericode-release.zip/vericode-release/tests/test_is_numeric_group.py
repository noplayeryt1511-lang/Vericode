import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. IOCHECK.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  IO-STATUS.
           05 IO-STAT1  PIC X.
           05 IO-STAT2  PIC X.
       01  WS-RESULT    PIC 9(1).
       PROCEDURE DIVISION.
       P.
           IF IO-STATUS IS NOT NUMERIC
               MOVE 1 TO WS-RESULT
           ELSE
               MOVE 0 TO WS-RESULT
           END-IF.
           STOP RUN.
"""


def is_numeric_string(s):
    return s.isdigit()


def modern_correct(io_status):
    if (not (is_numeric_string(io_status.io_stat1) and is_numeric_string(io_status.io_stat2))):
        r = 1
    else:
        r = 0
    return r


def modern_buggy_only_first_field(io_status):
    # Bug: only checks the first subfield, ignores the second -- a
    # realistic mistake when a translator doesn't fully understand the
    # group structure.
    if not is_numeric_string(io_status.io_stat1):
        r = 1
    else:
        r = 0
    return r


def run():
    print("=" * 78)
    print("TEST: IS NUMERIC on a pure PicX group field (a coverage gap that was fixed)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "io_check", ["io_status"], "ws_result")
    print(source)

    from engine import PicX
    record_spec = {"io_status": {"io_stat1": PicX(1), "io_stat2": PicX(1)}}
    legacy_fn.record_types = dict(record_spec)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_correct.record_types = dict(record_spec)
    modern_buggy_only_first_field.field_types = dict(legacy_fn.field_types)
    modern_buggy_only_first_field.record_types = dict(record_spec)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT (both subfields checked): {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_only_first_field, arg_type=z3.IntSort())
    print(f"vs. BUGGY (only first subfield checked): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> IS NUMERIC now correctly handles group fields -- the gap found in "
          "the sixth external validation is closed.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
