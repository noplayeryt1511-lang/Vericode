"""
Confirmation (not a new finding): SUBTRACT shares the same code path
(_add_or_subtract) as ADD -- the scaling fix there covers both. It had
never been verified separately; this confirms it directly instead of
just assuming it.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-SMALL   PIC 9(2)V9(1).
       01  WS-BIG     PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           SUBTRACT WS-SMALL FROM WS-BIG.
           STOP RUN.
"""


def modern_correct(ws_small, ws_big):
    return ws_big - (ws_small * 10)


def modern_buggy_no_scale_correction(ws_small, ws_big):
    return ws_big - ws_small


def run():
    print("=" * 78)
    print("TEST: SUBTRACT correctly shares the same scaling fix as ADD")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_small", "ws_big"], "ws_big")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_no_scale_correction.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_no_scale_correction, arg_type=z3.IntSort())
    print(f"vs. BUGGY (SUBTRACT without scale correction): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> SUBTRACT confirmed correct, no separate gap.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
