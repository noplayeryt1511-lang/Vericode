"""
Sixth step toward a "hybrid mode" for file I/O (after OPEN/CLOSE,
READ INTO, WRITE, REWRITE): DELETE is unconditionally safe as a no-op --
'DELETE <file>' removes a record, but does NOT set any WORKING-STORAGE
field.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE
                  ORGANIZATION IS INDEXED
                  RECORD KEY IS FD-KEY.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC.
           05 FD-KEY    PIC X(5).
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(3).
       01  WS-RESULT  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT = WS-A * 2.
           DELETE MYFILE.
           STOP RUN.
"""


def modern_correct(ws_a):
    return ws_a * 2


def run():
    print("=" * 78)
    print("TEST: DELETE as an unconditionally safe no-op")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_a"], "ws_result")
    print(source)
    modern_correct.field_types = dict(legacy_fn.field_types)
    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"Result: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("\n-> DELETE no longer blocks the surrounding calculation logic.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
