# -*- coding: utf-8 -*-
"""
Signed COMP-3 test case (PIC S9(...)):

  1. Demonstrates the sign-nibble bug: naive truncation (plain modulo, as
     it worked before the fix in engine.py) flips the sign for negative
     values. VeriCode is applied to its OWN old vs. new field semantics
     to prove the difference -- the same method it is meant to use later
     for real COBOL migrations.
  2. A practical scenario: a credit/reversal with a signed field, overflow
     for negative values, and automatic bounds derivation including the
     negative range.
"""

import z3
from engine import verify, PicField, Label


# --- 1. The sign-nibble bug, with VeriCode checked against itself ----------

class NaivePicField(PicField):
    """Deliberately the OLD, buggy implementation from before the fix:
    plain modulo, ignoring the sign for signed fields."""
    def truncate(self, scaled_int_expr):
        return scaled_int_expr % self.modulus


SIGNED_NAIVE = NaivePicField(total_digits=5, decimal_digits=2, signed=True)
SIGNED_CORRECT = PicField(total_digits=5, decimal_digits=2, signed=True)
QTY_SIGNED = PicField(total_digits=4, decimal_digits=0, signed=True)
PRICE_UNSIGNED = PicField(total_digits=5, decimal_digits=2, signed=False)


def calc_naive(quantity, unit_price_scaled):
    balance = quantity * unit_price_scaled
    return balance


calc_naive.field_types = {
    "quantity": QTY_SIGNED,
    "unit_price_scaled": PRICE_UNSIGNED,
    "balance": SIGNED_NAIVE,
    "return": SIGNED_NAIVE,
}


def calc_correct(quantity, unit_price_scaled):
    balance = quantity * unit_price_scaled
    return balance


calc_correct.field_types = {
    "quantity": QTY_SIGNED,
    "unit_price_scaled": PRICE_UNSIGNED,
    "balance": SIGNED_CORRECT,
    "return": SIGNED_CORRECT,
}


def run_bug_demo():
    print("=" * 78)
    print("1. VeriCode checks itself: naive (old) vs. correct (new) signed truncation")
    print("-" * 78)
    res = verify(calc_naive, calc_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        q = res.counterexample["quantity"].as_long()
        p = res.counterexample["unit_price_scaled"].as_long()
        raw = q * p
        modulus = SIGNED_CORRECT.modulus
        naive = raw % modulus  # Python's % is Euclidean like Z3's, same behavior
        mag = abs(raw)
        correct = (1 if raw >= 0 else -1) * (mag % modulus)
        print(f"  Counterexample: quantity={q}, unit_price={p/100:.2f}")
        print(f"    raw (untruncated) = {raw} (= {raw/100:.2f})")
        print(f"    naive truncation (bug, sign flips) = {naive} (= {naive/100:.2f})")
        print(f"    correct truncation (sign preserved) = {correct} (= {correct/100:.2f})")
    print()


# --- 2. Practical scenario: credit/reversal with a signed field -------------

def legacy_credit_note(quantity, unit_price_scaled):
    # COBOL: BALANCE is PIC S9(5)V99 COMP-3 -- quantity can be negative
    # (reversal/credit), overflow truncates while preserving the sign
    balance = quantity * unit_price_scaled
    return balance


legacy_credit_note.field_types = {
    "quantity": QTY_SIGNED,
    "unit_price_scaled": PRICE_UNSIGNED,
    "balance": SIGNED_CORRECT,
    "return": SIGNED_CORRECT,
}


def modern_credit_note_correct(quantity, unit_price_scaled):
    balance = quantity * unit_price_scaled
    return balance


modern_credit_note_correct.field_types = dict(legacy_credit_note.field_types)


def modern_credit_note_buggy(quantity, unit_price_scaled):
    # Bug: the developer assumed "unsigned" during translation (amounts are
    # usually positive) -> forgot to set signed=False correctly
    balance = quantity * unit_price_scaled
    return balance


modern_credit_note_buggy.field_types = {
    "quantity": QTY_SIGNED,
    "unit_price_scaled": PRICE_UNSIGNED,
    "balance": PicField(total_digits=5, decimal_digits=2, signed=False),  # bug is here
    "return": PicField(total_digits=5, decimal_digits=2, signed=False),
}


def run_credit_note_scenario():
    print("=" * 78)
    print("2a. Credit/reversal: LEGACY (signed) vs. MODERN, bug 'signed forgotten'")
    print("-" * 78)
    res = verify(legacy_credit_note, modern_credit_note_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        q = res.counterexample["quantity"].as_long()
        p = res.counterexample["unit_price_scaled"].as_long()
        print(f"  Counterexample: quantity={q} (negative = credit), unit_price={p/100:.2f}")
    print()

    print("=" * 78)
    print("2b. Credit/reversal: LEGACY vs. MODERN correct (signed preserved)")
    print("-" * 78)
    res = verify(legacy_credit_note, modern_credit_note_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}  <- bounds now include the negative range, derived automatically")
    print()


if __name__ == "__main__":
    run_bug_demo()
    run_credit_note_scenario()
