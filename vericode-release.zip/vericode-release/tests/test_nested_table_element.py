import z3
from engine import verify, PicField, TableField

QUANTITY_FIELD = PicField(total_digits=4, decimal_digits=0)
PRICE_FIELD = PicField(total_digits=7, decimal_digits=2)
CUSTOMER_ID_FIELD = PicField(total_digits=6, decimal_digits=0)
TOTAL_FIELD = PicField(total_digits=9, decimal_digits=2)

# Table element with a NESTED group:
#   05 LINE-ITEM OCCURS 5 TIMES.
#      10 QUANTITY PIC 9(4).
#      10 PRICE PIC 9(5)V99.
#      10 CUSTOMER-INFO.
#         15 CUSTOMER-ID PIC 9(6).
LINE_ITEM_SPEC = {
    "quantity": QUANTITY_FIELD,
    "price": PRICE_FIELD,
    "customer_info": {"customer_id": CUSTOMER_ID_FIELD},
}
LINE_ITEMS_TABLE = TableField(element=LINE_ITEM_SPEC, occurs=5)


def legacy_vip_total(line_items):
    # Sum only line items belonging to VIP customers (ID < 1000)
    total = 0
    for i in range(5):
        if line_items[i].customer_info.customer_id < 1000:
            total = total + line_items[i].quantity * line_items[i].price
    return total


legacy_vip_total.table_types = {"line_items": LINE_ITEMS_TABLE}
legacy_vip_total.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}


def modern_vip_total_buggy(line_items):
    # Bug: boundary at <= 1000 instead of < 1000 (off-by-one)
    total = 0
    for i in range(5):
        if line_items[i].customer_info.customer_id <= 1000:
            total = total + line_items[i].quantity * line_items[i].price
    return total


modern_vip_total_buggy.table_types = {"line_items": LINE_ITEMS_TABLE}
modern_vip_total_buggy.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}


def modern_vip_total_correct(line_items):
    total = 0
    for i in range(5):
        if line_items[i].customer_info.customer_id < 1000:
            total = total + line_items[i].quantity * line_items[i].price
    return total


modern_vip_total_correct.table_types = {"line_items": LINE_ITEMS_TABLE}
modern_vip_total_correct.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}


# --- Second test: targeted WRITE into a nested table field --

def legacy_reassign_customer(line_items):
    line_items[0].customer_info.customer_id = 42
    return line_items[0].customer_info.customer_id


legacy_reassign_customer.table_types = {"line_items": LINE_ITEMS_TABLE}
legacy_reassign_customer.field_types = {"return": CUSTOMER_ID_FIELD}


def modern_reassign_customer_buggy(line_items):
    line_items[0].customer_info.customer_id = 24  # Bug: digits transposed
    return line_items[0].customer_info.customer_id


modern_reassign_customer_buggy.table_types = {"line_items": LINE_ITEMS_TABLE}
modern_reassign_customer_buggy.field_types = {"return": CUSTOMER_ID_FIELD}


def modern_reassign_customer_correct(line_items):
    line_items[0].customer_info.customer_id = 42
    return line_items[0].customer_info.customer_id


modern_reassign_customer_correct.table_types = {"line_items": LINE_ITEMS_TABLE}
modern_reassign_customer_correct.field_types = {"return": CUSTOMER_ID_FIELD}


def run():
    print("=" * 78)
    print("N1. Table with a nested element: reading (customer_info.customer_id)")
    print("-" * 78)
    res = verify(legacy_vip_total, modern_vip_total_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"

    res = verify(legacy_vip_total, modern_vip_total_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("  -> reading from a nested table element works\n")

    print("=" * 78)
    print("N2. Table with a nested element: writing (customer_info.customer_id = ...)")
    print("-" * 78)
    res = verify(legacy_reassign_customer, modern_reassign_customer_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"

    res = verify(legacy_reassign_customer, modern_reassign_customer_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("  -> writing to a nested table element works\n")


if __name__ == "__main__":
    run()
    print("Both nested table element tests passed.")
