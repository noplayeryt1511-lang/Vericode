import time
import z3
from engine import PicField
from patch_loop import run_patch_loop

INVOICE_FIELD = PicField(total_digits=5, decimal_digits=2)


def legacy_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total


legacy_invoice_total.field_types = {"return": INVOICE_FIELD}

BROKEN_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled):
    total = 1
    return total
'''

INFINITE_LOOP_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled):
    while True:
        pass
    return 1
'''

MEMORY_BOMB_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled):
    huge = []
    while True:
        huge.append(bytearray(10 * 1024 * 1024))  # 10 MB per iteration
    return 1
'''

SYNTAX_ERROR_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled)
    return quantity * unit_price_scaled
'''


def test_infinite_loop():
    print("=" * 78)
    print("S1. LLM produces an infinite loop")
    print("-" * 78)
    t0 = time.time()

    def mock_infinite(prompt, attempt):
        return INFINITE_LOOP_SOURCE

    result = run_patch_loop(
        legacy_fn=legacy_invoice_total, initial_modern_source=INFINITE_LOOP_SOURCE,
        function_name="modern_invoice_total", llm_fix_fn=mock_infinite,
        arg_type=z3.IntSort(), field_types={"return": INVOICE_FIELD},
        max_attempts=2, sandbox_timeout_seconds=3,
    )
    dt = time.time() - t0
    print(f"  success={result.success}, runtime={dt:.1f}s (should be ~3s, NOT forever)")
    print(f"  history[0]: {result.history[0]}")
    assert dt < 10, f"Sandbox timeout did not trigger -- runtime {dt:.1f}s"
    assert result.success is False
    assert "SANDBOX ERROR" in result.history[0][1]
    print("  -> infinite loop successfully killed by the timeout, main process still alive.")
    print()


def test_memory_bomb():
    print("=" * 78)
    print("S2. LLM produces a memory bomb")
    print("-" * 78)
    t0 = time.time()

    def mock_bomb(prompt, attempt):
        return MEMORY_BOMB_SOURCE

    result = run_patch_loop(
        legacy_fn=legacy_invoice_total, initial_modern_source=MEMORY_BOMB_SOURCE,
        function_name="modern_invoice_total", llm_fix_fn=mock_bomb,
        arg_type=z3.IntSort(), field_types={"return": INVOICE_FIELD},
        max_attempts=2, sandbox_timeout_seconds=5,
    )
    dt = time.time() - t0
    print(f"  success={result.success}, runtime={dt:.1f}s")
    print(f"  history[0]: {result.history[0]}")
    assert result.success is False
    assert "SANDBOX ERROR" in result.history[0][1]
    print("  -> memory bomb caught (memory limit or timeout), main process still alive.")
    print()


def test_syntax_error():
    print("=" * 78)
    print("S3. LLM produces syntactically broken code")
    print("-" * 78)

    def mock_syntax_error(prompt, attempt):
        return SYNTAX_ERROR_SOURCE

    result = run_patch_loop(
        legacy_fn=legacy_invoice_total, initial_modern_source=SYNTAX_ERROR_SOURCE,
        function_name="modern_invoice_total", llm_fix_fn=mock_syntax_error,
        arg_type=z3.IntSort(), field_types={"return": INVOICE_FIELD},
        max_attempts=2,
    )
    print(f"  success={result.success}")
    print(f"  history[0]: {result.history[0]}")
    assert result.success is False
    assert "SANDBOX ERROR" in result.history[0][1]
    print("  -> syntax error cleanly reported as an error instead of crashing.")
    print()


def test_main_process_still_alive():
    print("=" * 78)
    print("S4. After all that: does the main process keep running normally?")
    print("-" * 78)

    def mock_correct(prompt, attempt):
        return BROKEN_SOURCE  # still logically wrong (returns 1 instead of the correct value), but syntactically clean -> demonstrates normal operation

    result = run_patch_loop(
        legacy_fn=legacy_invoice_total, initial_modern_source=BROKEN_SOURCE,
        function_name="modern_invoice_total", llm_fix_fn=mock_correct,
        arg_type=z3.IntSort(), field_types={"return": INVOICE_FIELD},
        max_attempts=2,
    )
    print(f"  success={result.success} (expected False, but clean and fast, no hang)")
    assert result.success is False
    print("  -> main process unaffected, normal operation continues to work.")


if __name__ == "__main__":
    test_infinite_loop()
    test_memory_bomb()
    test_syntax_error()
    test_main_process_still_alive()
    print()
    print("All sandbox stress tests passed.")
