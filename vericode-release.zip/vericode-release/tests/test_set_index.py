import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  IN3   PIC 9(3).
       01  IDN2  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           SET IN3 TO IDN2.
           SET IN3 UP BY 2.
           STOP RUN.
"""


def modern_correct(idn2):
    in3 = idn2
    in3 = in3 + 2
    return in3


def modern_buggy_down_instead_of_up(idn2):
    # Bug: DOWN instead of UP -- a realistic mistake when manipulating an index.
    in3 = idn2
    in3 = in3 - 2
    return in3


def run():
    print("=" * 78)
    print("TEST: SET index/counter assignment (TO/UP BY) -- a real NIST-suite finding (IC107A.CBL)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["idn2"], "in3")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_down_instead_of_up.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_down_instead_of_up, arg_type=z3.IntSort())
    print(f"vs. BUGGY (DOWN instead of UP): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> SET TO / SET UP BY works end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
