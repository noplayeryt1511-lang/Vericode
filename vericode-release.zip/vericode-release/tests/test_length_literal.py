import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-N        PIC 9(3).
       01  WS-RESULT   PIC 9(1).
       PROCEDURE DIVISION.
       P.
           IF FUNCTION LENGTH ("ABC") = WS-N
               MOVE 1 TO WS-RESULT
           ELSE
               MOVE 0 TO WS-RESULT
           END-IF.
           STOP RUN.
"""


def modern_correct(ws_n):
    if 3 == ws_n:
        r = 1
    else:
        r = 0
    return r


def modern_buggy_wrong_length(ws_n):
    # Bug: incorrect hardcoded length (4 instead of 3).
    if 4 == ws_n:
        r = 1
    else:
        r = 0
    return r


def run():
    print("=" * 78)
    print("TEST: FUNCTION LENGTH on a string literal -- a real NIST-suite finding (IF402M.CBL)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_n"], "ws_result")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_wrong_length.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_wrong_length, arg_type=z3.IntSort())
    print(f"vs. BUGGY (length 4 instead of 3): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> FUNCTION LENGTH on string literals works end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
