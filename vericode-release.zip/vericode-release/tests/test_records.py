# -*- coding: utf-8 -*-
"""
Record/group field test: models a COBOL group field

  01 ACCOUNT-RECORD.
     05 BALANCE       PIC S9(7)V99 COMP-3.   (signed, can go negative)
     05 FEE            PIC 9(5)V99 COMP-3.
     05 STATUS-CODE    PIC 9(2).

as a Python parameter with dot notation (account.balance, account.fee, ...).
"""

import z3
from engine import verify, PicField


BALANCE_FIELD = PicField(total_digits=7, decimal_digits=2, signed=True)  # balance can go negative
FEE_FIELD = PicField(total_digits=5, decimal_digits=2)
STATUS_FIELD = PicField(total_digits=2, decimal_digits=0)

ACCOUNT_RECORD = {
    "balance": BALANCE_FIELD,
    "fee": FEE_FIELD,
    "status_code": STATUS_FIELD,
}


def legacy_apply_monthly_fee(account):
    # COBOL: SUBTRACT FEE FROM BALANCE, result is written back into the BALANCE field
    new_balance = account.balance - account.fee
    return new_balance


legacy_apply_monthly_fee.record_types = {"account": ACCOUNT_RECORD}
legacy_apply_monthly_fee.field_types = {"return": BALANCE_FIELD}


def modern_apply_monthly_fee_buggy(account):
    # Bug: the fields were translated to i64 during the migration to Rust/Go
    # (field width forgotten) -> no more overflow truncation on the return value
    new_balance = account.balance - account.fee
    return new_balance


modern_apply_monthly_fee_buggy.record_types = {"account": ACCOUNT_RECORD}
# deliberately NO field_types["return"] -> no truncation on the return value -> bug


def modern_apply_monthly_fee_correct(account):
    new_balance = account.balance - account.fee
    return new_balance


modern_apply_monthly_fee_correct.record_types = {"account": ACCOUNT_RECORD}
modern_apply_monthly_fee_correct.field_types = {"return": BALANCE_FIELD}


def run():
    print("=" * 78)
    print("R1. Record field: LEGACY vs. MODERN, return-value truncation forgotten during translation")
    print("-" * 78)
    res = verify(legacy_apply_monthly_fee, modern_apply_monthly_fee_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        bal = res.counterexample["account.balance"].as_long()
        fee = res.counterexample["account.fee"].as_long()
        print(f"  Counterexample: account.balance={bal/100:.2f}, account.fee={fee/100:.2f}")
        raw = bal - fee
        modulus = BALANCE_FIELD.modulus
        mag = abs(raw)
        legacy_val = (1 if raw >= 0 else -1) * (mag % modulus)
        print(f"    legacy (with truncation) = {legacy_val/100:.2f}")
        print(f"    modern (without truncation) = {raw/100:.2f}")
    print()

    print("=" * 78)
    print("R2. Record field: LEGACY vs. MODERN correct (truncation replicated)")
    print("-" * 78)
    res = verify(legacy_apply_monthly_fee, modern_apply_monthly_fee_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()

    print("=" * 78)
    print("R3. Sanity check: account.fee has a different field width in legacy vs. modern")
    print("-" * 78)
    modern_apply_monthly_fee_correct.record_types = {
        "account": {**ACCOUNT_RECORD, "fee": PicField(total_digits=6, decimal_digits=2)}
    }
    res = verify(legacy_apply_monthly_fee, modern_apply_monthly_fee_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    modern_apply_monthly_fee_correct.record_types = {"account": ACCOUNT_RECORD}  # reset
    print()


if __name__ == "__main__":
    run()
