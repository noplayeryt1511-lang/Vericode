# -*- coding: utf-8 -*-
"""
Three test scenarios meant to demonstrate exactly the three label classes
from the VeriCode v2 concept:

  1. interest_v1  -> correctly migrated           -> expected: PROVEN
  2. interest_v2  -> subtle rounding bug           -> expected: FLAGGED (Z3 counterexample)
  3. batch_sum    -> bounded loop, correct         -> expected: PROVEN
  4. anomaly_case -> unprovable while loop         -> expected: VERIFIED-BY-TESTING (fuzzing)
"""

import z3
from engine import verify, Label


# ---------------------------------------------------------------------------
# Scenario 1: interest calculation -- correctly migrated
# ---------------------------------------------------------------------------
def legacy_interest(principal, rate):
    # "COBOL": COMPUTE INTEREST = principal * rate / 100, ROUNDED
    interest = round(principal * rate / 100, 2)
    return interest


def modern_interest_correct(principal, rate):
    interest = round(principal * rate / 100, 2)
    return interest


# ---------------------------------------------------------------------------
# Scenario 2: interest calculation -- LLM introduces a subtle rounding bug
#   (rounding happens at a different point in the formula -> edge cases break)
# ---------------------------------------------------------------------------
def modern_interest_buggy(principal, rate):
    # Bug: rounds the rate first instead of the final result -> deviates for certain values
    rounded_rate = round(rate, 2)
    interest = principal * rounded_rate / 100
    return interest


# ---------------------------------------------------------------------------
# Scenario 3: bounded-loop batch summation -- correctly migrated
# ---------------------------------------------------------------------------
def legacy_batch_sum(x):
    total = 0
    for i in range(5):
        total = total + x
    return total


def modern_batch_sum_correct(x):
    total = x * 5
    return total


# ---------------------------------------------------------------------------
# Scenario 4: error-handling path with an unprovable construct
#   (represents a "side effect via an external system" / while loop
#    -> in a real system: Flagged for Manual Review OR Differential Testing,
#    here we show the fuzzing fallback)
# ---------------------------------------------------------------------------
def legacy_anomaly_handler(code):
    result = 0
    n = code
    while n > 0:          # <- unbounded, not symbolically provable
        result = result + n
        n = n - 1
    return result


def modern_anomaly_handler_correct(code):
    n = max(code, 0)
    result = n * (n + 1) // 2
    return result


def modern_anomaly_handler_buggy(code):
    n = max(code, 0)
    result = (n * (n + 1) // 2) + (1 if n > 5000 else 0)  # Bug only shows up for large values
    return result


SCENARIOS = [
    ("1. Interest calculation (correctly migrated)",
     legacy_interest, modern_interest_correct, z3.RealSort(), None),

    ("2. Interest calculation (LLM rounding bug)",
     legacy_interest, modern_interest_buggy, z3.RealSort(), None),

    ("3. Batch summation, bounded loop (correct)",
     legacy_batch_sum, modern_batch_sum_correct, z3.RealSort(), None),

    ("4a. Anomaly handler, unbounded loop (correct) -> fuzzing fallback",
     legacy_anomaly_handler, modern_anomaly_handler_correct, z3.IntSort(),
     lambda: (__import__("random").randint(0, 200),)),

    ("4b. Anomaly handler, unbounded loop (bug only for large n) -> fuzzing only finds it with enough coverage",
     legacy_anomaly_handler, modern_anomaly_handler_buggy, z3.IntSort(),
     lambda: (__import__("random").randint(0, 10_000),)),
]


def run_all():
    for name, legacy, modern, arg_type, sampler in SCENARIOS:
        print("=" * 78)
        print(name)
        print("-" * 78)
        res = verify(legacy, modern, arg_type=arg_type,
                      fuzz_samples=50_000, sampler=sampler)
        print(f"  LABEL:   {res.label.value}")
        print(f"  Detail:  {res.detail}")
        if res.counterexample:
            print(f"  Counterexample: {res.counterexample}")
            # Verify the counterexample by actually running it
            try:
                args = list(res.counterexample.values())
                args = [float(str(a)) if hasattr(a, "as_decimal") else a for a in args]
            except Exception:
                pass
        if res.coverage:
            print(f"  Coverage: {res.coverage} test cases")
        print()


if __name__ == "__main__":
    run_all()
