import time
import z3
from engine import verify
from test_concolic import legacy_cumsum, modern_cumsum_buggy
from test_fuzzing_limit import legacy_payoff_periods, modern_payoff_periods_buggy


def test_shallow_case_still_works_and_is_fast():
    """Bug independent of the loop (a special-case branch after a check,
    not inside the loop itself) -- should still be found quickly."""
    print("1. Shallow case (trigger independent of loop length)")
    t0 = time.time()
    res = verify(legacy_cumsum, modern_cumsum_buggy, arg_type=z3.IntSort(),
                  fuzz_samples=300, input_bounds={"code": (0, 20000)})
    dt = time.time() - t0
    print(f"   LABEL={res.label.value}, runtime={dt:.2f}s")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    assert dt < 5, f"should be fast, was {dt:.2f}s"
    print("   -> confirmed: fast AND correct\n")


def test_deep_behind_loop_case_still_fails_honestly():
    """Bug that only occurs after a full pass through a data-dependent-length
    loop (trigger value far from zero) -- should STILL not be found
    (honestly reported as VERIFIED-BY-TESTING, not incorrectly reported
    as PROVEN/missed as a success). This is the empirical evidence that
    the sliding-window improvement does NOT solve this problem --
    genuine loop summarization remains necessary."""
    print("2. Deep case (trigger hidden behind a data-dependent loop length)")
    t0 = time.time()
    res = verify(
        legacy_payoff_periods, modern_payoff_periods_buggy,
        arg_type=z3.IntSort(), fuzz_samples=2000,
        input_bounds={"balance_scaled": (0, 50_000)},
    )
    dt = time.time() - t0
    print(f"   LABEL={res.label.value}, runtime={dt:.2f}s")
    assert res.label.value == "VERIFIED-BY-TESTING", (
        "If this now shows FLAGGED: great, but then this test AND the "
        "documentation in concolic.py must be updated -- not simply "
        "removing the assertion."
    )
    assert dt < 40, f"should not hang, was {dt:.2f}s"
    print("   -> confirmed: (still) not found, but reported FAST and "
          "HONESTLY instead of hanging or being a false positive\n")


if __name__ == "__main__":
    test_shallow_case_still_works_and_is_fast()
    test_deep_behind_loop_case_still_fails_honestly()
    print("Both tests passed -- improvement AND its limitation confirmed.")
