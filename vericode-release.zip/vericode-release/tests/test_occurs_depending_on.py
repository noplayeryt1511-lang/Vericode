import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. DEPENDTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-COUNT   PIC 9(3).
       01  WS-TABLE.
           05  WS-ITEM PIC 9(5) OCCURS 5 TIMES DEPENDING ON WS-COUNT.
       01  WS-TOTAL   PIC 9(7).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           ADD WS-ITEM (1) TO WS-TOTAL.
           ADD WS-ITEM (2) TO WS-TOTAL.
           STOP RUN.
"""


def test_occurs_depending_on():
    print("=" * 78)
    print("TEST: OCCURS ... DEPENDING ON -- maximum used as a fixed bound, no crash")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        SOURCE, "depend_test", ["ws_item"], "ws_total")
    print(source)
    print("table_types:", legacy_fn.table_types)
    assert legacy_fn.table_types["ws_item"].occurs == 5, "the maximum (5) must be used as the fixed table size"

    table = [10, 20, 30, 40, 50]
    result = legacy_fn(table)
    print("Result (10+20):", result)
    assert result == 30

    def modern_correct(ws_item):
        total = 0
        total = total + ws_item[0]
        total = total + ws_item[1]
        return total
    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_correct.table_types = dict(legacy_fn.table_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> OCCURS ... DEPENDING ON parses and verifies correctly "
          "(WS-COUNT itself remains an ordinary, unused variable "
          "-- there is no dynamic length check; this is a deliberately "
          "documented limitation)\n")


if __name__ == "__main__":
    test_occurs_depending_on()
    print("OCCURS-DEPENDING-ON test passed.")
