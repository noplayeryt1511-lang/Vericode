import z3
from patch_loop import run_patch_loop
from engine import PicField

INVOICE_FIELD = PicField(total_digits=5, decimal_digits=2)


def legacy_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total


legacy_invoice_total.field_types = {"return": INVOICE_FIELD}

CORRECT_SOURCE = """
def modern_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total
"""


def mock_fix(prompt, attempt):
    return CORRECT_SOURCE  # never actually needed for this test, PROVEN immediately


def run():
    print("=" * 78)
    print("SMT2 export end-to-end through run_patch_loop() (via export_smt2=True in verify_kwargs)")
    print("=" * 78)
    result = run_patch_loop(
        legacy_fn=legacy_invoice_total, initial_modern_source=CORRECT_SOURCE,
        function_name="modern_invoice_total", llm_fix_fn=mock_fix,
        arg_type=z3.IntSort(), field_types={"return": INVOICE_FIELD},
        export_smt2=True,  # passed through via **verify_kwargs down to verify()
    )
    print("Success:", result.success)
    print("SMT2 present:", result.smt2 is not None)
    print("SMT2 length:", len(result.smt2) if result.smt2 else 0)
    assert result.success is True
    assert result.smt2 is not None

    print()
    print("Independent verification: fresh solver, ONLY the SMT2 text (no access to our code)")
    fresh_solver = z3.Solver()
    fresh_solver.from_string(result.smt2)
    audit_result = fresh_solver.check()
    print("Independent solver result:", audit_result)
    assert audit_result == z3.unsat  # PROVEN == UNSAT of the negation
    print("-> matches: the proof produced through the full patch loop")
    print("   is independently verifiable, not just tested in isolation.")


if __name__ == "__main__":
    run()
    print()
    print("Test passed.")
