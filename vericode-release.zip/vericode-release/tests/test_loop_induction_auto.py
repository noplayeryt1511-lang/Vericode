from loop_induction import verify_variable_bound_loop, UnsupportedLoopPattern
from test_loop_induction import COBOL_SRC as SINGLE_COBOL, modern_correct as single_correct
from test_loop_induction_conditional import COBOL_SRC as COND_COBOL, modern_correct as cond_correct
from test_loop_induction_nested import COBOL_SRC as NESTED_COBOL, modern_correct as nested_correct
from test_loop_induction_dual import COBOL_SRC as DUAL_COBOL, modern_correct as dual_correct


def test_auto_dispatch_finds_each_pattern():
    print("=" * 78)
    print("TEST: the unified entry point automatically recognizes all four patterns")
    print("=" * 78)

    res = verify_variable_bound_loop(SINGLE_COBOL, single_correct)
    print(f"simple pattern: {res['label']} (detected pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "single"

    res = verify_variable_bound_loop(COND_COBOL, cond_correct)
    print(f"conditional pattern: {res['label']} (detected pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "single"

    res = verify_variable_bound_loop(NESTED_COBOL, nested_correct)
    print(f"nested pattern: {res['label']} (detected pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "nested"

    res = verify_variable_bound_loop(DUAL_COBOL, dual_correct)
    print(f"dual-state pattern: {res['label']} (detected pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "dual"

    print("\n-> all four patterns correctly auto-detected, without the caller needing "
          "to know which of the four functions to use\n")


def test_auto_dispatch_rejects_unsupported():
    print("=" * 78)
    print("TEST: the unified entry point cleanly rejects input when NO pattern matches")
    print("=" * 78)
    unrelated_cobol = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           MOVE 1 TO WS-A.
           STOP RUN.
    """

    def unrelated_fn(x):
        return x

    try:
        verify_variable_bound_loop(unrelated_cobol, unrelated_fn)
        raise AssertionError("Should have raised UnsupportedLoopPattern!")
    except UnsupportedLoopPattern as e:
        print("Correctly rejected, with details on all four failed attempts:")
        print(str(e)[:300], "...")
    print("-> no pattern is guessed at when none actually fits\n")


if __name__ == "__main__":
    test_auto_dispatch_finds_each_pattern()
    test_auto_dispatch_rejects_unsupported()
    print("Both unified entry point tests passed.")
