import z3
from engine import PicField
from patch_loop import convert_and_verify, build_translation_prompt

BALANCE_FIELD = PicField(total_digits=7, decimal_digits=2, signed=True)
FEE_FIELD = PicField(total_digits=5, decimal_digits=2)
ACCOUNT_RECORD = {"balance": BALANCE_FIELD, "fee": FEE_FIELD}


def legacy_apply_fee(account):
    new_balance = account.balance - account.fee
    return new_balance


legacy_apply_fee.record_types = {"account": ACCOUNT_RECORD}
legacy_apply_fee.field_types = {"return": BALANCE_FIELD}

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. APPLYFEE.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  ACCOUNT-RECORD.
           05  BALANCE        PIC S9(5)V99.
           05  FEE            PIC 9(3)V99.

       PROCEDURE DIVISION.
       APPLY-FEE.
           SUBTRACT FEE FROM BALANCE.
           STOP RUN.
"""


def mock_translate(prompt, attempt):
    # Check whether the record hint actually reaches the prompt
    assert "account.balance" in prompt, "Record hint missing from prompt!"
    return '''
def apply_fee(account):
    new_balance = account.balance - account.fee
    return new_balance
'''


if __name__ == "__main__":
    prompt = build_translation_prompt(
        COBOL_SOURCE, "apply_fee", ["account"], record_types={"account": ACCOUNT_RECORD})
    print("--- Prompt excerpt (record hint) ---")
    print([l for l in prompt.splitlines() if "account" in l.lower()][:3])
    print()

    result = convert_and_verify(
        legacy_fn=legacy_apply_fee, cobol_source=COBOL_SOURCE,
        function_name="apply_fee", param_names=["account"],
        llm_fix_fn=mock_translate, arg_type=z3.IntSort(),
        field_types={"return": BALANCE_FIELD},
        record_types={"account": ACCOUNT_RECORD},
    )
    print("Success:", result.success)
    for h in result.history:
        print(" ", h[0], h[1])
