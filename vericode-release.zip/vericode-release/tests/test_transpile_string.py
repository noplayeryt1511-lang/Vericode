import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items
from cobol_transpile import transpile_procedure_division
from engine import verify


def build_legacy_fn(cobol_source, function_name, param_names, return_field_py, extra_param_fields=None):
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(cobol_source, params)
    items = extract_data_items(cobol_source)
    field_types = {it["name"]: it["field"] for it in items if it["field"]}
    field_scales = {k: (v.decimal_digits if hasattr(v, "decimal_digits") else 0) for k, v in field_types.items()}
    source = transpile_procedure_division(
        program, function_name, param_names,
        return_field_py=return_field_py, field_decimal_scales=field_scales,
    )
    print(source)
    namespace = {}
    filename = f"<{function_name}>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    exec(compile(source, filename, "exec"), namespace)
    fn = namespace[function_name]
    fn.field_types = {p: field_types[p] for p in param_names}
    fn.field_types["return"] = field_types[return_field_py]
    return fn, field_types


STRING_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. CONCAT.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-FIRST   PIC X(10).
       01  WS-LAST    PIC X(10).
       01  WS-FULL    PIC X(21).
       PROCEDURE DIVISION.
       P.
           STRING WS-FIRST DELIMITED BY SIZE
                  " " DELIMITED BY SIZE
                  WS-LAST DELIMITED BY SIZE
                  INTO WS-FULL.
           STOP RUN.
"""


def test_string_concat():
    print("=" * 78)
    print("TEST: STRING (concatenation of three segments)")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(
        STRING_SOURCE, "concat_test", ["ws_first", "ws_last"], "ws_full")

    def modern_correct(ws_first, ws_last):
        ws_full = ws_first + " " + ws_last
        return ws_full
    modern_correct.field_types = dict(legacy_fn.field_types)

    def modern_buggy(ws_first, ws_last):
        ws_full = ws_last + " " + ws_first  # Bug: order swapped
        return ws_full
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"  Counterexample: {{k: v.as_string() for k, v in ...}} ->",
              {k: v.as_string() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> STRING works end-to-end\n")


if __name__ == "__main__":
    test_string_concat()
    print("STRING test passed.")
