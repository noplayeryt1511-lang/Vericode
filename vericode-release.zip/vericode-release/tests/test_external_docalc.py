"""
External validation #11: SEVENTH entirely new project --
Apress/beg-cobol-for-programmers, the official companion code for
the published textbook "Beginning COBOL for Programmers" by Michael
Coughlan (Apress, 2014).

Source: Listing 2-3, "The DoCalc example program.cbl":

    COMPUTE CalcResult = FirstNum + SecondNum

Deliberately a very simple example -- no new bug found, but a
legitimate, credible, entirely new source (an academic textbook
rather than a community or company repo).
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. DoCalc.
       AUTHOR. Michael Coughlan.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 FirstNum PIC 9 VALUE ZEROS.
       01 SecondNum PIC 9 VALUE ZEROS.
       01 CalcResult PIC 99 VALUE 0.
       PROCEDURE DIVISION.
       CalculateResult.
           COMPUTE CalcResult = FirstNum + SecondNum
           STOP RUN.
"""


def modern_correct(firstnum, secondnum):
    return firstnum + secondnum


def modern_buggy_subtract(firstnum, secondnum):
    return firstnum - secondnum


def run():
    print("=" * 78)
    print("External validation #11: seventh project -- DoCalc (Coughlan textbook)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "do_calc", ["firstnum", "secondnum"], "calcresult")
    print("Auto-generated reference (from real, published COBOL textbook code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_subtract.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_subtract, arg_type=z3.IntSort())
    print(f"vs. BUGGY (subtraction instead of addition): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Eleventh external source proven, seventh source project.")


if __name__ == "__main__":
    run()
    print("\nExternal validation #11 passed.")
