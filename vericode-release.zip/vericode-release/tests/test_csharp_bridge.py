import linecache
import z3
from csharp_bridge import transpile_csharp_method, UnsupportedCSharpConstruct
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify, PicField

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INC     PIC 9(7)V99.
       01  WS-TAX     PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           IF WS-INC <= 10000.00
               COMPUTE WS-TAX = WS-INC * 10
           ELSE
               IF WS-INC <= 50000.00
                   COMPUTE WS-TAX = WS-INC * 20
               ELSE
                   COMPUTE WS-TAX = WS-INC * 30
               END-IF
           END-IF.
           STOP RUN.
"""

CSHARP_CORRECT = """
public class TaxCalc {
    public static int Calc(int wsInc) {
        int wsTax;
        if (wsInc <= 1000000) {
            wsTax = wsInc * 10;
        } else if (wsInc <= 5000000) {
            wsTax = wsInc * 20;
        } else {
            wsTax = wsInc * 30;
        }
        return wsTax;
    }
}
"""

CSHARP_BUGGY = """
public class TaxCalc {
    public static int Calc(int wsInc) {
        int wsTax;
        if (wsInc < 1000000) {
            wsTax = wsInc * 10;
        } else if (wsInc <= 5000000) {
            wsTax = wsInc * 20;
        } else {
            wsTax = wsInc * 30;
        }
        return wsTax;
    }
}
"""

CSHARP_SUM_CORRECT = """
public class SumCalc {
    public static int Calc(int amt) {
        int total = 0;
        for (int i = 0; i < 12; i++) {
            total += amt;
        }
        return total;
    }
}
"""

CSHARP_SUM_BUGGY = """
public class SumCalc {
    public static int Calc(int amt) {
        int total = 0;
        for (int i = 0; i < 11; i++) {
            total += amt;
        }
        return total;
    }
}
"""

CSHARP_RECORD_SOURCE = """
public class Account {
    public int Balance;
    public int Fee;
}
public class Calc {
    public static int ApplyFee(Account acc) {
        int newBalance = acc.Balance - acc.Fee;
        return newBalance;
    }
}
"""


def load_csharp_as_fn(csharp_source, method_name, field_types, param_names):
    py_source = transpile_csharp_method(csharp_source, method_name, param_names=param_names)
    filename = f"<csharp:{method_name}>"
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    fn = ns[method_name]
    fn.field_types = dict(field_types)
    return fn


def test_if_elif():
    print("=" * 78)
    print("TEST 1: C# as verification target -- automatically generated COBOL reference vs. C#")
    print("=" * 78)
    legacy_fn, legacy_source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "tax_calc", ["ws_inc"], "ws_tax")

    correct_fn = load_csharp_as_fn(CSHARP_CORRECT, "Calc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    res = verify(legacy_fn, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT C#: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_csharp_as_fn(CSHARP_BUGGY, "Calc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    res = verify(legacy_fn, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY C#: {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> if/elif works end-to-end\n")


def test_for_loop():
    def legacy_sum_loop(amt):
        total = 0
        for i in range(12):
            total = total + amt
        return total
    field = PicField(total_digits=9, decimal_digits=2)
    legacy_sum_loop.field_types = {"return": field}

    print("=" * 78)
    print("TEST 2: C# FOR loop with +=")
    print("=" * 78)
    correct_fn = load_csharp_as_fn(CSHARP_SUM_CORRECT, "Calc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT (12x): {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_csharp_as_fn(CSHARP_SUM_BUGGY, "Calc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (11x): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> FOR loop works end-to-end\n")


def test_record_param():
    field = PicField(total_digits=9, decimal_digits=2)
    record_spec = {"balance": field, "fee": field}

    def legacy_apply_fee(acc):
        return acc.balance - acc.fee
    legacy_apply_fee.record_types = {"acc": record_spec}
    legacy_apply_fee.field_types = {"return": field}

    print("=" * 78)
    print("TEST 3: C# class with multiple fields as a record parameter")
    print("=" * 78)
    py_source = transpile_csharp_method(CSHARP_RECORD_SOURCE, "ApplyFee", param_names=["acc"],
                                         field_rename={"Balance": "balance", "Fee": "fee"})
    print(py_source)
    filename = "<csharp:ApplyFee>"
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    csharp_fn = ns["ApplyFee"]
    csharp_fn.record_types = {"acc": record_spec}
    csharp_fn.field_types = {"return": field}

    res = verify(legacy_apply_fee, csharp_fn, arg_type=z3.IntSort())
    print(f"vs. C# record parameter: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> C# class as a record parameter works end-to-end\n")


CSHARP_SWITCH_SOURCE = """
public class X {
    public static int Grade(int code) {
        int level;
        switch (code) {
            case 1:
                level = 100;
                break;
            case 2:
            case 3:
                level = 200;
                break;
            default:
                level = 0;
                break;
        }
        return level;
    }
}
"""

CSHARP_SWITCH_BUGGY = """
public class X {
    public static int Grade(int code) {
        int level;
        switch (code) {
            case 1:
                level = 100;
                break;
            case 2:
                level = 200;
                break;
            default:
                level = 0;
                break;
        }
        return level;
    }
}
"""


def test_switch():
    def legacy_grade(code):
        if code == 1:
            level = 100
        elif code == 2 or code == 3:
            level = 200
        else:
            level = 0
        return level
    field = PicField(total_digits=5, decimal_digits=0)
    legacy_grade.field_types = {"return": field}

    print("=" * 78)
    print("TEST 4: C# switch (analogous to COBOL EVALUATE / Java switch)")
    print("=" * 78)
    correct_fn = load_csharp_as_fn(CSHARP_SWITCH_SOURCE, "Grade", {"return": field}, ["code"])
    res = verify(legacy_grade, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_csharp_as_fn(CSHARP_SWITCH_BUGGY, "Grade", {"return": field}, ["code"])
    res = verify(legacy_grade, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (case 3 missing): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> switch works end-to-end -- parity with Java\n")


CSHARP_TERNARY_SOURCE = """
public class X {
    public static int Max2(int a, int b) {
        int r = a > b ? a : b;
        return r;
    }
}
"""

CSHARP_TERNARY_BUGGY = """
public class X {
    public static int Max2(int a, int b) {
        int r = a >= b ? b : a;
        return r;
    }
}
"""

CSHARP_WHILE_SOURCE = """
public class X {
    public static int SumLoop(int amt) {
        int total = 0;
        int i = 0;
        while (i < 12) {
            total += amt;
            i++;
        }
        return total;
    }
}
"""

CSHARP_WHILE_BUGGY = """
public class X {
    public static int SumLoop(int amt) {
        int total = 0;
        int i = 0;
        while (i < 11) {
            total += amt;
            i++;
        }
        return total;
    }
}
"""


def test_ternary():
    print("=" * 78)
    print("TEST 5: C# ternary operator")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)

    def legacy_max2(a, b):
        if a > b:
            r = a
        else:
            r = b
        return r
    legacy_max2.field_types = {"return": field}

    correct_fn = load_csharp_as_fn(CSHARP_TERNARY_SOURCE, "Max2", {"return": field}, ["a", "b"])
    res = verify(legacy_max2, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_csharp_as_fn(CSHARP_TERNARY_BUGGY, "Max2", {"return": field}, ["a", "b"])
    res = verify(legacy_max2, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> ternary operator works end-to-end -- parity with Java\n")


def test_while_counted_loop():
    print("=" * 78)
    print("TEST 6: C# while counted loop")
    print("=" * 78)

    def legacy_sum_loop_while(amt):
        total = 0
        for i in range(12):
            total = total + amt
        return total
    field = PicField(total_digits=9, decimal_digits=2)
    legacy_sum_loop_while.field_types = {"return": field}

    correct_fn = load_csharp_as_fn(CSHARP_WHILE_SOURCE, "SumLoop", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop_while, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT (12x): {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_csharp_as_fn(CSHARP_WHILE_BUGGY, "SumLoop", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop_while, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (11x):   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> while counted loop works end-to-end -- parity with Java\n")


CSHARP_ARRAY_SOURCE = """
public class X {
    public static int SumArray(int[] items) {
        int total = 0;
        for (int i = 0; i < 5; i++) {
            total = total + items[i];
        }
        return total;
    }
}
"""

CSHARP_ARRAY_BUGGY = """
public class X {
    public static int SumArray(int[] items) {
        int total = 0;
        for (int i = 0; i < 4; i++) {
            total = total + items[i];
        }
        return total;
    }
}
"""


def test_array_param():
    from engine import TableField
    print("=" * 78)
    print("TEST 7: C# int[] array as a table parameter")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    table_spec = TableField(element=field, occurs=5)

    def legacy_sum_array(items):
        total = 0
        for i in range(5):
            total = total + items[i]
        return total
    legacy_sum_array.field_types = {"return": field}
    legacy_sum_array.table_types = {"items": table_spec}

    correct_fn = load_csharp_as_fn(CSHARP_ARRAY_SOURCE, "SumArray", {"return": field}, ["items"])
    correct_fn.table_types = {"items": table_spec}
    res = verify(legacy_sum_array, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_csharp_as_fn(CSHARP_ARRAY_BUGGY, "SumArray", {"return": field}, ["items"])
    buggy_fn.table_types = {"items": table_spec}
    res = verify(legacy_sum_array, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (only 4 instead of 5 elements): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> C# int[] array as a table parameter works end-to-end -- parity with Java\n")


CSHARP_STRING_SOURCE = """
public class X {
    public static string Pick(string a, string b, int useFirst) {
        string r;
        if (useFirst > 0) {
            r = a;
        } else {
            r = b;
        }
        return r;
    }
}
"""

CSHARP_STRING_BUGGY = """
public class X {
    public static string Pick(string a, string b, int useFirst) {
        string r;
        if (useFirst >= 0) {
            r = a;
        } else {
            r = b;
        }
        return r;
    }
}
"""


def test_string_param():
    from engine import PicX
    print("=" * 78)
    print("TEST 8: C# string as a parameter/return type")
    print("=" * 78)
    field = PicX(10)

    def legacy_pick(a, b, use_first):
        if use_first > 0:
            r = a
        else:
            r = b
        return r
    legacy_pick.field_types = {"a": field, "b": field, "return": field}

    correct_fn = load_csharp_as_fn(CSHARP_STRING_SOURCE, "Pick", {"return": field}, ["a", "b", "use_first"])
    correct_fn.field_types = {"a": field, "b": field, "return": field}
    res = verify(legacy_pick, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_csharp_as_fn(CSHARP_STRING_BUGGY, "Pick", {"return": field}, ["a", "b", "use_first"])
    buggy_fn.field_types = {"a": field, "b": field, "return": field}
    res = verify(legacy_pick, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (>= instead of >): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> C# string as a parameter/return type works end-to-end -- parity with Java\n")


if __name__ == "__main__":
    test_if_elif()
    test_for_loop()
    test_record_param()
    test_switch()
    test_ternary()
    test_while_counted_loop()
    test_array_param()
    test_string_param()
    print("All eight C# bridge tests passed -- parity with Java achieved.")
