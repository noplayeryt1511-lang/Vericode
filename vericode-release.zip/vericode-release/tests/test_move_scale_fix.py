"""
Proactively found bug (after multiplication, ADD/SUBTRACT, and comparisons,
this is the FOURTH instance of the same scaling-error class, this time in
MOVE -- likely the most frequently triggered one, since MOVE is by far the
most common COBOL statement): 'MOVE WS-SRC TO WS-DST' with WS-SRC at one
decimal place and WS-DST at two decimal places carried the raw value over
UNCHANGED -- 7.6 was incorrectly turned into 0.76 instead of the correct
7.60.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-SRC   PIC 9(2)V9(1).
       01  WS-DST   PIC 9(2)V9(2).
       PROCEDURE DIVISION.
       P.
           MOVE WS-SRC TO WS-DST.
           STOP RUN.
"""


def modern_correct(ws_src):
    return ws_src * 10


def modern_buggy_no_scale_correction(ws_src):
    # Bug: exactly the MOVE scaling error described above -- the raw
    # value is carried over unchanged (representing the state BEFORE
    # the fix).
    return ws_src


def run():
    print("=" * 78)
    print("TEST: MOVE scaling error (proactively found, fourth instance of the same class)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_src"], "ws_dst")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_no_scale_correction.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_no_scale_correction, arg_type=z3.IntSort())
    print(f"vs. BUGGY (MOVE without scale correction): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> MOVE scaling error fixed and proven end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
