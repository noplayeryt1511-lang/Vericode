import z3
from engine import PicField
from patch_loop import run_patch_loop


def mock_correct(prompt, attempt):
    return """
def invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total
"""


def test_smt2_through_patch_loop():
    print("=" * 78)
    print("SMT2 export through the complete patch-loop/sandbox flow")
    print("=" * 78)

    def legacy_invoice_total(quantity, unit_price_scaled):
        total = quantity * unit_price_scaled
        return total

    invoice_field = PicField(total_digits=5, decimal_digits=2)
    legacy_invoice_total.field_types = {"return": invoice_field}

    result = run_patch_loop(
        legacy_fn=legacy_invoice_total,
        initial_modern_source="def invoice_total(quantity, unit_price_scaled):\n    total = quantity * unit_price_scaled\n    return total\n",
        function_name="invoice_total", llm_fix_fn=mock_correct,
        arg_type=z3.IntSort(), field_types={"return": invoice_field},
        export_smt2=True,  # <-- this is the actual point of the test: does this survive the sandbox?
    )
    print("success:", result.success)
    print("smt2 present:", result.smt2 is not None)
    assert result.success is True
    assert result.smt2 is not None, "SMT2 export did NOT survive the sandbox!"
    print(f"SMT2 length: {len(result.smt2)} characters")

    # Independent verification: fresh solver, ONLY the SMT2 text, no access
    # to our Python code
    fresh_solver = z3.Solver()
    fresh_solver.from_string(result.smt2)
    check_result = fresh_solver.check()
    print("Independent verification (fresh solver):", check_result)
    assert check_result == z3.unsat, "Independent verification does NOT match PROVEN!"
    print("-> SMT2 export works through the complete patch loop, independently confirmed\n")


if __name__ == "__main__":
    test_smt2_through_patch_loop()
    print("Test passed.")
