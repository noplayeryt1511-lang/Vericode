import linecache
import z3
from rust_bridge import transpile_rust_function, UnsupportedRustConstruct
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify, PicField, PicX, TableField

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INC     PIC 9(7)V99.
       01  WS-TAX     PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           IF WS-INC <= 10000.00
               COMPUTE WS-TAX = WS-INC * 10
           ELSE
               IF WS-INC <= 50000.00
                   COMPUTE WS-TAX = WS-INC * 20
               ELSE
                   COMPUTE WS-TAX = WS-INC * 30
               END-IF
           END-IF.
           STOP RUN.
"""

RUST_CORRECT = """
fn calc(ws_inc: i64) -> i64 {
    if ws_inc <= 1000000 {
        ws_inc * 10
    } else if ws_inc <= 5000000 {
        ws_inc * 20
    } else {
        ws_inc * 30
    }
}
"""

RUST_BUGGY = """
fn calc(ws_inc: i64) -> i64 {
    if ws_inc < 1000000 {
        ws_inc * 10
    } else if ws_inc <= 5000000 {
        ws_inc * 20
    } else {
        ws_inc * 30
    }
}
"""

RUST_SUM_CORRECT = """
fn calc(amt: i64) -> i64 {
    let mut total: i64 = 0;
    for i in 0..12 {
        total += amt;
    }
    total
}
"""

RUST_SUM_BUGGY = """
fn calc(amt: i64) -> i64 {
    let mut total: i64 = 0;
    for i in 0..11 {
        total += amt;
    }
    total
}
"""

RUST_ARRAY_SOURCE = """
fn sum_array(items: [i64; 5]) -> i64 {
    let mut total: i64 = 0;
    for i in 0..5 {
        total = total + items[i];
    }
    total
}
"""

RUST_ARRAY_BUGGY = """
fn sum_array(items: [i64; 5]) -> i64 {
    let mut total: i64 = 0;
    for i in 0..4 {
        total = total + items[i];
    }
    total
}
"""

RUST_STRING_SOURCE = """
fn pick(a: String, b: String, use_first: i64) -> String {
    if use_first > 0 {
        a
    } else {
        b
    }
}
"""

RUST_STRING_BUGGY = """
fn pick(a: String, b: String, use_first: i64) -> String {
    if use_first >= 0 {
        a
    } else {
        b
    }
}
"""

RUST_RECORD_SOURCE = """
fn apply_fee(acc: Account) -> i64 {
    acc.balance - acc.fee
}
"""


def load_rust_as_fn(rust_source, function_name, field_types, param_names, table_types=None, record_types=None,
                     field_rename=None):
    py_source = transpile_rust_function(rust_source, function_name, param_names=param_names, field_rename=field_rename)
    filename = f"<rust:{function_name}:{id(rust_source)}>"
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    fn = ns[function_name]
    fn.field_types = dict(field_types)
    fn.table_types = dict(table_types or {})
    fn.record_types = dict(record_types or {})
    return fn


def test_if_elif():
    print("=" * 78)
    print("TEST 1: Rust as a verification target -- auto-generated COBOL reference vs. Rust")
    print("(Rust quirk: if as a value expression, no 'return' -- see the module docstring in rust_bridge.py)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "tax_calc", ["ws_inc"], "ws_tax")

    correct_fn = load_rust_as_fn(RUST_CORRECT, "calc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    res = verify(legacy_fn, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT Rust: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_rust_as_fn(RUST_BUGGY, "calc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    res = verify(legacy_fn, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY Rust: {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> if as a value expression (implicit return) works end-to-end\n")


def test_for_loop():
    def legacy_sum_loop(amt):
        total = 0
        for i in range(12):
            total = total + amt
        return total
    field = PicField(total_digits=9, decimal_digits=2)
    legacy_sum_loop.field_types = {"return": field}

    print("=" * 78)
    print("TEST 2: Rust FOR loop (range-based) with +=")
    print("=" * 78)
    correct_fn = load_rust_as_fn(RUST_SUM_CORRECT, "calc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT (12x): {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_rust_as_fn(RUST_SUM_BUGGY, "calc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (11x): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> range-based FOR loop works end-to-end\n")


def test_array_param():
    print("=" * 78)
    print("TEST 3: Rust [i64; N] array as a table parameter")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    table_spec = TableField(element=field, occurs=5)

    def legacy_sum_array(items):
        total = 0
        for i in range(5):
            total = total + items[i]
        return total
    legacy_sum_array.field_types = {"return": field}
    legacy_sum_array.table_types = {"items": table_spec}

    correct_fn = load_rust_as_fn(RUST_ARRAY_SOURCE, "sum_array", {"return": field}, ["items"], table_types={"items": table_spec})
    res = verify(legacy_sum_array, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_rust_as_fn(RUST_ARRAY_BUGGY, "sum_array", {"return": field}, ["items"], table_types={"items": table_spec})
    res = verify(legacy_sum_array, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (only 4 elements instead of 5): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> [i64; N] array as a table parameter works end-to-end\n")


def test_string_param():
    print("=" * 78)
    print("TEST 4: Rust String as parameter/return type")
    print("=" * 78)
    field = PicX(10)

    def legacy_pick(a, b, use_first):
        if use_first > 0:
            r = a
        else:
            r = b
        return r
    legacy_pick.field_types = {"a": field, "b": field, "return": field}

    correct_fn = load_rust_as_fn(RUST_STRING_SOURCE, "pick", {"a": field, "b": field, "return": field}, ["a", "b", "use_first"])
    res = verify(legacy_pick, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_rust_as_fn(RUST_STRING_BUGGY, "pick", {"a": field, "b": field, "return": field}, ["a", "b", "use_first"])
    res = verify(legacy_pick, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (>= instead of >): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> String as parameter/return type works end-to-end\n")


def test_record_param():
    print("=" * 78)
    print("TEST 5: Rust struct with multiple fields as a record parameter")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=2)
    record_spec = {"balance": field, "fee": field}

    def legacy_apply_fee(acc):
        return acc.balance - acc.fee
    legacy_apply_fee.field_types = {"return": field}
    legacy_apply_fee.record_types = {"acc": record_spec}

    correct_fn = load_rust_as_fn(RUST_RECORD_SOURCE, "apply_fee", {"return": field}, ["acc"],
                                  record_types={"acc": record_spec})
    res = verify(legacy_apply_fee, correct_fn, arg_type=z3.IntSort())
    print(f"vs. Rust record parameter: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> Rust struct as a record parameter works end-to-end\n")


if __name__ == "__main__":
    test_if_elif()
    test_for_loop()
    test_array_param()
    test_string_param()
    test_record_param()
    print("All five Rust bridge tests passed -- fourth target language reaches parity with Java/C#/Go.")
