# -*- coding: utf-8 -*-
"""
Direct comparison at equal budget: random fuzzing (the older fallback)
vs. concolic search (the newer fallback) -- on a function with an unbounded
while loop (not symbolically provable, so it falls into the fallback tier)
and a bug that only triggers at ONE exact input value.
"""

import random
import time

from concolic import concolic_search
from engine import differential_fuzz

TRIGGER = 13_337
BOUND = (0, 20_000)
BUDGET = 300


def legacy_cumsum(code):
    # Unbounded while loop -> not provable by the SymbolicEvaluator, so it
    # falls through to the regular fallback tier (VERIFIED-BY-TESTING / FLAGGED)
    n = code if code > 0 else 0
    total = 0
    i = 0
    while i < n:
        total = total + i
        i = i + 1
    return total


def modern_cumsum_buggy(code):
    n = code if code > 0 else 0
    base = n * (n - 1) // 2
    if n == TRIGGER:  # Bug only at EXACTLY this one value
        base = base + 1
    return base


def run():
    print("=" * 78)
    print(f"A) Random fuzzing, budget={BUDGET} samples, trigger at exactly code={TRIGGER} (range 0-{BOUND[1]})")
    print("-" * 78)
    random.seed(42)
    sampler = lambda: (random.randint(*BOUND),)
    t0 = time.time()
    res = differential_fuzz(legacy_cumsum, modern_cumsum_buggy, n_samples=BUDGET, sampler=sampler)
    dt = time.time() - t0
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print(f"  Runtime: {dt:.2f}s")
    print()

    print("=" * 78)
    print(f"B) Concolic search, SAME budget={BUDGET} iterations")
    print("-" * 78)
    t0 = time.time()
    res2 = concolic_search(legacy_cumsum, modern_cumsum_buggy, seed=(0,), max_iterations=BUDGET, bound=BOUND)
    dt2 = time.time() - t0
    print(f"  Found: {res2.found_diff}")
    print(f"  {res2.note}")
    if res2.counterexample:
        print(f"  Counterexample: {res2.counterexample}")
    print(f"  Runtime: {dt2:.2f}s")
    print()


if __name__ == "__main__":
    run()
