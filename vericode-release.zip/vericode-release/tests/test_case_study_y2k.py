# -*- coding: utf-8 -*-
"""
Case study 5: century windowing for 2-digit year fields (PIC 99).

THE classic COBOL modernization bug: legacy systems often store the year as
only 2 digits (PIC 99). During migration, a "windowing" rule must be applied
to decide whether, e.g., '75' means 1975 or 2075. If an LLM migration picks
the wrong cutover point, an entire range of years shifts by 100 years --
with knock-on errors in contract terms, age calculations, interest periods,
and so on.
"""

import z3
from engine import verify, PicField


YY_FIELD = PicField(total_digits=2, decimal_digits=0)  # 00-99


def legacy_expand_year(yy):
    # COBOL windowing rule (common practice): yy < 50 -> 20yy, otherwise 19yy
    if yy < 50:
        year = 2000 + yy
    else:
        year = 1900 + yy
    return year


legacy_expand_year.field_types = {"yy": YY_FIELD}


def modern_expand_year_buggy(yy):
    # Bug: the LLM used a DIFFERENT, also-common cutover value (e.g. from a
    # generic training example) instead of determining the boundary actually
    # used by this system
    if yy < 30:
        year = 2000 + yy
    else:
        year = 1900 + yy
    return year


modern_expand_year_buggy.field_types = {"yy": YY_FIELD}


def modern_expand_year_correct(yy):
    if yy < 50:
        year = 2000 + yy
    else:
        year = 1900 + yy
    return year


modern_expand_year_correct.field_types = {"yy": YY_FIELD}


def run():
    print("=" * 78)
    print("5a. Century windowing: LEGACY (cutover at 50) vs. MODERN (cutover at 30, bug)")
    print("-" * 78)
    res = verify(legacy_expand_year, modern_expand_year_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        yy = res.counterexample["yy"].as_long()
        print(f"  Counterexample: yy={yy:02d}")
        print(f"    legacy interprets as  {legacy_expand_year(yy)}")
        print(f"    modern (buggy) interprets as {modern_expand_year_buggy(yy)}")
        print(f"    -> ALL years {30:02d}-{49:02d} would be affected, not just this one value")
    print()

    print("=" * 78)
    print("5b. Century windowing: LEGACY vs. MODERN correct (same cutover)")
    print("-" * 78)
    res = verify(legacy_expand_year, modern_expand_year_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()


if __name__ == "__main__":
    run()
