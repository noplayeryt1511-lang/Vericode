import z3
from engine import PicField
from patch_loop import run_patch_loop

INVOICE_FIELD = PicField(total_digits=5, decimal_digits=2)


def legacy_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total


legacy_invoice_total.field_types = {"return": INVOICE_FIELD}

BROKEN_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled):
    total = 424242
    return total
'''


def always_broken_mock(prompt, attempt):
    """Simulates an LLM that NEVER produces a working fix -- exercises
    the fully unsuccessful path."""
    return BROKEN_SOURCE


def run():
    result = run_patch_loop(
        legacy_fn=legacy_invoice_total,
        initial_modern_source=BROKEN_SOURCE,
        function_name="modern_invoice_total",
        llm_fix_fn=always_broken_mock,
        arg_type=z3.IntSort(),
        field_types={"return": INVOICE_FIELD},
        max_attempts=3,
    )
    print("success:", result.success)
    print("attempts (verify rounds):", result.attempts)
    print("repairs_used (actual LLM calls):", result.repairs_used)
    print("final_source:")
    print(result.final_source)
    print()

    # Core check: final_source MUST be the source that was actually last
    # checked (BROKEN_SOURCE, since the mock never returns anything else) --
    # NOT an unverified result of an extra, wasted final call.
    assert result.final_source.strip() == BROKEN_SOURCE.strip(), "final_source is NOT the last checked source!"
    # With max_attempts=3, 3 verify() rounds run, but a repair is only
    # attempted after rounds 1 and 2 (round 3 is the last one, and another
    # call would serve no purpose) -> repairs_used must be 2, not 3.
    assert result.attempts == 3, f"attempts should be 3, was {result.attempts}"
    assert result.repairs_used == 2, f"repairs_used should be 2, was {result.repairs_used}"
    print("All assertions passed: final_source is verified, repairs_used is correct.")


if __name__ == "__main__":
    run()
