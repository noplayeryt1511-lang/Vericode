"""
Extends the C proof-of-concept bridge with bitwise operators
(&, |, ^, ~, <<, >>), and documents a known limitation found while
doing so: the proof approach (Int2BV/BV2Int over unbounded Z3 integers)
works reliably only for identical or very simple bitwise expressions --
once two genuinely different bitwise expressions need to be compared
(the actual point of the exercise), the proof hangs indefinitely. This
was confirmed via several independent narrowing steps (shifting the
boundary value, and a different operator -- both hang), so it is not
an edge case specific to a single test.

Note: Python's signal.alarm() does not help here -- Z3 apparently
keeps control in native C code the whole time without returning to
Python, so an in-process timeout never fires. A timeout has to be
enforced at the process level (see the separate test file
test_c_bridge_bitwise_hang_probe.py, which is intentionally NOT part
of the normal test suite and is only meant to be run with an external
'timeout' command)."""
import z3
from c_bridge import transpile_c_function
from engine import verify, PicField


C_SOURCE = """
int is_power_of_two(int n) {
    if (n <= 0) {
        return 0;
    } else {
        return (n & (n - 1)) == 0;
    }
}
"""


def test_bitwise_transpiles_and_executes_correctly():
    """Covers what works reliably: parsing, translating, and concretely
    executing (not symbolically proving) the bitwise operators."""
    print("=" * 78)
    print("TEST 1: bitwise operators -- transpilation and concrete execution")
    print("=" * 78)
    py_source = transpile_c_function(C_SOURCE, "is_power_of_two", param_names=["n"])
    print(py_source)
    ns = {}
    exec(compile(py_source, "<c_bitwise>", "exec"), ns)
    fn = ns["is_power_of_two"]
    expected = {0: 0, 1: 1, 2: 1, 3: 0, 4: 1, 8: 1, 15: 0, 16: 1, -4: 0}
    for n, exp in expected.items():
        got = fn(n)
        assert got == exp, f"is_power_of_two({n}) = {got}, expected {exp}"
    print("-> all concrete test cases correct (0, 1, 2, 3, 4, 8, 15, 16, -4)\n")


def test_bitwise_identical_expression_proven_instantly():
    """Confirms that the symbolic proof works when both sides have
    exactly the same bitwise structure (trivial, but a real, verified
    data point rather than an assumption)."""
    print("=" * 78)
    print("TEST 2: identical bitwise expressions -- proven symbolically, instantly")
    print("=" * 78)

    def legacy(n):
        if n <= 0:
            return 0
        return 1 if (n & (n - 1)) == 0 else 0

    def modern(n):
        if n <= 0:
            return 0
        return 1 if (n & (n - 1)) == 0 else 0

    field = PicField(total_digits=1, decimal_digits=0)
    legacy.field_types = {"return": field}
    modern.field_types = {"return": field}
    res = verify(legacy, modern, arg_type=z3.IntSort())
    print(f"Result: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> identical bitwise expressions are proven instantly\n")


if __name__ == "__main__":
    test_bitwise_transpiles_and_executes_correctly()
    test_bitwise_identical_expression_proven_instantly()
    print("Both regular tests passed. See the module docstring above for "
          "the separately documented known limitation with differing "
          "bitwise expressions.")
