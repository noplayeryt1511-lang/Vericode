from loop_induction import verify_nested_accumulator_loop, UnsupportedLoopPattern

COBOL_SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-ROWS    PIC 9(3).
       01  WS-TABLE.
           05  WS-ROW OCCURS 100 TIMES.
               10  WS-ITEM PIC S9(5) OCCURS 3 TIMES.
       01  WS-I       PIC 9(3).
       01  WS-J       PIC 9(3).
       01  WS-TOTAL   PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > WS-ROWS
               PERFORM VARYING WS-J FROM 1 BY 1 UNTIL WS-J > 3
                   ADD WS-ITEM (WS-I WS-J) TO WS-TOTAL
               END-PERFORM
           END-PERFORM.
           STOP RUN.
"""


def modern_correct(ws_item, ws_rows):
    ws_total = 0
    for i in range(ws_rows):
        for j in range(3):
            ws_total = ws_total + ws_item[i][j]
    return ws_total


def modern_buggy_wrong_inner_bound(ws_item, ws_rows):
    ws_total = 0
    for i in range(ws_rows):
        for j in range(2):  # Bug: only 2 columns per row instead of 3
            ws_total = ws_total + ws_item[i][j]
    return ws_total


def modern_buggy_wrong_coeff(ws_item, ws_rows):
    ws_total = 0
    for i in range(ws_rows):
        for j in range(3):
            ws_total = ws_total + ws_item[i][j] * 2  # Bug: incorrectly doubled
    return ws_total


def test_nested_correct():
    print("=" * 78)
    print("TEST 1: nested accumulator loop (variable outer, fixed inner) -- correct")
    print("=" * 78)
    res = verify_nested_accumulator_loop(COBOL_SRC, modern_correct)
    print(f"Result: {res['label']}")
    print(f"COBOL side:   {res['legacy_spec']}")
    print(f"Python side:  {res['modern_spec']}")
    assert res["label"] == "PROVEN"
    print("-> proven for EVERY row count, fixed column count correctly unrolled\n")


def test_nested_buggy():
    print("=" * 78)
    print("TEST 2: nested accumulator loop -- wrong inner bound")
    print("=" * 78)
    try:
        res = verify_nested_accumulator_loop(COBOL_SRC, modern_buggy_wrong_inner_bound)
        # If no error is raised here, it should fail via the inner_bound check itself
        print(f"Result: {res['label']}")
        assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    except UnsupportedLoopPattern as e:
        print(f"Correctly rejected (differing inner bounds): {e}")
    print("-> the wrong inner bound is caught (either as a rejection or as a proof failure)\n")


def test_nested_buggy_via_proof_itself():
    print("=" * 78)
    print("TEST 3: nested accumulator loop -- same structure, wrong coefficient")
    print("(here the induction proof itself must catch it, not just a pre-check)")
    print("=" * 78)
    res = verify_nested_accumulator_loop(COBOL_SRC, modern_buggy_wrong_coeff)
    print(f"Result: {res['label']}, counterexample k={res['counterexample_k']}")
    assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    print("-> the induction step itself catches the error, not just a structural check\n")


if __name__ == "__main__":
    test_nested_correct()
    test_nested_buggy()
    test_nested_buggy_via_proof_itself()
    print("All three tests for nested accumulator loops passed.")
