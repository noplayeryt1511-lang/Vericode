import linecache
import z3
from java_bridge import transpile_java_method
from engine import verify, PicField

JAVA_NESTED_SOURCE = """
public class Address {
    public int zip;
}
public class Person {
    public int age;
    public Address addr;
}
public class X {
    public static int getZip(Person p) {
        return p.addr.zip;
    }
}
"""

JAVA_NESTED_BUGGY = """
public class Address {
    public int zip;
}
public class Person {
    public int age;
    public Address addr;
}
public class X {
    public static int getZip(Person p) {
        return p.age;
    }
}
"""


def load(src, param_names, field_types, record_types):
    py = transpile_java_method(src, "getZip", param_names=param_names)
    filename = f"<java:getZip:{id(src)}>"
    linecache.cache[filename] = (len(py), None, py.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py, filename, "exec"), ns)
    fn = ns["getZip"]
    fn.field_types = dict(field_types)
    fn.record_types = dict(record_types)
    return fn


def test_nested_record():
    print("=" * 78)
    print("TEST: nested object (Person contains Address)")
    print("=" * 78)
    zip_field = PicField(total_digits=5, decimal_digits=0)
    age_field = PicField(total_digits=3, decimal_digits=0)
    person_spec = {"age": age_field, "addr": {"zip": zip_field}}

    def legacy_get_zip(person):
        return person.addr.zip
    legacy_get_zip.field_types = {"return": zip_field}
    legacy_get_zip.record_types = {"person": person_spec}

    correct_fn = load(JAVA_NESTED_SOURCE, ["person"], {"return": zip_field}, {"person": person_spec})
    print("Transpiled from Java:")
    print(transpile_java_method(JAVA_NESTED_SOURCE, "getZip", param_names=["person"]))

    res = verify(legacy_get_zip, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load(JAVA_NESTED_BUGGY, ["person"], {"return": zip_field}, {"person": person_spec})
    res = verify(legacy_get_zip, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (reads .age instead of .addr.zip): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> nested object works end-to-end, including the field-renaming fix\n")


if __name__ == "__main__":
    test_nested_record()
    print("Nested object test passed.")
