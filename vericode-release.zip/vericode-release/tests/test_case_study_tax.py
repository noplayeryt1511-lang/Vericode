# -*- coding: utf-8 -*-
"""
Case study 3: progressive tax bracket (tax bracket parsing).

Classic LLM migration bug in bracket logic: < instead of <= at a bracket
boundary. Unlike the previous cases, this one needs NO loop -- it is pure
if/elif/else, so it is a "clean" tier-1 PROVEN case (or an immediate FLAGGED
when the bug is present) with no fuzzing/concolic fallback needed. Good as a
first, simplest example in a design-partner pitch, since the proof completes
in milliseconds and the boundary is immediately understandable.
"""

import z3
from engine import verify, PicField


INCOME_FIELD = PicField(total_digits=9, decimal_digits=2)  # up to 9,999,999.99


def legacy_tax_bracket(income_scaled):
    # Flat-bracket tax: the ENTIRE amount is taxed at the applicable rate
    # (not a marginal rate), so a real jump occurs at each bracket boundary --
    # a classic "cliff-edge" tax design
    if income_scaled <= 1_000_000:
        tax = income_scaled * 10 // 100
    elif income_scaled <= 5_000_000:
        tax = income_scaled * 20 // 100
    else:
        tax = income_scaled * 30 // 100
    return tax


legacy_tax_bracket.field_types = {"income_scaled": INCOME_FIELD}


def modern_tax_bracket_buggy(income_scaled):
    # Bug: "<" instead of "<=" at the first bracket boundary -> at EXACTLY
    # 10,000.00 the value incorrectly lands in the 20% bracket instead of
    # the 10% bracket
    if income_scaled < 1_000_000:
        tax = income_scaled * 10 // 100
    elif income_scaled <= 5_000_000:
        tax = income_scaled * 20 // 100
    else:
        tax = income_scaled * 30 // 100
    return tax


modern_tax_bracket_buggy.field_types = {"income_scaled": INCOME_FIELD}


def modern_tax_bracket_correct(income_scaled):
    if income_scaled <= 1_000_000:
        tax = income_scaled * 10 // 100
    elif income_scaled <= 5_000_000:
        tax = income_scaled * 20 // 100
    else:
        tax = income_scaled * 30 // 100
    return tax


modern_tax_bracket_correct.field_types = {"income_scaled": INCOME_FIELD}


def run():
    print("=" * 78)
    print("3a. Tax bracket: LEGACY vs. MODERN with '<' instead of '<=' at the boundary")
    print("-" * 78)
    res = verify(legacy_tax_bracket, modern_tax_bracket_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        inc = res.counterexample["income_scaled"].as_long()
        print(f"  Counterexample: income = {inc/100:.2f}")
        print(f"    legacy tax = {legacy_tax_bracket(inc)/100:.2f}")
        print(f"    modern (buggy) tax = {modern_tax_bracket_buggy(inc)/100:.2f}")
    print()

    print("=" * 78)
    print("3b. Tax bracket: LEGACY vs. MODERN correct")
    print("-" * 78)
    res = verify(legacy_tax_bracket, modern_tax_bracket_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()


if __name__ == "__main__":
    run()
