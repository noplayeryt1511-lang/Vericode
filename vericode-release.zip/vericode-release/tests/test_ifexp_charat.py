import z3
from engine import verify, PicX


def legacy_test(s):
    r = "X" if char_at(s, 0) == "A" else "Y"
    return r


legacy_test.field_types = {"s": PicX(3), "return": PicX(1)}


def modern_correct(s):
    r = "X" if char_at(s, 0) == "A" else "Y"
    return r


modern_correct.field_types = {"s": PicX(3), "return": PicX(1)}


def modern_buggy(s):
    r = "X" if char_at(s, 1) == "A" else "Y"  # Bug: wrong index position
    return r


modern_buggy.field_types = {"s": PicX(3), "return": PicX(1)}


def char_at(s, i):
    return s[i:i + 1]


if __name__ == "__main__":
    res = verify(legacy_test, modern_correct, arg_type=z3.IntSort())
    print("vs CORRECT:", res.label.value)
    assert res.label.value == "PROVEN"

    res = verify(legacy_test, modern_buggy, arg_type=z3.IntSort())
    print("vs BUGGY:", res.label.value)
    if res.counterexample:
        print("Counterexample:", {k: v.as_string() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("IfExp + char_at work correctly.")
