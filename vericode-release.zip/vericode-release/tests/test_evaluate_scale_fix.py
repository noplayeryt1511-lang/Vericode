"""
This covers a scaling bug class in COBOL EVALUATE (the fifth instance of
the same scaling error class, after multiplication, ADD/SUBTRACT,
comparisons, MOVE): 'EVALUATE <subject> / WHEN <field>' compares the
subject against another FIELD VALUE (not just a literal) -- this runs
through its own mechanism (_when_value_condition), which does NOT go
through the normal condition parser and therefore needed a SEPARATE fix.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(2)V9(1).
       01  WS-B       PIC 9(2)V9(2).
       01  WS-RESULT  PIC 9(1).
       PROCEDURE DIVISION.
       P.
           EVALUATE WS-A
               WHEN WS-B
                   MOVE 1 TO WS-RESULT
               WHEN OTHER
                   MOVE 0 TO WS-RESULT
           END-EVALUATE.
           STOP RUN.
"""


def modern_correct(ws_a, ws_b):
    if (ws_a * 10) == ws_b:
        r = 1
    else:
        r = 0
    return r


def modern_buggy_no_scale_correction(ws_a, ws_b):
    # Bug: exactly the EVALUATE scaling error described above -- raw,
    # differently scaled values are compared directly
    # (represents the state BEFORE the fix).
    if ws_a == ws_b:
        r = 1
    else:
        r = 0
    return r


def run():
    print("=" * 78)
    print("TEST: EVALUATE-against-field scaling bug (fifth instance of this bug class)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_a", "ws_b"], "ws_result")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_no_scale_correction.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_no_scale_correction, arg_type=z3.IntSort())
    print(f"vs. BUGGY (EVALUATE without scale correction): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> EVALUATE-against-field scaling bug fixed and proven end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
