import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items
from cobol_transpile import transpile_procedure_division
from engine import verify


def build_legacy_fn(cobol_source, function_name, param_names, return_field_py):
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(cobol_source, params)
    items = extract_data_items(cobol_source)
    field_scales = {it["name"]: it["field"].decimal_digits for it in items if it["field"]}
    field_types = {it["name"]: it["field"] for it in items if it["field"]}
    source = transpile_procedure_division(
        program, function_name, param_names,
        return_field_py=return_field_py, field_decimal_scales=field_scales,
    )
    print(source)
    namespace = {}
    filename = f"<{function_name}>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    exec(compile(source, filename, "exec"), namespace)
    fn = namespace[function_name]
    fn.field_types = {"return": field_types[return_field_py]}
    return fn, field_types


# --- EVALUATE <subject> ------------------------------------------------------

EVALUATE_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. EVALTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-CODE     PIC 9(2).
       01  WS-RESULT   PIC 9(5).
       PROCEDURE DIVISION.
       P.
           EVALUATE WS-CODE
               WHEN 1
                   MOVE 100 TO WS-RESULT
               WHEN 2
                   MOVE 200 TO WS-RESULT
               WHEN OTHER
                   MOVE 0 TO WS-RESULT
           END-EVALUATE.
           STOP RUN.
"""


def test_evaluate_subject():
    print("=" * 78)
    print("TEST 1: EVALUATE <subject> / WHEN <value>")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(EVALUATE_SOURCE, "evaluate_test", ["ws_code"], "ws_result")

    def modern_correct(ws_code):
        if ws_code == 1:
            ws_result = 100
        elif ws_code == 2:
            ws_result = 200
        else:
            ws_result = 0
        return ws_result
    modern_correct.field_types = {"return": field_types["ws_result"]}

    def modern_buggy(ws_code):
        if ws_code == 1:
            ws_result = 100
        elif ws_code == 2:
            ws_result = 999  # Bug: wrong value
        else:
            ws_result = 0
        return ws_result
    modern_buggy.field_types = {"return": field_types["ws_result"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> EVALUATE <subject> works end-to-end\n")


# --- EVALUATE TRUE -----------------------------------------------------------

EVALUATE_TRUE_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXEVAL.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INC     PIC 9(7)V99.
       01  WS-TAX     PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           EVALUATE TRUE
               WHEN WS-INC <= 10000.00
                   COMPUTE WS-TAX = WS-INC * 10
               WHEN WS-INC <= 50000.00
                   COMPUTE WS-TAX = WS-INC * 20
               WHEN OTHER
                   COMPUTE WS-TAX = WS-INC * 30
           END-EVALUATE.
           STOP RUN.
"""


def test_evaluate_true():
    print("=" * 78)
    print("TEST 2: EVALUATE TRUE / WHEN <condition> (cliff-edge bug)")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(EVALUATE_TRUE_SOURCE, "tax_eval", ["ws_inc"], "ws_tax")

    def modern_correct(ws_inc):
        if ws_inc <= 1000000:
            ws_tax = ws_inc * 10
        elif ws_inc <= 5000000:
            ws_tax = ws_inc * 20
        else:
            ws_tax = ws_inc * 30
        return ws_tax
    modern_correct.field_types = {"return": field_types["ws_tax"]}

    def modern_buggy(ws_inc):
        if ws_inc < 1000000:  # Cliff-edge bug: < instead of <=
            ws_tax = ws_inc * 10
        elif ws_inc <= 5000000:
            ws_tax = ws_inc * 20
        else:
            ws_tax = ws_inc * 30
        return ws_tax
    modern_buggy.field_types = {"return": field_types["ws_tax"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> EVALUATE TRUE works end-to-end\n")


# --- MULTIPLY/DIVIDE ---------------------------------------------------------

MULT_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. MULTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-QTY     PIC 9(5).
       01  WS-PRICE   PIC 9(5)V99.
       01  WS-TOTAL   PIC 9(9)V99.
       PROCEDURE DIVISION.
       P.
           MULTIPLY WS-QTY BY WS-PRICE GIVING WS-TOTAL.
           STOP RUN.
"""


def test_multiply():
    print("=" * 78)
    print("TEST 3: MULTIPLY ... BY ... GIVING")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(MULT_SOURCE, "mult_test", ["ws_qty", "ws_price"], "ws_total")

    def modern_correct(ws_qty, ws_price):
        ws_total = ws_qty * ws_price
        return ws_total
    modern_correct.field_types = {"return": field_types["ws_total"]}

    def modern_buggy(ws_qty, ws_price):
        ws_total = ws_qty * ws_price + 1  # Bug: off-by-one addition
        return ws_total
    modern_buggy.field_types = {"return": field_types["ws_total"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> MULTIPLY works end-to-end\n")


if __name__ == "__main__":
    test_evaluate_subject()
    test_evaluate_true()
    test_multiply()
    print("All three new constructs passed end-to-end.")
