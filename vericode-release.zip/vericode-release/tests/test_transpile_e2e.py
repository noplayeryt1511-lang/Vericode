import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items
from cobol_transpile import transpile_procedure_division, UnsupportedCobolConstruct
from engine import verify, PicField


def build_legacy_fn(cobol_source, function_name, param_names, return_field_py):
    """The complete automated path: COBOL text in, a real Python function
    out -- WITHOUT a human reading or translating the PROCEDURE DIVISION."""
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(cobol_source, params)
    items = extract_data_items(cobol_source)
    field_scales = {it["name"]: it["field"].decimal_digits for it in items if it["field"]}
    field_types = {it["name"]: it["field"] for it in items if it["field"]}

    source = transpile_procedure_division(
        program, function_name, param_names,
        return_field_py=return_field_py, field_decimal_scales=field_scales,
    )
    print("--- Automatically generated Python code ---")
    print(source)

    namespace = {}
    filename = f"<{function_name}>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    exec(compile(source, filename, "exec"), namespace)
    fn = namespace[function_name]
    fn.field_types = {"return": field_types[return_field_py]}
    return fn, field_types


# --- Test 1: plain COMPUTE, no branching -----------------------------------

INVOICE_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. INVTOTAL.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-QTY     PIC 9(4).
       01  WS-PRICE   PIC 9(5)V99.
       01  WS-TOTAL   PIC 9(9)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-TOTAL = WS-QTY * WS-PRICE.
           STOP RUN.
"""


def test_compute_only():
    print("=" * 78)
    print("TEST 1: plain COMPUTE (no branching) -- automatically transpiled")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(INVOICE_SOURCE, "invoice_total", ["ws_qty", "ws_price"], "ws_total")

    def modern_correct(ws_qty, ws_price):
        ws_total = ws_qty * ws_price
        return ws_total
    modern_correct.field_types = {"return": field_types["ws_total"]}

    def modern_buggy(ws_qty, ws_price):
        ws_total = ws_qty * ws_price * 2  # Bug: doubled
        return ws_total
    modern_buggy.field_types = {"return": field_types["ws_total"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> the automatically generated legacy_fn correctly catches the bug\n")


# --- Test 2: nested IF, SHORT field names (works around the cobol-py bug) --

TAX_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INC     PIC 9(7)V99.
       01  WS-TAX     PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           IF WS-INC <= 10000.00
               COMPUTE WS-TAX = WS-INC * 10
           ELSE
               IF WS-INC <= 50000.00
                   COMPUTE WS-TAX = WS-INC * 20
               ELSE
                   COMPUTE WS-TAX = WS-INC * 30
               END-IF
           END-IF.
           STOP RUN.
"""


def test_nested_if_short_names():
    print("=" * 78)
    print("TEST 2: nested IF/ELSE, short field names -- automatically transpiled")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(TAX_SOURCE, "tax_calc", ["ws_inc"], "ws_tax")

    def modern_correct(ws_inc):
        if ws_inc <= 1000000:
            ws_tax = ws_inc * 10
        elif ws_inc <= 5000000:
            ws_tax = ws_inc * 20
        else:
            ws_tax = ws_inc * 30
        return ws_tax
    modern_correct.field_types = {"return": field_types["ws_tax"]}

    def modern_buggy(ws_inc):
        # Cliff-edge bug: < instead of <=
        if ws_inc < 1000000:
            ws_tax = ws_inc * 10
        elif ws_inc <= 5000000:
            ws_tax = ws_inc * 20
        else:
            ws_tax = ws_inc * 30
        return ws_tax
    modern_buggy.field_types = {"return": field_types["ws_tax"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"  Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> the automatically generated legacy_fn correctly catches the cliff-edge bug\n")


# --- Test 3: PERFORM VARYING (loop) -----------------------------------------

SUM_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SUMCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-AMT     PIC 9(5)V99.
       01  WS-TOTAL   PIC 9(9)V99.
       01  WS-IDX     PIC 9(3).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           PERFORM VARYING WS-IDX FROM 1 BY 1 UNTIL WS-IDX > 12
               ADD WS-AMT TO WS-TOTAL
           END-PERFORM.
           STOP RUN.
"""


def test_perform_varying():
    print("=" * 78)
    print("TEST 3: PERFORM VARYING (loop) -- automatically transpiled")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(SUM_SOURCE, "sum_calc", ["ws_amt"], "ws_total")

    def modern_correct(ws_amt):
        ws_total = ws_amt * 12
        return ws_total
    modern_correct.field_types = {"return": field_types["ws_total"]}

    def modern_buggy(ws_amt):
        ws_total = ws_amt * 11  # Bug: only 11 times instead of 12
        return ws_total
    modern_buggy.field_types = {"return": field_types["ws_total"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT (12x amt): {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY (11x amt):   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> the automatically generated legacy_fn (with the loop unrolled) correctly catches the bug\n")


if __name__ == "__main__":
    test_compute_only()
    test_nested_if_short_names()
    test_perform_varying()
    print("All three end-to-end tests passed -- NO human translated the PROCEDURE DIVISION.")
