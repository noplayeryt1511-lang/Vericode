from loop_induction import verify_dual_accumulator_loop, UnsupportedLoopPattern

COBOL_SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-COUNT   PIC 9(3).
       01  WS-TABLE.
           05  WS-ITEM PIC S9(5) OCCURS 100 TIMES.
       01  WS-I       PIC 9(3).
       01  WS-SUM     PIC 9(9).
       01  WS-CNT     PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-SUM.
           MOVE 0 TO WS-CNT.
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > WS-COUNT
               ADD WS-ITEM (WS-I) TO WS-SUM
               ADD 1 TO WS-CNT
           END-PERFORM.
           STOP RUN.
"""


def modern_correct(ws_item, ws_count):
    ws_sum = 0
    ws_cnt = 0
    for i in range(ws_count):
        ws_sum = ws_sum + ws_item[i]
        ws_cnt = ws_cnt + 1
    return ws_sum


def modern_buggy_wrong_sum_coeff(ws_item, ws_count):
    ws_sum = 0
    ws_cnt = 0
    for i in range(ws_count):
        ws_sum = ws_sum + ws_item[i] * 2  # Bug: sum is incorrectly doubled
        ws_cnt = ws_cnt + 1
    return ws_sum


def test_dual_correct():
    print("=" * 78)
    print("TEST 1: sum AND counter tracked simultaneously -- correct")
    print("=" * 78)
    res = verify_dual_accumulator_loop(COBOL_SRC, modern_correct)
    print(f"Result: {res['label']}")
    print(f"COBOL side:   {res['legacy_spec']}")
    print(f"Python side:  {res['modern_spec']}")
    assert res["label"] == "PROVEN"
    print("-> both state variables proven jointly for EVERY length\n")


def test_dual_buggy_wrong_sum_coeff():
    print("=" * 78)
    print("TEST 2: wrong sum coefficient (x2) -- the counter part remains correct")
    print("(must still be caught, since the induction step checks BOTH state variables jointly)")
    print("=" * 78)
    res = verify_dual_accumulator_loop(COBOL_SRC, modern_buggy_wrong_sum_coeff)
    print(f"Result: {res['label']}, counterexample k={res['counterexample_k']}")
    assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    print("-> bug found in the SUM, even though the COUNTER part is correct on its own\n")


if __name__ == "__main__":
    test_dual_correct()
    test_dual_buggy_wrong_sum_coeff()
    print("Both tests for two simultaneous state variables passed.")
