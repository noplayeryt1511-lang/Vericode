"""
External validation #4: AWS CardDemo, the same already-vetted source
as #2/#3 -- a THIRD construct pattern (balance update via ADD plus two
MOVE resets, no STRING, no pure formula).

Source: app/cbl/CBACT04C.cbl, paragraph '1050-UPDATE-ACCOUNT':

    ADD WS-TOTAL-INT TO ACCT-CURR-BAL
    MOVE 0 TO ACCT-CURR-CYC-CREDIT
    MOVE 0 TO ACCT-CURR-CYC-DEBIT

A very common batch-processing idiom: add interest to the balance,
then reset the running cycle totals (current billing period's debit
and credit) to 0 once they have been processed.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify, PicField

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ACCTUPD.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-TOTAL-INT           PIC S9(9)V99.
       01  ACCT-CURR-BAL          PIC S9(9)V99.
       01  ACCT-CURR-CYC-CREDIT   PIC S9(9)V99.
       01  ACCT-CURR-CYC-DEBIT    PIC S9(9)V99.
       PROCEDURE DIVISION.
       P.
           ADD WS-TOTAL-INT TO ACCT-CURR-BAL.
           MOVE 0 TO ACCT-CURR-CYC-CREDIT.
           MOVE 0 TO ACCT-CURR-CYC-DEBIT.
           STOP RUN.
"""


def modern_correct(ws_total_int, acct_curr_bal):
    acct_curr_bal = acct_curr_bal + ws_total_int
    return acct_curr_bal


def modern_buggy_missing_add(ws_total_int, acct_curr_bal):
    # Bug: the interest is never added to the balance -- a realistic
    # mistake when a translator only "sees" the two MOVE statements
    # and overlooks/drops the ADD line.
    return acct_curr_bal


def run():
    print("=" * 78)
    print("External validation #4: AWS CardDemo -- balance update")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "update_account", ["ws_total_int", "acct_curr_bal"], "acct_curr_bal")
    print("Auto-generated reference (from real CardDemo code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_missing_add.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_missing_add, arg_type=z3.IntSort())
    print(f"vs. BUGGY (interest addition missing): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Fourth external source proven successfully -- a third construct "
          "pattern (ADD+MOVE combination) from the same source already licensed "
          "as safe.")


if __name__ == "__main__":
    run()
    print("\nExternal validation #4 passed.")
