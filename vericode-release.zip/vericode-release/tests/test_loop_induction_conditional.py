from loop_induction import verify_accumulator_loop, UnsupportedLoopPattern

COBOL_SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-COUNT   PIC 9(3).
       01  WS-TABLE.
           05  WS-ITEM PIC S9(5) OCCURS 100 TIMES.
       01  WS-I       PIC 9(3).
       01  WS-TOTAL   PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > WS-COUNT
               IF WS-ITEM (WS-I) > 0
                   ADD 1 TO WS-TOTAL
               END-IF
           END-PERFORM.
           STOP RUN.
"""


def modern_correct(ws_item, ws_count):
    ws_total = 0
    for i in range(ws_count):
        if ws_item[i] > 0:
            ws_total = ws_total + 1
    return ws_total


def modern_buggy_boundary(ws_item, ws_count):
    ws_total = 0
    for i in range(ws_count):
        if ws_item[i] >= 0:  # Bug: incorrectly counts the boundary case of 0
            ws_total = ws_total + 1
    return ws_total


def test_conditional_correct():
    print("=" * 78)
    print("TEST 1: conditional accumulation (count only positive values) -- correct")
    print("=" * 78)
    res = verify_accumulator_loop(COBOL_SRC, modern_correct)
    print(f"Result: {res['label']}")
    print(f"COBOL side:  {res['legacy_spec']}")
    print(f"Python side: {res['modern_spec']}")
    assert res["label"] == "PROVEN"
    print("-> proven for EVERY table content and EVERY length\n")


def test_conditional_buggy():
    print("=" * 78)
    print("TEST 2: conditional accumulation -- boundary bug (>= instead of >)")
    print("=" * 78)
    res = verify_accumulator_loop(COBOL_SRC, modern_buggy_boundary)
    print(f"Result: {res['label']}, counterexample k={res['counterexample_k']}")
    assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    print("-> boundary bug (table[k]=0) correctly found, even though it would "
          "rarely surface in concrete test runs\n")


if __name__ == "__main__":
    test_conditional_correct()
    test_conditional_buggy()
    print("Both conditional accumulation tests passed.")
