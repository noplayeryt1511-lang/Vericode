"""
Confirmation, not a new extension: Rust has no try/catch -- the idiomatic
form for "division with a zero guard" is 'if b == 0 { 0 } else { a / b }'
(if as a value expression), which already works through our existing
support for Rust's if-as-expression (see rust_bridge.py, which added the
implicit-return handling), without needing anything new. This test
confirms that end-to-end instead of just asserting it.
"""
import z3
from rust_bridge import transpile_rust_function
from engine import verify, PicField

RUST_SAFE_DIVIDE_SOURCE = """
fn safe_divide(a: i64, b: i64) -> i64 {
    if b == 0 {
        0
    } else {
        a / b
    }
}
"""

RUST_SAFE_DIVIDE_BUGGY = """
fn safe_divide(a: i64, b: i64) -> i64 {
    if b == 0 {
        1
    } else {
        a / b
    }
}
"""


def legacy_safe_divide(a, b):
    if b == 0:
        result = 0
    else:
        result = a // b
    return result


def load(src):
    py = transpile_rust_function(src, "safe_divide", param_names=["a", "b"])
    filename = f"<rust_safe_divide:{id(src)}>"
    import linecache
    linecache.cache[filename] = (len(py), None, py.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py, filename, "exec"), ns)
    return ns["safe_divide"]


def run():
    print("=" * 78)
    print("TEST: Rust -- division with a zero guard, no new code needed (existing if-as-value support)")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    legacy_safe_divide.field_types = {"return": field}

    correct_fn = load(RUST_SAFE_DIVIDE_SOURCE)
    correct_fn.field_types = {"return": field}
    res = verify(legacy_safe_divide, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load(RUST_SAFE_DIVIDE_BUGGY)
    buggy_fn.field_types = {"return": field}
    res = verify(legacy_safe_divide, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (fallback value 1 instead of 0): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Rust reaches parity with Java/C#'s try/catch WITHOUT new code -- "
          "different language, different idiom, same result.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
