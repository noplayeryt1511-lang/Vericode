"""
This covers a scaling bug class in COBOL division (the fourth instance of
the same scaling error class, after multiplication, ADD/SUBTRACT,
comparisons, MOVE, EVALUATE): 'DIVIDE WS-DIVISOR INTO WS-VALUE' (implicit
form, without GIVING) with differing decimal place counts previously
produced 50 instead of the correct 500 -- the earlier multiplication fix
deliberately covered only STAR, leaving SLASH (division) open, which is
now closed here.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-DIVISOR PIC 9(2)V9(1).
       01  WS-VALUE   PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           DIVIDE WS-DIVISOR INTO WS-VALUE.
           STOP RUN.
"""


def modern_correct(ws_divisor, ws_value):
    return ws_value * 10 // ws_divisor


def modern_buggy_no_scale_correction(ws_divisor, ws_value):
    return ws_value // ws_divisor


def run():
    print("=" * 78)
    print("TEST: Division scaling bug (fourth instance of this same bug class)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_divisor", "ws_value"], "ws_value")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_no_scale_correction.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_no_scale_correction, arg_type=z3.IntSort())
    print(f"vs. BUGGY (division without scale correction): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Division scaling bug fixed and proven end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
