from loop_induction import verify_file_processing_loop, UnsupportedLoopPattern
from test_loop_induction_file_accumulator import COBOL_SRC as SINGLE_COBOL, modern_correct as single_correct
from test_loop_induction_file_accumulator import COBOL_SRC_CONDITIONAL as COND_COBOL, modern_conditional_correct as cond_correct
from test_loop_induction_file_nested import COBOL_SRC as NESTED_COBOL, modern_correct as nested_correct
from test_loop_induction_file_dual import COBOL_SRC as DUAL_COBOL, modern_correct as dual_correct


def test_auto_dispatch_finds_each_file_pattern():
    print("=" * 78)
    print("TEST: the unified file-loop dispatcher automatically recognizes all four patterns")
    print("=" * 78)

    res = verify_file_processing_loop(SINGLE_COBOL, single_correct)
    print(f"simple pattern: {res['label']} (recognized pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "file_single"

    res = verify_file_processing_loop(COND_COBOL, cond_correct)
    print(f"conditional pattern: {res['label']} (recognized pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "file_single"

    res = verify_file_processing_loop(NESTED_COBOL, nested_correct)
    print(f"nested pattern: {res['label']} (recognized pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "file_nested"

    res = verify_file_processing_loop(DUAL_COBOL, dual_correct)
    print(f"two-state pattern: {res['label']} (recognized pattern: {res['pattern']})")
    assert res["label"] == "PROVEN"
    assert res["pattern"] == "file_dual"

    print("\n-> all four file-loop patterns recognized automatically and correctly\n")


def test_auto_dispatch_rejects_unsupported():
    print("=" * 78)
    print("TEST: the unified dispatcher cleanly rejects input when NO pattern matches")
    print("=" * 78)
    unrelated_cobol = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           MOVE 1 TO WS-A.
           STOP RUN.
    """

    def unrelated_fn(x):
        return x

    try:
        verify_file_processing_loop(unrelated_cobol, unrelated_fn)
        raise AssertionError("Should have raised UnsupportedLoopPattern!")
    except UnsupportedLoopPattern as e:
        print("Correctly rejected, with details on all the failed attempts:")
        print(str(e)[:200], "...")
    print("-> no pattern is guessed when none actually matches\n")


if __name__ == "__main__":
    test_auto_dispatch_finds_each_file_pattern()
    test_auto_dispatch_rejects_unsupported()
    print("Both tests for the unified file dispatcher passed.")
