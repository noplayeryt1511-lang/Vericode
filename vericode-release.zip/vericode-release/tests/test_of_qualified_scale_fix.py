"""
Proactively found bug (eleventh instance of the same scaling-error class,
following table elements as the tenth): an OF-QUALIFIED field reference
like 'INV-AMOUNT OF WS-INVOICE' transpiles to dot notation
('ws_invoice.inv_amount') -- but field_decimal_scales only indexed the
field name itself ('inv_amount'), not the full path. This is the same
lookup gap as with table elements, now closed here as well using the
same _scale_lookup_key helper (extended to cover the dot-notation case).

Verified directly against the generated source -- a full symbolic
verify() run would raise a separate, unrelated question (how record
objects get wired up correctly for dot notation) that has nothing to
do with this particular finding.
"""
from full_pipeline import build_legacy_fn_from_cobol

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INVOICE.
           05  INV-AMOUNT   PIC 9(4)V9(1).
       01  WS-RATE          PIC 9(2)V99.
       01  WS-RESULT        PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT = INV-AMOUNT OF WS-INVOICE * WS-RATE.
           STOP RUN.
"""


def run():
    print("=" * 78)
    print("TEST: OF-qualified field reference scaling error (eleventh instance of the same class)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["inv_amount", "ws_rate"], "ws_result")
    print(source)

    assert "// 10)" in source, f"scale correction missing from generated code: {source!r}"
    assert "ws_invoice.inv_amount" in source, "OF qualification not present in generated code as expected"
    print("-> scale correction (// 10) is correctly present in the generated code, "
          "even for an OF-qualified field reference used as an operand.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
