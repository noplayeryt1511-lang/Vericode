# -*- coding: utf-8 -*-
"""
OCCURS table test:

  01 MONTHLY-AMOUNTS.
     05 AMOUNT PIC 9(7)V99 COMP-3 OCCURS 12 TIMES.
     05 TOTAL  PIC 9(7)V99 COMP-3.

Sums 12 monthly amounts using a bounded for loop (index = loop variable,
SYMBOLIC -> tests the select/store mechanism with a variable index, not
just with literal indices).
"""

import z3
from engine import verify, PicField, TableField


AMOUNT_FIELD = PicField(total_digits=7, decimal_digits=2)
TOTAL_FIELD = PicField(total_digits=7, decimal_digits=2)

AMOUNTS_TABLE = TableField(element=AMOUNT_FIELD, occurs=12)


def legacy_annual_total(amounts):
    # COBOL: PERFORM VARYING I FROM 1 BY 1 UNTIL I > 12
    #            ADD AMOUNT(I) TO TOTAL
    #        END-PERFORM
    total = 0
    for i in range(12):
        total = total + amounts[i]
    return total


legacy_annual_total.table_types = {"amounts": AMOUNTS_TABLE}
legacy_annual_total.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}


def modern_annual_total_buggy(amounts):
    # Bug: the migration translated TOTAL as i64 (field width forgotten)
    total = 0
    for i in range(12):
        total = total + amounts[i]
    return total


modern_annual_total_buggy.table_types = {"amounts": AMOUNTS_TABLE}
# deliberately NO field_types["return"] -> no truncation -> bug on overflow


def modern_annual_total_correct(amounts):
    total = 0
    for i in range(12):
        total = total + amounts[i]
    return total


modern_annual_total_correct.table_types = {"amounts": AMOUNTS_TABLE}
modern_annual_total_correct.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}


def run_sum_test():
    print("=" * 78)
    print("T1. OCCURS sum: LEGACY (with field width) vs. MODERN without truncation")
    print("-" * 78)
    res = verify(legacy_annual_total, modern_annual_total_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()

    print("=" * 78)
    print("T2. OCCURS sum: LEGACY vs. MODERN correct")
    print("-" * 78)
    res = verify(legacy_annual_total, modern_annual_total_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()


# --- Test 2: constant index + off-by-one bug (typical 0/1-based mistake) --

def legacy_get_q4_amount(amounts):
    # COBOL indices are 1-based: AMOUNT(10) is the 10th value -> Python index 9
    return amounts[9]


legacy_get_q4_amount.table_types = {"amounts": AMOUNTS_TABLE}
legacy_get_q4_amount.field_types = {"return": AMOUNT_FIELD}


def modern_get_q4_amount_buggy(amounts):
    # Bug: the LLM naively carried COBOL's 1-based index "10" straight over
    # as a Python index, instead of converting it to 0-based
    return amounts[10]


modern_get_q4_amount_buggy.table_types = {"amounts": AMOUNTS_TABLE}
modern_get_q4_amount_buggy.field_types = {"return": AMOUNT_FIELD}


def modern_get_q4_amount_correct(amounts):
    return amounts[9]


modern_get_q4_amount_correct.table_types = {"amounts": AMOUNTS_TABLE}
modern_get_q4_amount_correct.field_types = {"return": AMOUNT_FIELD}


def run_index_test():
    print("=" * 78)
    print("T3. Off-by-one: LEGACY (index 9) vs. MODERN (index 10, 1-based index carried over incorrectly)")
    print("-" * 78)
    res = verify(legacy_get_q4_amount, modern_get_q4_amount_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()

    print("=" * 78)
    print("T4. Off-by-one: LEGACY vs. MODERN correct (same index)")
    print("-" * 78)
    res = verify(legacy_get_q4_amount, modern_get_q4_amount_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()


if __name__ == "__main__":
    run_sum_test()
    run_index_test()
