import z3
from full_pipeline import build_legacy_fn_from_cobol
from cobol_transpile import UnsupportedCobolConstruct
from engine import verify

REDEFINES_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. REDEFTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-DATE            PIC 9(8).
       01  WS-DATE-PARTS REDEFINES WS-DATE.
           05  WS-YEAR        PIC 9(4).
           05  WS-MONTH       PIC 9(2).
           05  WS-DAY         PIC 9(2).
       01  WS-RESULT          PIC 9(8).
       01  WS-TEMP1           PIC 9(8).
       01  WS-TEMP2           PIC 9(8).
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-TEMP1 = WS-YEAR * 10000.
           COMPUTE WS-TEMP2 = WS-MONTH * 100.
           MOVE WS-TEMP1 TO WS-RESULT.
           ADD WS-TEMP2 TO WS-RESULT.
           ADD WS-DAY TO WS-RESULT.
           STOP RUN.
"""

WRITE_ATTEMPT_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. REDEFWRITE.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-DATE            PIC 9(8).
       01  WS-DATE-PARTS REDEFINES WS-DATE.
           05  WS-YEAR        PIC 9(4).
           05  WS-MONTH       PIC 9(2).
           05  WS-DAY         PIC 9(2).
       PROCEDURE DIVISION.
       P.
           MOVE 2024 TO WS-YEAR.
           STOP RUN.
"""


def test_redefines_read():
    print("=" * 78)
    print("TEST 1: REDEFINES -- read-side decomposition (date YYYYMMDD -> YY/MM/DD)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        REDEFINES_SOURCE, "redef_reassemble", ["ws_date"], "ws_result")
    print(source)
    # Reassembly should yield the IDENTITY (decompose + recompose)
    assert legacy_fn(20240315) == 20240315
    assert legacy_fn(19991231) == 19991231
    print("-> REDEFINES decomposition + reassembly correctly yields the identity\n")

    def modern_correct(ws_date):
        year = (ws_date // 10000) % 10000
        month = (ws_date // 100) % 100
        day = (ws_date // 1) % 100
        return (year * 10000) + (month * 100) + day
    modern_correct.field_types = dict(legacy_fn.field_types)

    def modern_buggy(ws_date):
        year = (ws_date // 10000) % 10000
        month = (ws_date // 100) % 100
        day = (ws_date // 1) % 100
        return (year * 10000) + (day * 100) + month  # Bug: month/day swapped
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> REDEFINES works end-to-end with a Z3 proof\n")


def test_redefines_write_rejected():
    print("=" * 78)
    print("TEST 2: writing to a REDEFINES field -- must be clearly rejected")
    print("=" * 78)
    try:
        build_legacy_fn_from_cobol(WRITE_ATTEMPT_SOURCE, "redef_write", ["ws_date"], "ws_date")
        raise AssertionError("Should have raised UnsupportedCobolConstruct!")
    except UnsupportedCobolConstruct as e:
        print(f"Correctly rejected: {e}")
    print("-> Writing to a REDEFINES field is cleanly rejected, not guessed\n")


if __name__ == "__main__":
    test_redefines_read()
    test_redefines_write_rejected()
    print("Both REDEFINES tests passed.")
