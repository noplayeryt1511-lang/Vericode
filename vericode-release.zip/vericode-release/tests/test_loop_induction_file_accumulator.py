"""
Fifth pattern in loop_induction.py: 'PERFORM UNTIL <eof> = <value> /
READ <file> AT END MOVE <value> TO <eof> NOT AT END ADD <field> TO
<accumulator> END-READ / END-PERFORM' -- the most common real-world
form of a file-processing loop, encountered in a full-program test
case. Reuses the same, already-proven AccumulatorLoopSpec machinery
as the PERFORM VARYING patterns.
"""
from loop_induction import verify_file_accumulator_loop, UnsupportedLoopPattern

COBOL_SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC.
           05  FD-AMOUNT PIC 9(5).
       WORKING-STORAGE SECTION.
       01  WS-EOF     PIC X VALUE N.
       01  WS-TOTAL   PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           PERFORM UNTIL WS-EOF = Y
               READ MYFILE
                   AT END MOVE Y TO WS-EOF
                   NOT AT END ADD FD-AMOUNT TO WS-TOTAL
               END-READ
           END-PERFORM.
           STOP RUN.
"""


def modern_correct(fd_amount, record_count):
    ws_total = 0
    for i in range(record_count):
        ws_total = ws_total + fd_amount[i]
    return ws_total


def modern_buggy_off_by_scaling(fd_amount, record_count):
    ws_total = 0
    for i in range(record_count):
        ws_total = ws_total + fd_amount[i] * 2
    return ws_total


COBOL_SRC_CONDITIONAL = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC.
           05  FD-AMOUNT PIC 9(5).
       WORKING-STORAGE SECTION.
       01  WS-EOF     PIC X VALUE N.
       01  WS-COUNT   PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-COUNT.
           PERFORM UNTIL WS-EOF = Y
               READ MYFILE
                   AT END MOVE Y TO WS-EOF
                   NOT AT END
                       IF FD-AMOUNT > 100
                           ADD 1 TO WS-COUNT
                       END-IF
               END-READ
           END-PERFORM.
           STOP RUN.
"""


def modern_conditional_correct(fd_amount, record_count):
    ws_count = 0
    for i in range(record_count):
        if fd_amount[i] > 100:
            ws_count = ws_count + 1
    return ws_count


def modern_conditional_buggy_threshold(fd_amount, record_count):
    ws_count = 0
    for i in range(record_count):
        if fd_amount[i] > 50:  # Bug: wrong threshold
            ws_count = ws_count + 1
    return ws_count


def test_file_accumulator_correct():
    print("=" * 78)
    print("TEST 1: file-processing loop -- correct")
    print("=" * 78)
    res = verify_file_accumulator_loop(COBOL_SRC, modern_correct)
    print(f"Result: {res['label']}")
    print(f"COBOL side:   {res['legacy_spec']}")
    print(f"Python side:  {res['modern_spec']}")
    assert res["label"] == "PROVEN"
    print("-> proven for EVERY record count, without the count ever needing to be known\n")


def test_file_accumulator_buggy():
    print("=" * 78)
    print("TEST 2: file-processing loop -- wrong scaling factor")
    print("=" * 78)
    res = verify_file_accumulator_loop(COBOL_SRC, modern_buggy_off_by_scaling)
    print(f"Result: {res['label']}, counterexample record_count={res['counterexample_k']}")
    assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    print("-> the induction step itself catches the error\n")


def test_file_accumulator_conditional():
    print("=" * 78)
    print("TEST 3: CONDITIONAL file-processing loop ('only count above a threshold')")
    print("=" * 78)
    res = verify_file_accumulator_loop(COBOL_SRC_CONDITIONAL, modern_conditional_correct)
    print(f"vs. CORRECT: {res['label']}")
    print(f"COBOL side: {res['legacy_spec']}")
    assert res["label"] == "PROVEN"

    res = verify_file_accumulator_loop(COBOL_SRC_CONDITIONAL, modern_conditional_buggy_threshold)
    print(f"vs. BUGGY (threshold 50 instead of 100): {res['label']}")
    assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    print("-> conditional file accumulation works, and the wrong threshold is caught\n")


if __name__ == "__main__":
    test_file_accumulator_correct()
    test_file_accumulator_buggy()
    test_file_accumulator_conditional()
    print("All three tests for the file-processing loop passed.")
