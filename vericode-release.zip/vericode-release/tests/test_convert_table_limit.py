import z3
from engine import PicField, TableField
from patch_loop import convert_and_verify

SCORE_FIELD = PicField(total_digits=3, decimal_digits=0)
SCORES_TABLE = TableField(element=SCORE_FIELD, occurs=5)
TOTAL_FIELD = PicField(total_digits=4, decimal_digits=0)


def legacy_sum_scores(scores):
    total = 0
    for i in range(5):
        total = total + scores[i]
    return total


legacy_sum_scores.table_types = {"scores": SCORES_TABLE}
legacy_sum_scores.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TABLESUM.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-SCORES.
           05  WS-SCORE       PIC 9(3) OCCURS 5 TIMES.
       01  WS-TOTAL           PIC 9(4).
       01  WS-IDX             PIC 9.

       PROCEDURE DIVISION.
       SUM-SCORES.
           MOVE 0 TO WS-TOTAL.
           PERFORM VARYING WS-IDX FROM 1 BY 1 UNTIL WS-IDX > 5
               ADD WS-SCORE(WS-IDX) TO WS-TOTAL
           END-PERFORM.
           STOP RUN.
"""


def mock_translate(prompt, attempt):
    return '''
def sum_scores(scores):
    total = 0
    for i in range(5):
        total = total + scores[i]
    return total
'''


if __name__ == "__main__":
    result = convert_and_verify(
        legacy_fn=legacy_sum_scores, cobol_source=COBOL_SOURCE,
        function_name="sum_scores", param_names=["scores"],
        llm_fix_fn=mock_translate, arg_type=z3.IntSort(),
        field_types={"return": TOTAL_FIELD},
        table_types={"scores": SCORES_TABLE},
    )
    print("Success:", result.success)
    print("Verify rounds:", result.attempts)
    for h in result.history:
        print(" ", h[0], h[1], "-", h[2][:150] if h[2] else "")
