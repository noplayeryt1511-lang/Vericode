import z3
from full_pipeline import full_auto_pipeline

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. DISCOUNT.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY CUSTREC.
       01  WS-DISCOUNT   PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-DISCOUNT = CUST-BALANCE * 1 // 10.
           STOP RUN.
"""
# (Note: "* 1 // 10" above is just a comment placeholder -- the actual
# COBOL text below uses "* 0.10", which is what actually gets parsed.)
COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. DISCOUNT.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY CUSTREC.
       01  WS-DISCOUNT   PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-DISCOUNT = CUST-BALANCE * 0.10.
           STOP RUN.
"""


def mock_translate(prompt, attempt):
    # Confirm that the LLM sees the fields resolved from the copybook in
    # the prompt -- not just a bare "COPY CUSTREC."
    assert "CUST-BALANCE" in prompt, "Copybook content missing from the translation prompt!"
    assert "COPY CUSTREC" not in prompt or "CUST-BALANCE" in prompt
    return """
def discount(cust_balance):
    ws_discount = cust_balance * 1 // 10
    return ws_discount
"""


def run():
    print("=" * 78)
    print("Copybook through the full pipeline (reference + LLM prompt)")
    print("=" * 78)
    result = full_auto_pipeline(
        COBOL_SOURCE, "discount", ["cust_balance"], "ws_discount",
        llm_fix_fn=mock_translate, arg_type=z3.IntSort(),
        copy_book_dirs=["/tmp/copybook_test"],
    )
    print("Automatically generated legacy reference (with copybook resolved):")
    print(result.legacy_source)
    print("Success:", result.success)
    assert result.success is True
    print("\n-> Copybook correctly resolved, for BOTH sides (reference and LLM).")


if __name__ == "__main__":
    run()
