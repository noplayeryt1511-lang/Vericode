"""
Fourth step toward "hybrid mode" for file I/O (after OPEN/CLOSE as a
no-op, READ INTO as a conditional no-op): WRITE is UNCONDITIONALLY safe
as a no-op -- unlike READ, WRITE only reads FROM a field into a file, it
never writes back. Just like DISPLAY: pure output, with no consequence
for our verification model.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC       PIC X(10).
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(3).
       01  WS-RESULT  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT = WS-A * 2.
           WRITE FD-REC FROM WS-RESULT.
           STOP RUN.
"""


def modern_correct(ws_a):
    return ws_a * 2


def run():
    print("=" * 78)
    print("TEST: WRITE as an unconditionally safe no-op")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_a"], "ws_result")
    print(source)
    modern_correct.field_types = dict(legacy_fn.field_types)
    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"Result: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("\n-> WRITE no longer blocks the surrounding calculation logic.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
