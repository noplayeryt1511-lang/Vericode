import time
import z3
from engine import verify

# Simulates a COBOL remaining-balance payoff calculation: PERFORM UNTIL
# BALANCE <= 0, counting the number of payoff periods. A classic
# unbounded loop -> not symbolically provable -> falls into the
# fallback tier.

TRIGGER = 41_337  # exact value at which the bug is triggered


def legacy_payoff_periods(balance_scaled):
    periods = 0
    b = balance_scaled
    while b > 0:
        b = b - 100
        periods = periods + 1
    return periods


def modern_payoff_periods_buggy(balance_scaled):
    periods = 0
    b = balance_scaled
    while b > 0:
        b = b - 100
        periods = periods + 1
    if balance_scaled == TRIGGER:  # rare bug, only at ONE exact value
        periods = periods + 1
    return periods


if __name__ == "__main__":
    print(f"Range: 0-50000, trigger at exactly {TRIGGER}, budget: 5000 fuzz samples")
    print("(real verify() pipeline, no concolic execution -- exactly what run_patch_loop() uses)")
    print("-" * 78)
    t0 = time.time()
    res = verify(
        legacy_payoff_periods, modern_payoff_periods_buggy,
        arg_type=z3.IntSort(), fuzz_samples=5000,
        input_bounds={"balance_scaled": (0, 50_000)},
    )
    dt = time.time() - t0
    print(f"LABEL:  {res.label.value}")
    print(f"Detail: {res.detail}")
    print(f"Runtime: {dt:.2f}s")
    print()

    # Sanity check: the bug REALLY exists -- direct call with the trigger value
    print(f"Sanity check at balance_scaled={TRIGGER}:")
    print(f"  legacy: {legacy_payoff_periods(TRIGGER)}, modern (buggy): {modern_payoff_periods_buggy(TRIGGER)}")
