"""
OPEN/CLOSE as a no-op -- first, deliberately narrow step towards a
"hybrid mode" for file I/O (see docs/VERIFICATION_GUARANTEES.md, section
4, "Partially supported (hybrid mode)"). Needed to verify a complete
real-world program (examples/CBACT04C.cbl) -- OPEN previously blocked
processing at the very first statement.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE
                  ORGANIZATION IS SEQUENTIAL.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  MYFILE-REC          PIC X(10).
       WORKING-STORAGE SECTION.
       01  WS-A                PIC 9(3).
       01  WS-RESULT           PIC 9(3).
       PROCEDURE DIVISION.
       P.
           OPEN INPUT MYFILE.
           COMPUTE WS-RESULT = WS-A * 2.
           CLOSE MYFILE.
           STOP RUN.
"""


def modern_correct(ws_a):
    return ws_a * 2


def run():
    print("=" * 78)
    print("TEST: OPEN/CLOSE as a no-op -- the surrounding computation logic remains provable")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_a"], "ws_result")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"Result: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("\n-> OPEN/CLOSE no longer block the surrounding computation logic.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
