import z3
from cobol_extract import extract_data_items
from engine import verify, PicField

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SHIPCOST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-WEIGHT-KG       PIC 9(5)V99.
       01  WS-DISTANCE-KM     PIC 9(5).
       01  WS-BASE-RATE       PIC 9(3)V99 VALUE 2.50.
       01  WS-SHIPPING-COST   PIC 9(7)V99.

       PROCEDURE DIVISION.
       CALCULATE-SHIPPING.
           IF WS-WEIGHT-KG <= 5.00
               COMPUTE WS-SHIPPING-COST =
                   WS-BASE-RATE * WS-DISTANCE-KM
           ELSE
               IF WS-WEIGHT-KG <= 20.00
                   COMPUTE WS-SHIPPING-COST =
                       WS-BASE-RATE * WS-DISTANCE-KM * 1.5
               ELSE
                   COMPUTE WS-SHIPPING-COST =
                       WS-BASE-RATE * WS-DISTANCE-KM * 2
               END-IF
           END-IF.
           STOP RUN.
"""

if __name__ == "__main__":
    print("=" * 78)
    print("1. Automatically extracted fields (real parser, NO manual transcription)")
    print("-" * 78)
    items = extract_data_items(COBOL_SOURCE)
    for it in items:
        print(f"  {it['cobol_name']:20s} -> {it['name']:20s} {it['field']}")
    print()

    # Use the correctly extracted widths for weight/distance/cost --
    # no more guessing them by hand.
    fields = {it["name"]: it["field"] for it in items if it["field"]}

    print("=" * 78)
    print("2. Legacy reference using the AUTOMATICALLY extracted field widths")
    print("-" * 78)

    def legacy_shipping_cost(weight_kg_scaled, distance_km):
        base_rate_scaled = 250  # 2.50, taken directly from the VALUE clause in the COBOL
        if weight_kg_scaled <= 500:
            cost = base_rate_scaled * distance_km
        elif weight_kg_scaled <= 2000:
            cost = base_rate_scaled * distance_km * 3 // 2
        else:
            cost = base_rate_scaled * distance_km * 2
        return cost

    legacy_shipping_cost.field_types = {
        "weight_kg_scaled": fields["ws_weight_kg"],
        "distance_km": fields["ws_distance_km"],
        "return": fields["ws_shipping_cost"],
    }
    print(f"  weight_kg_scaled field width: {legacy_shipping_cost.field_types['weight_kg_scaled']}")
    print(f"  return field width:           {legacy_shipping_cost.field_types['return']}")
    print()

    print("=" * 78)
    print("3. Verification against a correct translation")
    print("-" * 78)

    def modern_shipping_cost_correct(weight_kg_scaled, distance_km):
        base_rate_scaled = 250
        if weight_kg_scaled <= 500:
            cost = base_rate_scaled * distance_km
        elif weight_kg_scaled <= 2000:
            cost = base_rate_scaled * distance_km * 3 // 2
        else:
            cost = base_rate_scaled * distance_km * 2
        return cost

    modern_shipping_cost_correct.field_types = {"return": fields["ws_shipping_cost"]}

    res = verify(legacy_shipping_cost, modern_shipping_cost_correct, arg_type=z3.IntSort())
    print(f"  LABEL: {res.label.value}")
