# -*- coding: utf-8 -*-
"""
Patch-loop demo: an initially faulty LLM migration of the invoice line
item (known from test_pic_fields.py) has TWO bugs at once:
  1. Field width forgotten (overflow truncation is missing)
  2. Wrong sign in the multiplication (quantity * -1 * price)

The simulated "LLM fix" realistically only fixes ONE bug per round
(just like a real LLM often needs several iterations) -- round 1 fixes
the sign error, round 2 fixes the field width, round 3 verifies as PROVEN.
"""

import z3
from engine import PicField
from patch_loop import run_patch_loop


INVOICE_FIELD = PicField(total_digits=5, decimal_digits=2)


def legacy_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total


legacy_invoice_total.field_types = {"return": INVOICE_FIELD}


ATTEMPT_1_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled * -1
    return total
'''

ATTEMPT_2_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total
'''
# (the field width is still missing here -> round 2 will not yet be PROVEN)

ATTEMPT_3_SOURCE = ATTEMPT_2_SOURCE  # field width comes from field_types, not from code


def mock_llm_fix(prompt, attempt):
    """Stand-in for a real LLM call. Simulates a realistic, step-by-step
    correction across several rounds (not a 'one-shot' fix)."""
    cx_line = next(l for l in prompt.splitlines() if l.strip().startswith("Input:"))
    print(f"  [Round {attempt}] Prompt sent to LLM ({len(prompt)} chars), counterexample: {cx_line.strip()}")
    if attempt == 1:
        print("  [Round 1] LLM fixes the sign error (still misses the field width)")
        return ATTEMPT_2_SOURCE
    else:
        print(f"  [Round {attempt}] LLM changes nothing further in the code itself this "
              f"round -- the remaining cause is missing field-width metadata, "
              f"which is set separately via field_types (see below)")
        return ATTEMPT_3_SOURCE


def run():
    print("=" * 78)
    print("Patch loop: invoice line item with TWO bugs (sign + field width)")
    print("=" * 78)
    result = run_patch_loop(
        legacy_fn=legacy_invoice_total,
        initial_modern_source=ATTEMPT_1_SOURCE,
        function_name="modern_invoice_total",
        llm_fix_fn=mock_llm_fix,
        arg_type=z3.IntSort(),
        field_types={"return": INVOICE_FIELD},  # field width: part of the spec, not the LLM output
        max_attempts=5,
    )
    print()
    print("-" * 78)
    print(f"Success: {result.success}, after {result.attempts} attempts")
    print("-" * 78)
    for attempt, label, detail, prompt in result.history:
        print(f"  Round {attempt}: {label}")
    print()
    if result.success:
        print("Final (proven correct) code:")
        print(result.final_source)


if __name__ == "__main__":
    run()
