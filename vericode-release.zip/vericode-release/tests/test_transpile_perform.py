import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items
from cobol_transpile import transpile_procedure_division
from engine import verify


def build_legacy_fn(cobol_source, function_name, param_names, return_field_py):
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(cobol_source, params)
    items = extract_data_items(cobol_source)
    field_scales = {it["name"]: it["field"].decimal_digits for it in items if it["field"]}
    field_types = {it["name"]: it["field"] for it in items if it["field"]}
    source = transpile_procedure_division(
        program, function_name, param_names,
        return_field_py=return_field_py, field_decimal_scales=field_scales,
    )
    print(source)
    namespace = {}
    filename = f"<{function_name}>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    exec(compile(source, filename, "exec"), namespace)
    fn = namespace[function_name]
    fn.field_types = {"return": field_types[return_field_py]}
    return fn, field_types


PERFORM_N_TIMES_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PERFN.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-AMT     PIC 9(5)V99.
       01  WS-TOTAL   PIC 9(9)V99.
       PROCEDURE DIVISION.
       MAIN-PARA.
           MOVE 0 TO WS-TOTAL.
           PERFORM ADD-AMOUNT 12 TIMES.
           STOP RUN.
       ADD-AMOUNT.
           ADD WS-AMT TO WS-TOTAL.
"""


def test_perform_n_times():
    print("=" * 78)
    print("TEST 1: PERFORM <paragraph> N TIMES (12x monthly amount)")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(PERFORM_N_TIMES_SOURCE, "perf_n_times", ["ws_amt"], "ws_total")

    def modern_correct(ws_amt):
        ws_total = ws_amt * 12
        return ws_total
    modern_correct.field_types = {"return": field_types["ws_total"]}

    def modern_buggy(ws_amt):
        ws_total = ws_amt * 11  # Bug: only 11 times instead of 12
        return ws_total
    modern_buggy.field_types = {"return": field_types["ws_total"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"  vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"  vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("  -> PERFORM <paragraph> N TIMES works end-to-end\n")


PERFORM_UNTIL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PERFU.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-BALANCE     PIC 9(9)V99.
       01  WS-PERIODS     PIC 9(5).
       PROCEDURE DIVISION.
       MAIN-PARA.
           MOVE 0 TO WS-PERIODS.
           PERFORM PAY-DOWN UNTIL WS-BALANCE <= 0.
           STOP RUN.
       PAY-DOWN.
           SUBTRACT 100 FROM WS-BALANCE.
           ADD 1 TO WS-PERIODS.
"""


def test_perform_until():
    print("=" * 78)
    print("TEST 2: PERFORM <paragraph> UNTIL <condition> (data-dependent loop)")
    print("=" * 78)
    legacy_fn, field_types = build_legacy_fn(PERFORM_UNTIL_SOURCE, "perf_until", ["ws_balance"], "ws_periods")

    def modern_correct(ws_balance):
        periods = 0
        b = ws_balance
        while not (b <= 0):
            b = b - 10000  # SUBTRACT 100 FROM WS-BALANCE -> 100.00, scaled x100 = 10000
            periods = periods + 1
        return periods
    modern_correct.field_types = {"return": field_types["ws_periods"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort(),
                  input_bounds={"ws_balance": (0, 100_000)}, fuzz_samples=2000)
    print(f"  vs. CORRECT: {res.label.value}")
    print(f"  Detail: {res.detail}")
    # PERFORM UNTIL becomes a 'while' loop -> not symbolically provable -> fallback tier
    assert res.label.value in ("PROVEN", "VERIFIED-BY-TESTING")
    print("  -> PERFORM <paragraph> UNTIL correctly produces a 'while' loop "
          "(lands in the fallback tier, as expected)\n")


if __name__ == "__main__":
    test_perform_n_times()
    test_perform_until()
    print("Both PERFORM-paragraph-call variants passed end-to-end.")
