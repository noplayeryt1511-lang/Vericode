import z3
from full_pipeline import build_legacy_fn_from_cobol
from cobol_expr import cobol_condition_to_python
from engine import verify

COBOL_NO_IS_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A        PIC 9(3).
       01  WS-RESULT   PIC 9(1).
       PROCEDURE DIVISION.
       P.
           IF WS-A EQUAL TO 10
               MOVE 1 TO WS-RESULT
           ELSE
               MOVE 0 TO WS-RESULT
           END-IF.
           STOP RUN.
"""


def modern_correct_eq(ws_a):
    if ws_a == 10:
        r = 1
    else:
        r = 0
    return r


def test_abbreviated_word_form_not_reachable_via_cobol_py():
    """Notable finding, not just a fix: the abbreviated word forms
    (EQ/NE/LT/GT/LE/GE as their own reserved words, not as symbols)
    are rejected by cobol-py itself at the grammar level, for all
    six variants -- before our own code is even involved.
    The corresponding fix in cobol_expr.py (EQ/NE/... as keywords)
    is therefore correctly implemented and can be demonstrated directly
    here (bypassing cobol-py), but is practically unreachable through the
    real COBOL pipeline (build_legacy_fn_from_cobol). This is a
    library boundary, not a gap we can close."""
    print("=" * 78)
    print("TEST 1: abbreviated word form 'GE' -- directly via cobol_expr.py, NOT via cobol-py")
    print("(cobol-py already rejects all six word-form abbreviations at the grammar level)")
    print("=" * 78)
    result = cobol_condition_to_python("WS-A GE 10")
    print(f"'WS-A GE 10' -> {result}")
    assert result == "(ws_a >= 10)"
    result2 = cobol_condition_to_python("WS-A IS NOT EQ 10")
    print(f"'WS-A IS NOT EQ 10' -> {result2}")
    assert result2 == "(ws_a != 10)"
    print("-> fix is correct, but not reachable via the real pipeline (cobol-py boundary)\n")


def test_equal_to_without_is():
    print("=" * 78)
    print("TEST 2: 'EQUAL TO' without a preceding 'IS' -- real NIST-derived case (accepted by cobol-py)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_NO_IS_SOURCE, "x", ["ws_a"], "ws_result")
    print(source)
    modern_correct_eq.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct_eq, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> 'EQUAL TO' without 'IS' works end-to-end\n")


if __name__ == "__main__":
    test_abbreviated_word_form_not_reachable_via_cobol_py()
    test_equal_to_without_is()
    print("Both tests passed.")
