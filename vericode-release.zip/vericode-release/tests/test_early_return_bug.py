import z3
from engine import verify, PicField


def legacy_sign(a):
    if a >= 0:
        return 1
    return -1


legacy_sign.field_types = {"a": PicField(5, 0, signed=True), "return": PicField(1, 0, signed=True)}


def modern_correct_early_return(a):
    # Early return in an if branch, followed by a second return outside
    # it -- a VERY common Python pattern. Before this fix (see engine.py:
    # self.has_returned), this was INCORRECTLY FLAGGED, because the FIRST
    # processed return was unconditionally taken and then overwritten by
    # the SECOND return, regardless of its condition.
    if a >= 0:
        return 1
    return -1


modern_correct_early_return.field_types = dict(legacy_sign.field_types)


def modern_buggy_early_return(a):
    if a >= 0:
        return 1
    return 1  # Bug: should be -1


modern_buggy_early_return.field_types = dict(legacy_sign.field_types)


if __name__ == "__main__":
    res = verify(legacy_sign, modern_correct_early_return, arg_type=z3.IntSort())
    print("vs. CORRECT (early return):", res.label.value)
    assert res.label.value == "PROVEN", (
        "REGRESSION: early return in an if branch is being handled incorrectly again!"
    )

    res = verify(legacy_sign, modern_buggy_early_return, arg_type=z3.IntSort())
    print("vs. BUGGY (early return):", res.label.value)
    if res.counterexample:
        print("Counterexample:", {k: v.as_long() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("Early-return bug remains fixed.")
