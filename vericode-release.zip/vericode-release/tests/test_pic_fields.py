# -*- coding: utf-8 -*-
"""
Follow-up to path 1.1 (integrated): the same overflow scenario as
comp3_overflow.py, but now handled through the generic SymbolicEvaluator
plus PicField annotations instead of hand-written Z3 expressions ->
this now works for ARBITRARY function pairs, not just one special case.
"""

import z3
from engine import verify, PicField, Label


# PIC 9(5)V99 COMP-3: 5 total digits, 2 decimal digits, scaled x100
INVOICE_FIELD = PicField(total_digits=5, decimal_digits=2)
# Quantity: PIC 9(4) COMP-3, no decimal digits, unsigned -> 0..9999
QUANTITY_FIELD = PicField(total_digits=4, decimal_digits=0)


def legacy_invoice_total(quantity, unit_price_scaled):
    # COBOL: COMPUTE TOTAL = QUANTITY * UNIT-PRICE  (TOTAL is PIC 9(5)V99 COMP-3)
    total = quantity * unit_price_scaled
    return total


# Now we also declare the PARAMETERS themselves as PIC fields -- that's the
# difference from before (there, only the local 'total' variable was typed).
# The input_bounds are now derived from this automatically, with no need
# for a manual input_bounds={...}.
legacy_invoice_total.field_types = {
    "quantity": QUANTITY_FIELD,
    "unit_price_scaled": INVOICE_FIELD,
    "total": INVOICE_FIELD,
    "return": INVOICE_FIELD,
}


def modern_invoice_total_buggy(quantity, unit_price_scaled):
    # A "faithful" migration to i64 -- but the field width was forgotten during translation
    total = quantity * unit_price_scaled
    return total


# Deliberately only the parameter fields are declared (those really do come
# from the DB / legacy data format at the same width), but NOT 'total' ->
# that's exactly the bug: the result value is no longer truncated to 5 digits.
modern_invoice_total_buggy.field_types = {
    "quantity": QUANTITY_FIELD,
    "unit_price_scaled": INVOICE_FIELD,
}


def modern_invoice_total_correct(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total


modern_invoice_total_correct.field_types = {
    "quantity": QUANTITY_FIELD,
    "unit_price_scaled": INVOICE_FIELD,
    "total": INVOICE_FIELD,
    "return": INVOICE_FIELD,
}


# Additional example: a TWO-STAGE calculation (discount then tax), to show
# that truncation is applied correctly at every intermediate step, not just at the end
DISCOUNT_FIELD = PicField(total_digits=5, decimal_digits=2)


def legacy_two_stage(quantity, unit_price_scaled, discount_pct_scaled):
    subtotal = quantity * unit_price_scaled
    discount = subtotal * discount_pct_scaled / 10000
    total = subtotal - discount
    return total


legacy_two_stage.field_types = {
    "quantity": QUANTITY_FIELD,
    "unit_price_scaled": INVOICE_FIELD,
    "subtotal": DISCOUNT_FIELD,
    "total": DISCOUNT_FIELD,
    "return": DISCOUNT_FIELD,
}


def modern_two_stage_correct(quantity, unit_price_scaled, discount_pct_scaled):
    subtotal = quantity * unit_price_scaled
    discount = subtotal * discount_pct_scaled / 10000
    total = subtotal - discount
    return total


modern_two_stage_correct.field_types = {
    "quantity": QUANTITY_FIELD,
    "unit_price_scaled": INVOICE_FIELD,
    "subtotal": DISCOUNT_FIELD,
    "total": DISCOUNT_FIELD,
    "return": DISCOUNT_FIELD,
}


def run():
    print("=" * 78)
    print("1. Invoice line item, PARAMETERS declared as PIC fields, NO input_bounds passed")
    print("   -> bounds should now be derived fully automatically from QUANTITY_FIELD/INVOICE_FIELD")
    print("-" * 78)
    res = verify(
        legacy_invoice_total, modern_invoice_total_buggy,
        arg_type=z3.IntSort(),
    )
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        q = res.counterexample["quantity"].as_long()
        p = res.counterexample["unit_price_scaled"].as_long()
        print(f"  Counterexample: quantity={q}, unit_price={p/100:.2f}")
        print(f"    legacy returns   = {(q*p) % 100_000 / 100:.2f}")
        print(f"    modern (buggy) returns = {(q*p) / 100:.2f}")
    print()

    print("=" * 78)
    print("2. Invoice line item: LEGACY vs. MODERN with correct field width, also without manual bounds")
    print("-" * 78)
    res = verify(
        legacy_invoice_total, modern_invoice_total_correct,
        arg_type=z3.IntSort(),
    )
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()

    print("=" * 78)
    print("3. Two-stage discount+total calculation -- quantity/unit_price automatic, discount_pct manual")
    print("   (discount_pct is a plain percentage parameter, not its own PIC field)")
    print("-" * 78)
    res = verify(
        legacy_two_stage, modern_two_stage_correct,
        arg_type=z3.IntSort(),
        input_bounds={"discount_pct_scaled": (0, 5_000)},  # 0-50%, only this one parameter set manually
    )
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()

    print("=" * 78)
    print("4. Mismatch warning: quantity has a DIFFERENT field width in legacy vs. modern")
    print("-" * 78)
    modern_invoice_total_correct.field_types = {
        **modern_invoice_total_correct.field_types,
        "quantity": PicField(total_digits=6, decimal_digits=0),  # intentionally different from QUANTITY_FIELD
    }
    res = verify(
        legacy_invoice_total, modern_invoice_total_correct,
        arg_type=z3.IntSort(),
    )
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    # reset for any subsequent runs
    modern_invoice_total_correct.field_types["quantity"] = QUANTITY_FIELD
    print()


if __name__ == "__main__":
    run()
