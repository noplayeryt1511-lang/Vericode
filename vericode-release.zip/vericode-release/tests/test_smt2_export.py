import z3
from engine import verify
from test_case_study_tax import legacy_tax_bracket, modern_tax_bracket_correct, modern_tax_bracket_buggy


def independent_audit(smt2_text, expected_z3_result):
    """Simulates an independent auditor: takes ONLY the SMT-LIB2 text
    (no access to our Python code) and checks with a COMPLETELY FRESH
    Z3 solver whether the result matches."""
    fresh_solver = z3.Solver()
    fresh_solver.from_string(smt2_text)
    result = fresh_solver.check()
    assert result == expected_z3_result, f"AUDIT FAILED: expected {expected_z3_result}, got {result}"
    return result


def run():
    print("=" * 78)
    print("1. PROVEN case: export + independent verification")
    print("-" * 78)
    res = verify(legacy_tax_bracket, modern_tax_bracket_correct, arg_type=z3.IntSort(), export_smt2=True)
    print(f"  LABEL: {res.label.value}")
    print(f"  SMT2 export present: {res.smt2 is not None}, length: {len(res.smt2)} characters")
    audit_result = independent_audit(res.smt2, z3.unsat)
    print(f"  Independent verification (fresh solver, SMT2 text only): {audit_result}")
    print("  -> matches: PROVEN is independently verifiable\n")

    print("=" * 78)
    print("2. FLAGGED case: export + independent verification")
    print("-" * 78)
    res = verify(legacy_tax_bracket, modern_tax_bracket_buggy, arg_type=z3.IntSort(), export_smt2=True)
    print(f"  LABEL: {res.label.value}")
    print(f"  SMT2 export present: {res.smt2 is not None}, length: {len(res.smt2)} characters")
    audit_result = independent_audit(res.smt2, z3.sat)
    print(f"  Independent verification (fresh solver, SMT2 text only): {audit_result}")
    print("  -> matches: FLAGGED is independently verifiable\n")

    print("=" * 78)
    print("3. Excerpt of the exported SMT2 text (for inspection)")
    print("-" * 78)
    print("\n".join(res.smt2.splitlines()[:15]))
    print("...")


if __name__ == "__main__":
    run()
