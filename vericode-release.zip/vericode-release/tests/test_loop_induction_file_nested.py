"""
Sixth pattern in loop_induction.py: nested file-processing loop --
each record itself contains a small, fixed table (e.g. 3 values per
row) -- structurally identical to the already-solved "table of
records with a fixed inner bound" pattern, now for files instead of
WORKING-STORAGE tables.
"""
from loop_induction import verify_file_nested_accumulator_loop, UnsupportedLoopPattern

COBOL_SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC.
           05  FD-ITEM PIC 9(5) OCCURS 3 TIMES.
       WORKING-STORAGE SECTION.
       01  WS-EOF     PIC X VALUE N.
       01  WS-J       PIC 9(2).
       01  WS-TOTAL   PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           PERFORM UNTIL WS-EOF = Y
               READ MYFILE
                   AT END MOVE Y TO WS-EOF
                   NOT AT END
                       PERFORM VARYING WS-J FROM 1 BY 1 UNTIL WS-J > 3
                           ADD FD-ITEM (WS-J) TO WS-TOTAL
                       END-PERFORM
               END-READ
           END-PERFORM.
           STOP RUN.
"""


def modern_correct(fd_item, record_count):
    ws_total = 0
    for i in range(record_count):
        for j in range(3):
            ws_total = ws_total + fd_item[i][j]
    return ws_total


def modern_buggy_wrong_inner_bound(fd_item, record_count):
    ws_total = 0
    for i in range(record_count):
        for j in range(2):
            ws_total = ws_total + fd_item[i][j]
    return ws_total


def test_file_nested_correct():
    print("=" * 78)
    print("TEST 1: nested file-processing loop -- correct")
    print("=" * 78)
    res = verify_file_nested_accumulator_loop(COBOL_SRC, modern_correct)
    print(f"Result: {res['label']}")
    print(f"COBOL side:   {res['legacy_spec']}")
    assert res["label"] == "PROVEN"
    print("-> proven for EVERY record count, fixed column count correctly unrolled\n")


def test_file_nested_buggy():
    print("=" * 78)
    print("TEST 2: nested file-processing loop -- wrong inner bound")
    print("=" * 78)
    try:
        res = verify_file_nested_accumulator_loop(COBOL_SRC, modern_buggy_wrong_inner_bound)
        print(f"Result: {res['label']}")
        assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    except UnsupportedLoopPattern as e:
        print(f"Correctly rejected (differing inner bounds): {e}")
    print("-> the wrong inner bound is caught\n")


if __name__ == "__main__":
    test_file_nested_correct()
    test_file_nested_buggy()
    print("Both tests for the nested file-processing loop passed.")
