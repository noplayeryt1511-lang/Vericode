from loop_induction import verify_accumulator_loop, UnsupportedLoopPattern

COBOL_SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-COUNT   PIC 9(3).
       01  WS-TABLE.
           05  WS-ITEM PIC 9(5) OCCURS 100 TIMES.
       01  WS-I       PIC 9(3).
       01  WS-TOTAL   PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > WS-COUNT
               ADD WS-ITEM (WS-I) TO WS-TOTAL
           END-PERFORM.
           STOP RUN.
"""


def modern_correct(ws_item, ws_count):
    ws_total = 0
    for i in range(ws_count):
        ws_total = ws_total + ws_item[i]
    return ws_total


def modern_buggy(ws_item, ws_count):
    ws_total = 0
    for i in range(ws_count):
        ws_total = ws_total + ws_item[i] * 2  # Bug: incorrectly doubles the value
    return ws_total


def modern_no_init(ws_item, ws_count):
    # No 'ws_total = 0' before the loop -- must be rejected
    for i in range(ws_count):
        ws_total = ws_total + ws_item[i]
    return ws_total


def test_correct():
    print("=" * 78)
    print("TEST 1: correct translation -- must be PROVEN (for ALL n, not just samples)")
    print("=" * 78)
    res = verify_accumulator_loop(COBOL_SRC, modern_correct)
    print(f"Result: {res['label']}")
    print(f"COBOL side:  {res['legacy_spec']}")
    print(f"Python side: {res['modern_spec']}")
    assert res["label"] == "PROVEN"
    print("-> proven for EVERY table length n, not just individual test values\n")


def test_buggy():
    print("=" * 78)
    print("TEST 2: incorrect scale factor (x2) -- must be FLAGGED, with a counterexample")
    print("=" * 78)
    res = verify_accumulator_loop(COBOL_SRC, modern_buggy)
    print(f"Result: {res['label']}, counterexample k={res['counterexample_k']}")
    assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    print("-> bug correctly found, without unrolling the loop for a fixed length\n")


def test_no_init_rejected():
    print("=" * 78)
    print("TEST 3: missing initialization -- must be clearly rejected, not guessed at")
    print("=" * 78)
    try:
        verify_accumulator_loop(COBOL_SRC, modern_no_init)
        raise AssertionError("Should have raised UnsupportedLoopPattern!")
    except UnsupportedLoopPattern as e:
        print(f"Correctly rejected: {e}")
    print("-> a missing base-case proof is cleanly rejected\n")


if __name__ == "__main__":
    test_correct()
    test_buggy()
    test_no_init_rejected()
    print("All three inductive accumulator verification tests passed.")
