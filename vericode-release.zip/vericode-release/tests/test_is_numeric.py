import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

PICX_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. NUMTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INPUT   PIC X(4).
       01  WS-VALID   PIC 9(1).
       PROCEDURE DIVISION.
       P.
           IF WS-INPUT IS NUMERIC
               MOVE 1 TO WS-VALID
           ELSE
               MOVE 0 TO WS-VALID
           END-IF.
           STOP RUN.
"""

PICFIELD_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. NUMTEST2.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-NUM     PIC 9(5).
       01  WS-VALID   PIC 9(1).
       PROCEDURE DIVISION.
       P.
           IF WS-NUM IS NUMERIC
               MOVE 1 TO WS-VALID
           ELSE
               MOVE 0 TO WS-VALID
           END-IF.
           STOP RUN.
"""


def is_numeric_string(s):
    return s.isdigit()


def modern_correct_picx(ws_input):
    return 1 if is_numeric_string(ws_input) else 0


def test_is_numeric_picx():
    print("=" * 78)
    print("TEST 1: IS NUMERIC on PicX -- actual character check")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(PICX_SOURCE, "num_test", ["ws_input"], "ws_valid")
    print(source)

    modern_correct_picx.field_types = dict(legacy_fn.field_types)

    def modern_buggy(ws_input):
        return 1  # Bug: doesn't check anything, always says "valid"
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct_picx, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> IS NUMERIC on PicX works end-to-end (actual regex check)\n")


def test_is_numeric_picfield():
    print("=" * 78)
    print("TEST 2: IS NUMERIC on PicField -- trivially TRUE (our model only allows numbers)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(PICFIELD_SOURCE, "num_test2", ["ws_num"], "ws_valid")
    print(source)

    def modern_correct(ws_num):
        return 1
    modern_correct.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT (always 1): {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> IS NUMERIC on PicField correctly resolves to 'always true'\n")


if __name__ == "__main__":
    test_is_numeric_picx()
    test_is_numeric_picfield()
    print("Both IS NUMERIC tests passed.")
