"""
External validation #10: SIXTH entirely new project --
DoHITB/COBOL-Examples (GPL-3.0, an academic COBOL example repo,
public on GitHub).

Source: exm11.cbl -- digit extraction via repeated division:

    DIVIDE DIGITOS INTO BASE
        GIVING TEMPORAL REMAINDER RESTO.

Known limitation covered by this test: `DIVIDE ... GIVING ... REMAINDER
...` (quotient AND remainder in a single statement) was previously not
supported at all -- only the simple GIVING form without REMAINDER. Now
implemented, deliberately scoped tightly to plain integers (scale 0).
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  BASE-VAL   PIC 9(9).
       01  DIGITOS    PIC 9(4).
       01  TEMPORAL   PIC 9(9).
       01  RESTO      PIC 9(4).
       PROCEDURE DIVISION.
       P.
           DIVIDE DIGITOS INTO BASE-VAL
               GIVING TEMPORAL REMAINDER RESTO.
           STOP RUN.
"""


def modern_correct(base_val, digitos):
    temporal = base_val // digitos
    resto = base_val % digitos
    return resto


def modern_buggy_swapped(base_val, digitos):
    temporal = base_val % digitos
    resto = base_val // digitos
    return resto


def run():
    print("=" * 78)
    print("External validation #10: sixth project -- division with remainder")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["base_val", "digitos"], "resto")
    print("Auto-generated reference (from real COBOL code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_swapped.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_swapped, arg_type=z3.IntSort())
    print(f"vs. BUGGY (quotient/remainder swapped): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Tenth external source proven, sixth source project.")


if __name__ == "__main__":
    run()
    print("\nExternal validation #10 passed.")
