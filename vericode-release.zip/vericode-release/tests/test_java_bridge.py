import linecache
import z3
from java_bridge import transpile_java_method, UnsupportedJavaConstruct
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify, PicField

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INC     PIC 9(7)V99.
       01  WS-TAX     PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           IF WS-INC <= 10000.00
               COMPUTE WS-TAX = WS-INC * 10
           ELSE
               IF WS-INC <= 50000.00
                   COMPUTE WS-TAX = WS-INC * 20
               ELSE
                   COMPUTE WS-TAX = WS-INC * 30
               END-IF
           END-IF.
           STOP RUN.
"""

JAVA_CORRECT = """
public class TaxCalc {
    public static int taxCalc(int wsInc) {
        int wsTax;
        if (wsInc <= 1000000) {
            wsTax = wsInc * 10;
        } else if (wsInc <= 5000000) {
            wsTax = wsInc * 20;
        } else {
            wsTax = wsInc * 30;
        }
        return wsTax;
    }
}
"""

# Cliff-edge bug: < instead of <= at the first boundary -- exactly the
# pattern seen repeatedly in Python translations, reproduced here in Java
JAVA_BUGGY = """
public class TaxCalc {
    public static int taxCalc(int wsInc) {
        int wsTax;
        if (wsInc < 1000000) {
            wsTax = wsInc * 10;
        } else if (wsInc <= 5000000) {
            wsTax = wsInc * 20;
        } else {
            wsTax = wsInc * 30;
        }
        return wsTax;
    }
}
"""


def load_java_as_fn(java_source, method_name, field_types, param_names):
    py_source = transpile_java_method(java_source, method_name, param_names=param_names)
    filename = f"<java:{method_name}>"
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    fn = ns[method_name]
    fn.field_types = dict(field_types)
    return fn


def run():
    print("=" * 78)
    print("Java as the verification target: auto-generated COBOL reference vs. REAL Java")
    print("=" * 78)
    legacy_fn, legacy_source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "tax_calc", ["ws_inc"], "ws_tax")
    print("Auto-generated legacy reference (from COBOL):")
    print(legacy_source)

    java_correct_fn = load_java_as_fn(JAVA_CORRECT, "taxCalc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    print("Python source transpiled from Java (for verification only, NOT the target artifact):")
    print(transpile_java_method(JAVA_CORRECT, "taxCalc", param_names=["ws_inc"]))

    res = verify(legacy_fn, java_correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT Java: {res.label.value}")
    assert res.label.value == "PROVEN"

    java_buggy_fn = load_java_as_fn(JAVA_BUGGY, "taxCalc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    res = verify(legacy_fn, java_buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY Java: {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Engine unchanged, COBOL reference automatic, Java target now provable.")


def legacy_sum_loop(amt):
    total = 0
    for i in range(12):
        total = total + amt
    return total


TOTAL_FIELD = None  # set below in run() to keep import order clean


JAVA_SUM_CORRECT = """
public class SumCalc {
    public static int sumCalc(int amt) {
        int total = 0;
        for (int i = 0; i < 12; i++) {
            total += amt;
        }
        return total;
    }
}
"""

JAVA_SUM_BUGGY = """
public class SumCalc {
    public static int sumCalc(int amt) {
        int total = 0;
        for (int i = 0; i < 11; i++) {
            total += amt;
        }
        return total;
    }
}
"""


def test_for_loop():
    from engine import PicField
    field = PicField(total_digits=9, decimal_digits=2)
    legacy_sum_loop.field_types = {"return": field}

    print("=" * 78)
    print("TEST: Java FOR loop with +=")
    print("=" * 78)
    correct_fn = load_java_as_fn(JAVA_SUM_CORRECT, "sumCalc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT (12x): {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_java_as_fn(JAVA_SUM_BUGGY, "sumCalc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (11x):   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> FOR loop works end-to-end\n")


JAVA_RECORD_SOURCE = """
public class Account {
    public int balance;
    public int fee;
}
public class Calc {
    public static int applyFee(Account acc) {
        int newBalance = acc.balance - acc.fee;
        return newBalance;
    }
}
"""


def test_record_param():
    from engine import PicField
    field = PicField(total_digits=9, decimal_digits=2)
    record_spec = {"balance": field, "fee": field}

    def legacy_apply_fee(acc):
        return acc.balance - acc.fee
    legacy_apply_fee.record_types = {"acc": record_spec}
    legacy_apply_fee.field_types = {"return": field}

    print("=" * 78)
    print("TEST: Java class with multiple fields as a record parameter")
    print("=" * 78)
    py_source = transpile_java_method(JAVA_RECORD_SOURCE, "applyFee", param_names=["acc"])
    print(py_source)
    filename = "<java:applyFee>"
    import linecache
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    java_fn = ns["applyFee"]
    java_fn.record_types = {"acc": record_spec}
    java_fn.field_types = {"return": field}

    res = verify(legacy_apply_fee, java_fn, arg_type=z3.IntSort())
    print(f"vs. Java record parameter: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> Java class as a record parameter works end-to-end\n")


JAVA_SWITCH_SOURCE = """
public class X {
    public static int grade(int code) {
        int level;
        switch (code) {
            case 1:
                level = 100;
                break;
            case 2:
            case 3:
                level = 200;
                break;
            default:
                level = 0;
                break;
        }
        return level;
    }
}
"""

JAVA_SWITCH_BUGGY = """
public class X {
    public static int grade(int code) {
        int level;
        switch (code) {
            case 1:
                level = 100;
                break;
            case 2:
                level = 200;
                break;
            default:
                level = 0;
                break;
        }
        return level;
    }
}
"""


def test_switch():
    from engine import PicField
    field = PicField(total_digits=5, decimal_digits=0)

    def legacy_grade(code):
        if code == 1:
            level = 100
        elif code == 2 or code == 3:
            level = 200
        else:
            level = 0
        return level
    legacy_grade.field_types = {"return": field}

    print("=" * 78)
    print("TEST: Java switch (analogous to COBOL EVALUATE)")
    print("=" * 78)
    correct_fn = load_java_as_fn(JAVA_SWITCH_SOURCE, "grade", {"return": field}, ["code"])
    res = verify(legacy_grade, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_java_as_fn(JAVA_SWITCH_BUGGY, "grade", {"return": field}, ["code"])
    res = verify(legacy_grade, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (case 3 missing): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> switch works end-to-end\n")


JAVA_TERNARY_SOURCE = """
public class X {
    public static int max2(int a, int b) {
        int r = a > b ? a : b;
        return r;
    }
}
"""

JAVA_TERNARY_BUGGY = """
public class X {
    public static int max2(int a, int b) {
        int r = a >= b ? b : a;
        return r;
    }
}
"""

JAVA_WHILE_SOURCE = """
public class X {
    public static int sumLoop(int amt) {
        int total = 0;
        int i = 0;
        while (i < 12) {
            total += amt;
            i++;
        }
        return total;
    }
}
"""

JAVA_WHILE_BUGGY = """
public class X {
    public static int sumLoop(int amt) {
        int total = 0;
        int i = 0;
        while (i < 11) {
            total += amt;
            i++;
        }
        return total;
    }
}
"""


def test_ternary():
    print("=" * 78)
    print("TEST 5: Java ternary operator")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)

    def legacy_max2(a, b):
        if a > b:
            r = a
        else:
            r = b
        return r
    legacy_max2.field_types = {"return": field}

    correct_fn = load_java_as_fn(JAVA_TERNARY_SOURCE, "max2", {"return": field}, ["a", "b"])
    res = verify(legacy_max2, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_java_as_fn(JAVA_TERNARY_BUGGY, "max2", {"return": field}, ["a", "b"])
    res = verify(legacy_max2, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> ternary operator works end-to-end\n")


def test_while_counted_loop():
    print("=" * 78)
    print("TEST 6: Java while counting loop")
    print("=" * 78)

    def legacy_sum_loop_while(amt):
        total = 0
        for i in range(12):
            total = total + amt
        return total
    field = PicField(total_digits=9, decimal_digits=2)
    legacy_sum_loop_while.field_types = {"return": field}

    correct_fn = load_java_as_fn(JAVA_WHILE_SOURCE, "sumLoop", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop_while, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT (12x): {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_java_as_fn(JAVA_WHILE_BUGGY, "sumLoop", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop_while, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (11x):   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> while counting loop works end-to-end\n")


JAVA_ARRAY_SOURCE = """
public class X {
    public static int sumArray(int[] items) {
        int total = 0;
        for (int i = 0; i < 5; i++) {
            total = total + items[i];
        }
        return total;
    }
}
"""

JAVA_ARRAY_BUGGY = """
public class X {
    public static int sumArray(int[] items) {
        int total = 0;
        for (int i = 0; i < 4; i++) {
            total = total + items[i];
        }
        return total;
    }
}
"""


def test_array_param():
    from engine import TableField
    print("=" * 78)
    print("TEST 7: Java int[] array as a table parameter")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    table_spec = TableField(element=field, occurs=5)

    def legacy_sum_array(items):
        total = 0
        for i in range(5):
            total = total + items[i]
        return total
    legacy_sum_array.field_types = {"return": field}
    legacy_sum_array.table_types = {"items": table_spec}

    py_source = transpile_java_method(JAVA_ARRAY_SOURCE, "sumArray", param_names=["items"])
    print(py_source)
    filename = "<java:sumArray>"
    import linecache
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    correct_fn = ns["sumArray"]
    correct_fn.field_types = {"return": field}
    correct_fn.table_types = {"items": table_spec}

    res = verify(legacy_sum_array, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    py_buggy = transpile_java_method(JAVA_ARRAY_BUGGY, "sumArray", param_names=["items"])
    filename2 = "<java:sumArray:buggy>"
    linecache.cache[filename2] = (len(py_buggy), None, py_buggy.splitlines(keepends=True), filename2)
    ns2 = {}
    exec(compile(py_buggy, filename2, "exec"), ns2)
    buggy_fn = ns2["sumArray"]
    buggy_fn.field_types = {"return": field}
    buggy_fn.table_types = {"items": table_spec}

    res = verify(legacy_sum_array, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (only 4 elements instead of 5): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> Java int[] array as a table parameter works end-to-end\n")


JAVA_STRING_SOURCE = """
public class X {
    public static String pick(String a, String b, int useFirst) {
        String r;
        if (useFirst > 0) {
            r = a;
        } else {
            r = b;
        }
        return r;
    }
}
"""

JAVA_STRING_BUGGY = """
public class X {
    public static String pick(String a, String b, int useFirst) {
        String r;
        if (useFirst >= 0) {
            r = a;
        } else {
            r = b;
        }
        return r;
    }
}
"""


def test_string_param():
    from engine import PicX
    print("=" * 78)
    print("TEST 8: Java String as a parameter/return type")
    print("=" * 78)
    field = PicX(10)

    def legacy_pick(a, b, use_first):
        if use_first > 0:
            r = a
        else:
            r = b
        return r
    legacy_pick.field_types = {"a": field, "b": field, "return": field}

    correct_fn = load_java_as_fn(JAVA_STRING_SOURCE, "pick", {"return": field}, ["a", "b", "use_first"])
    correct_fn.field_types = {"a": field, "b": field, "return": field}
    res = verify(legacy_pick, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_java_as_fn(JAVA_STRING_BUGGY, "pick", {"return": field}, ["a", "b", "use_first"])
    buggy_fn.field_types = {"a": field, "b": field, "return": field}
    res = verify(legacy_pick, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (>= instead of >): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> Java String as a parameter/return type works end-to-end\n")


if __name__ == "__main__":
    run()
    test_for_loop()
    test_record_param()
    test_switch()
    test_ternary()
    test_while_counted_loop()
    test_array_param()
    test_string_param()
    print("\nJava bridge test passed.")
