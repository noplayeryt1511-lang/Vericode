import z3
from engine import verify, PicField, TableField

AMOUNT_FIELD = PicField(total_digits=7, decimal_digits=2)
AMOUNTS_TABLE = TableField(element=AMOUNT_FIELD, occurs=12)


def legacy_sum_all(amounts):
    total = 0
    for i in range(12):
        total = total + amounts[i]
    return total


legacy_sum_all.table_types = {"amounts": AMOUNTS_TABLE}
legacy_sum_all.field_types = {"return": AMOUNT_FIELD, "total": AMOUNT_FIELD}


def modern_sum_off_by_one(amounts):
    # Bug: range(13) instead of range(12) -> reads amounts[12], OUTSIDE the
    # 12-element table
    total = 0
    for i in range(13):
        total = total + amounts[i]
    return total


modern_sum_off_by_one.table_types = {"amounts": AMOUNTS_TABLE}
modern_sum_off_by_one.field_types = {"return": AMOUNT_FIELD, "total": AMOUNT_FIELD}


if __name__ == "__main__":
    res = verify(legacy_sum_all, modern_sum_off_by_one, arg_type=z3.IntSort())
    print("LABEL:", res.label.value)
    print("index_warnings:", res.index_warnings)
