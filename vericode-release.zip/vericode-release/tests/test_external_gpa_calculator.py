"""
External validation #9: FIFTH entirely new project --
marvinjason/cobol (a personal COBOL practice repo, public on GitHub).

Source: gpa-calculator.cbl:

    ADD TEMP1 TO UNITS.
    MULTIPLY TEMP1 BY TEMP2.
    ADD TEMP2 TO GRADES.
    DIVIDE UNITS INTO GRADES GIVING GPA.

A classic weighted average (units * grade, summed, divided by total
units). TWO real findings here:

1. `MULTIPLY A BY B` (implicit write-back into B, without GIVING) and
   `DIVIDE A INTO B GIVING C` (the 'INTO' preposition, not just 'BY')
   were previously NOT supported -- only 'MULTIPLY A BY B GIVING C' /
   'DIVIDE A BY B GIVING C'. Both are very common COBOL shorthand forms,
   now implemented (`_multiply_or_divide` in `cobol_transpile.py`).

2. **A related, independent finding in the same bug class as the
   field-times-field multiplication case:** `ADD`/`SUBTRACT` with a
   source that is a single field already scaled to ITS OWN scale
   (here: TEMP2 with one decimal place, GRADES with two) was carried
   over WITHOUT a scale adjustment -- `ADD TEMP2 TO GRADES` would have
   incorrectly added 7.50 as 8.25 instead of correctly as 15.00. Fixed
   (using the same technique as the multiplication fix: look up the
   known field scale, correct the difference via a power of ten).
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. GPACALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  UNITS      PIC 9(2).
       01  GRADES     PIC 9(2)V9(2).
       01  GPA        PIC 9(1)V9(2).
       01  TEMP1      PIC 9(1).
       01  TEMP2      PIC 9(2)V9(1).
       PROCEDURE DIVISION.
       P.
           ADD TEMP1 TO UNITS.
           MULTIPLY TEMP1 BY TEMP2.
           ADD TEMP2 TO GRADES.
           DIVIDE UNITS INTO GRADES GIVING GPA.
           STOP RUN.
"""


def modern_correct(units, grades, temp1, temp2):
    units = units + temp1
    temp2 = temp1 * temp2
    grades = grades + (temp2 * 10)
    gpa = grades // units
    return gpa


def modern_buggy_no_scale_correction(units, grades, temp1, temp2):
    # Bug: the ADD scaling error described above -- TEMP2 (one decimal
    # place) is added to GRADES (two decimal places) without adjustment
    # (represents the state before the fix).
    units = units + temp1
    temp2 = temp1 * temp2
    grades = grades + temp2
    gpa = grades // units
    return gpa


def run():
    print("=" * 78)
    print("External validation #9: fifth project -- GPA calculator (weighted average)")
    print("(found a MULTIPLY/DIVIDE gap AND a related ADD scaling bug)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "gpa_calc", ["units", "grades", "temp1", "temp2"], "gpa")
    print("Auto-generated reference (from real COBOL code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_no_scale_correction.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_no_scale_correction, arg_type=z3.IntSort())
    print(f"vs. BUGGY (ADD without scale correction -- the bug state described above): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Ninth external source proven, fifth source project -- "
          "found two independent real bugs (MULTIPLY/DIVIDE forms, ADD scaling).")


if __name__ == "__main__":
    run()
    print("\nExternal validation #9 passed.")
