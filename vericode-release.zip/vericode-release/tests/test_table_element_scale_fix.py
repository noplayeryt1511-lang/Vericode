"""
This is the tenth instance of the same scaling-bug class: a TABLE ELEMENT
used as an operand (e.g. 'WS-ITEM(WS-I) * WS-RATE') was not caught by any
of the nine previously fixed spots, because the lookup logic only checked
plain field names as an exact dictionary key -- 'ws_item[(ws_i - 1)]' is
not such a key, even though 'ws_item' (the table name) carries the
correct scale.

Verified directly against the generated source (rather than through a
full symbolic verify() run with a table parameter -- that would raise a
separate, independent question about how table parameters are wired up
for symbolic evaluation, which is unrelated to this specific finding)."""
from full_pipeline import build_legacy_fn_from_cobol

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-TABLE.
           05  WS-ITEM PIC 9(2)V9(1) OCCURS 10 TIMES.
       01  WS-I       PIC 9(2).
       01  WS-RATE    PIC 9(2)V99.
       01  WS-RESULT  PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT = WS-ITEM(WS-I) * WS-RATE.
           STOP RUN.
"""


def run():
    print("=" * 78)
    print("TEST: table-element scaling bug (tenth instance of the same class)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_item", "ws_i", "ws_rate"], "ws_result")
    print(source)

    # WS-ITEM has scale 1, WS-RATE has scale 2, target WS-RESULT has scale 2.
    # Exponent = target scale(2) - scale1(1) - scale2(2) = -1 -> divide
    # by 10^1 = 10. Before the fix, there was no correction here at all.
    assert "// 10)" in source, f"Scale correction is missing from the generated code: {source!r}"
    assert "ws_item[" in source, "Table access not present as expected in the generated code"
    print("-> scale correction (// 10) is correctly present in the generated code, "
          "even for a table element used as an operand.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
