import z3
from engine import verify, PicField, TableField

QUANTITY_FIELD = PicField(total_digits=4, decimal_digits=0)
PRICE_FIELD = PicField(total_digits=7, decimal_digits=2)
TOTAL_FIELD = PicField(total_digits=9, decimal_digits=2)

LINE_ITEM_SPEC = {"quantity": QUANTITY_FIELD, "price": PRICE_FIELD}
LINE_ITEMS_TABLE = TableField(element=LINE_ITEM_SPEC, occurs=10)


def legacy_invoice_total(line_items):
    # COBOL: PERFORM VARYING I ... ADD LINE-ITEM(I) QUANTITY * LINE-ITEM(I) PRICE TO TOTAL
    total = 0
    for i in range(10):
        total = total + line_items[i].quantity * line_items[i].price
    return total


legacy_invoice_total.table_types = {"line_items": LINE_ITEMS_TABLE}
legacy_invoice_total.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}


def modern_invoice_total_buggy(line_items):
    # Bug: field width forgotten during translation (no truncation on TOTAL_FIELD)
    total = 0
    for i in range(10):
        total = total + line_items[i].quantity * line_items[i].price
    return total


modern_invoice_total_buggy.table_types = {"line_items": LINE_ITEMS_TABLE}
# deliberately NO field_types["return"] -> bug on overflow


def modern_invoice_total_correct(line_items):
    total = 0
    for i in range(10):
        total = total + line_items[i].quantity * line_items[i].price
    return total


modern_invoice_total_correct.table_types = {"line_items": LINE_ITEMS_TABLE}
modern_invoice_total_correct.field_types = {"total": TOTAL_FIELD, "return": TOTAL_FIELD}


# --- Second test: targeted write into a single table field -----------

def legacy_apply_discount_to_item(line_items):
    # Apply a discount to entry 0: reduce the price by 10%
    line_items[0].price = line_items[0].price * 9 // 10
    return line_items[0].price


legacy_apply_discount_to_item.table_types = {"line_items": LINE_ITEMS_TABLE}
legacy_apply_discount_to_item.field_types = {"return": PRICE_FIELD}


def modern_apply_discount_to_item_buggy(line_items):
    # Bug: wrong discount rate (20% instead of 10%)
    line_items[0].price = line_items[0].price * 8 // 10
    return line_items[0].price


modern_apply_discount_to_item_buggy.table_types = {"line_items": LINE_ITEMS_TABLE}
modern_apply_discount_to_item_buggy.field_types = {"return": PRICE_FIELD}


def modern_apply_discount_to_item_correct(line_items):
    line_items[0].price = line_items[0].price * 9 // 10
    return line_items[0].price


modern_apply_discount_to_item_correct.table_types = {"line_items": LINE_ITEMS_TABLE}
modern_apply_discount_to_item_correct.field_types = {"return": PRICE_FIELD}


def run():
    print("=" * 78)
    print("R1. Table of records: sum over quantity*price, field width forgotten")
    print("-" * 78)
    res = verify(legacy_invoice_total, modern_invoice_total_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()

    print("=" * 78)
    print("R2. Table of records: sum correct")
    print("-" * 78)
    res = verify(legacy_invoice_total, modern_invoice_total_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print()

    print("=" * 78)
    print("R3. Targeted write to a table-record field: wrong discount rate")
    print("-" * 78)
    res = verify(legacy_apply_discount_to_item, modern_apply_discount_to_item_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        print(f"  Counterexample: {res.counterexample}")
    print()

    print("=" * 78)
    print("R4. Targeted write to a table-record field: correct")
    print("-" * 78)
    res = verify(legacy_apply_discount_to_item, modern_apply_discount_to_item_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")


if __name__ == "__main__":
    run()
