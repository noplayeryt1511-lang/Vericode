"""
External validation #3: AWS CardDemo, the SAME already-vetted,
Apache-2.0-licensed source as #2 -- but a STRUCTURALLY DIFFERENT
construct (STRING concatenation instead of a pure arithmetic formula),
to demonstrate genuine pattern breadth rather than a second copy of
the same pattern.

Source: app/cbl/CBACT04C.cbl, paragraph '1300-B-WRITE-TX':

    ADD 1 TO WS-TRANID-SUFFIX
    STRING PARM-DATE,
        WS-TRANID-SUFFIX
        DELIMITED BY SIZE
        INTO TRAN-ID
    END-STRING

Builds a transaction ID from a date plus a running sequence number --
a very common COBOL idiom (ID generation via concatenation).
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TXIDBUILD.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  PARM-DATE          PIC X(10).
       01  WS-TRANID-SUFFIX   PIC X(06).
       01  TRAN-ID            PIC X(16).
       PROCEDURE DIVISION.
       P.
           STRING PARM-DATE, WS-TRANID-SUFFIX
               DELIMITED BY SIZE
               INTO TRAN-ID
           END-STRING.
           STOP RUN.
"""


def modern_correct(parm_date, ws_tranid_suffix):
    return parm_date + ws_tranid_suffix


def modern_buggy_swapped(parm_date, ws_tranid_suffix):
    # Bug: operand order swapped -- a translator that assembles the
    # STRING sources in the wrong order (easy to miss when there are
    # several STRING sources with no obvious visual separation).
    return ws_tranid_suffix + parm_date


def run():
    print("=" * 78)
    print("External validation #3: AWS CardDemo -- STRING concatenation (transaction ID)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "build_tx_id", ["parm_date", "ws_tranid_suffix"], "tran_id")
    print("Auto-generated reference (from real CardDemo code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_swapped.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_swapped, arg_type=z3.IntSort())
    print(f"vs. BUGGY (order swapped): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Third external source proven successfully -- a different construct "
          "(STRING concatenation instead of arithmetic) from the same source already "
          "confirmed safe to license.")


if __name__ == "__main__":
    run()
    print("\nExternal validation #3 passed.")
