"""
This covers a scaling bug class in COBOL comparisons: the same scaling
error class seen with field-times-field multiplication and ADD/SUBTRACT
also occurs in COMPARISONS. 'IF TEMP2 > GRADES' with TEMP2 at one decimal
place and GRADES at two would compare the RAW, differently scaled integers
directly (7.6 > 7.50 would incorrectly evaluate as 76 > 750 = FALSE).
This is particularly serious because IF conditions appear in virtually
every COBOL program.

Fixed in cobol_expr.py (_normalize_scale_pair), at all four places that
build a comparison (symbolic operators, EQUAL/GREATER/LESS, each with and
without a preceding IS/NOT).
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  TEMP2      PIC 9(2)V9(1).
       01  GRADES     PIC 9(2)V9(2).
       01  WS-RESULT  PIC 9(1).
       PROCEDURE DIVISION.
       P.
           IF TEMP2 > GRADES
               MOVE 1 TO WS-RESULT
           ELSE
               MOVE 0 TO WS-RESULT
           END-IF.
           STOP RUN.
"""


def modern_correct(temp2, grades):
    if (temp2 * 10) > grades:
        r = 1
    else:
        r = 0
    return r


def modern_buggy_no_scale_correction(temp2, grades):
    # Bug: exactly the comparison scaling error described above --
    # raw, differently scaled values are compared directly
    # (represents the state BEFORE the fix).
    if temp2 > grades:
        r = 1
    else:
        r = 0
    return r


def run():
    print("=" * 78)
    print("TEST: Comparison scaling bug (third instance of this same bug class)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["temp2", "grades"], "ws_result")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_no_scale_correction.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_no_scale_correction, arg_type=z3.IntSort())
    print(f"vs. BUGGY (comparison without scale correction): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Comparison scaling bug fixed and proven end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
