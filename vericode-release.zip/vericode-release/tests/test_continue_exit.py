from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_transpile import transpile_procedure_division


def test_continue_in_if_branch():
    print("=" * 78)
    print("TEST 1: CONTINUE as the ONLY statement in an IF branch (edge case)")
    print("=" * 78)
    src = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A   PIC 9(5).
       PROCEDURE DIVISION.
       P.
           IF WS-A > 0
               CONTINUE
           ELSE
               ADD 1 TO WS-A
           END-IF.
           STOP RUN.
    """
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(src, params)
    source = transpile_procedure_division(program, "continue_test", ["ws_a"], "ws_a", {"ws_a": 0})
    print(source)
    ns = {}
    exec(compile(source, "<x>", "exec"), ns)
    assert ns["continue_test"](5) == 5
    assert ns["continue_test"](0) == 1
    print("-> valid Python despite a pure no-op branch, correct behavior\n")


def test_exit_standalone():
    print("=" * 78)
    print("TEST 2: EXIT as a standalone statement")
    print("=" * 78)
    src = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A   PIC 9(5).
       PROCEDURE DIVISION.
       P.
           ADD 1 TO WS-A.
           EXIT.
           STOP RUN.
    """
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(src, params)
    source = transpile_procedure_division(program, "exit_test", ["ws_a"], "ws_a", {"ws_a": 0})
    print(source)
    ns = {}
    exec(compile(source, "<x>", "exec"), ns)
    assert ns["exit_test"](10) == 11
    print("-> EXIT correctly treated as a no-op\n")


def test_perform_body_only_continue():
    print("=" * 78)
    print("TEST 3: PERFORM paragraph whose body consists ONLY of CONTINUE (edge case)")
    print("=" * 78)
    src = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A   PIC 9(5).
       PROCEDURE DIVISION.
       MAIN-PARA.
           PERFORM NOOP-PARA 3 TIMES.
           STOP RUN.
       NOOP-PARA.
           CONTINUE.
    """
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(src, params)
    source = transpile_procedure_division(program, "perform_noop_test", ["ws_a"], "ws_a", {"ws_a": 0})
    print(source)
    ns = {}
    exec(compile(source, "<x>", "exec"), ns)
    assert ns["perform_noop_test"](7) == 7  # unchanged, since NOOP-PARA does nothing
    print("-> valid Python despite a pure no-op paragraph body\n")


if __name__ == "__main__":
    test_continue_in_if_branch()
    test_exit_standalone()
    test_perform_body_only_continue()
    print("All CONTINUE/EXIT tests passed.")
