"""
Confirmation (not a new finding): the previously called-out edge case --
the combination of a table element AND record qualification ("table of
records") -- already works correctly with the existing
_scale_lookup_key helper.
"""
from full_pipeline import build_legacy_fn_from_cobol

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-TABLE.
           05  WS-ENTRY OCCURS 10 TIMES.
               10  ENTRY-AMOUNT PIC 9(4)V9(1).
       01  WS-I         PIC 9(2).
       01  WS-RATE      PIC 9(2)V99.
       01  WS-RESULT    PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT = ENTRY-AMOUNT (WS-I) * WS-RATE.
           STOP RUN.
"""


def run():
    print("=" * 78)
    print("TEST: table of records (combined edge case) -- confirmation, not a new finding")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_entry", "ws_i", "ws_rate"], "ws_result")
    print(source)
    assert "// 10)" in source, f"Scale correction is missing from the generated code: {source!r}"
    print("-> scale correction already works correctly, even for table-of-records access.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
