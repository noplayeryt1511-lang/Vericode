import linecache
import z3
from go_bridge import transpile_go_function, UnsupportedGoConstruct
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify, PicField, PicX, TableField

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INC     PIC 9(7)V99.
       01  WS-TAX     PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           IF WS-INC <= 10000.00
               COMPUTE WS-TAX = WS-INC * 10
           ELSE
               IF WS-INC <= 50000.00
                   COMPUTE WS-TAX = WS-INC * 20
               ELSE
                   COMPUTE WS-TAX = WS-INC * 30
               END-IF
           END-IF.
           STOP RUN.
"""

GO_CORRECT = """
package main
func Calc(wsInc int) int {
    var wsTax int
    if wsInc <= 1000000 {
        wsTax = wsInc * 10
    } else if wsInc <= 5000000 {
        wsTax = wsInc * 20
    } else {
        wsTax = wsInc * 30
    }
    return wsTax
}
"""

GO_BUGGY = """
package main
func Calc(wsInc int) int {
    var wsTax int
    if wsInc < 1000000 {
        wsTax = wsInc * 10
    } else if wsInc <= 5000000 {
        wsTax = wsInc * 20
    } else {
        wsTax = wsInc * 30
    }
    return wsTax
}
"""

GO_SUM_CORRECT = """
package main
func Calc(amt int) int {
    total := 0
    for i := 0; i < 12; i++ {
        total += amt
    }
    return total
}
"""

GO_SUM_BUGGY = """
package main
func Calc(amt int) int {
    total := 0
    for i := 0; i < 11; i++ {
        total += amt
    }
    return total
}
"""

GO_SWITCH_SOURCE = """
package main
func Grade(code int) int {
    var level int
    switch code {
    case 1:
        level = 100
    case 2, 3:
        level = 200
    default:
        level = 0
    }
    return level
}
"""

GO_SWITCH_BUGGY = """
package main
func Grade(code int) int {
    var level int
    switch code {
    case 1:
        level = 100
    case 2:
        level = 200
    default:
        level = 0
    }
    return level
}
"""

GO_ARRAY_SOURCE = """
package main
func SumArray(items []int) int {
    total := 0
    for i := 0; i < 5; i++ {
        total = total + items[i]
    }
    return total
}
"""

GO_ARRAY_BUGGY = """
package main
func SumArray(items []int) int {
    total := 0
    for i := 0; i < 4; i++ {
        total = total + items[i]
    }
    return total
}
"""

GO_STRING_SOURCE = """
package main
func Pick(a string, b string, useFirst int) string {
    var r string
    if useFirst > 0 {
        r = a
    } else {
        r = b
    }
    return r
}
"""

GO_STRING_BUGGY = """
package main
func Pick(a string, b string, useFirst int) string {
    var r string
    if useFirst >= 0 {
        r = a
    } else {
        r = b
    }
    return r
}
"""

GO_RECORD_SOURCE = """
package main
type Account struct {
    Balance int
    Fee int
}
func ApplyFee(acc Account) int {
    return acc.Balance - acc.Fee
}
"""


def load_go_as_fn(go_source, function_name, field_types, param_names, table_types=None, record_types=None,
                   field_rename=None):
    py_source = transpile_go_function(go_source, function_name, param_names=param_names, field_rename=field_rename)
    filename = f"<go:{function_name}:{id(go_source)}>"
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    fn = ns[function_name]
    fn.field_types = dict(field_types)
    fn.table_types = dict(table_types or {})
    fn.record_types = dict(record_types or {})
    return fn


def test_if_elif():
    print("=" * 78)
    print("TEST 1: Go as the verification target -- auto-generated COBOL reference vs. Go")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "tax_calc", ["ws_inc"], "ws_tax")

    correct_fn = load_go_as_fn(GO_CORRECT, "Calc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    res = verify(legacy_fn, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT Go: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_go_as_fn(GO_BUGGY, "Calc", {"return": field_types["ws_tax"]}, ["ws_inc"])
    res = verify(legacy_fn, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY Go: {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> if/elif works end-to-end\n")


def test_for_loop():
    def legacy_sum_loop(amt):
        total = 0
        for i in range(12):
            total = total + amt
        return total
    field = PicField(total_digits=9, decimal_digits=2)
    legacy_sum_loop.field_types = {"return": field}

    print("=" * 78)
    print("TEST 2: Go FOR loop with +=")
    print("=" * 78)
    correct_fn = load_go_as_fn(GO_SUM_CORRECT, "Calc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT (12x): {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_go_as_fn(GO_SUM_BUGGY, "Calc", {"return": field}, ["amt"])
    res = verify(legacy_sum_loop, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (11x): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> FOR loop works end-to-end\n")


def test_switch():
    def legacy_grade(code):
        if code == 1:
            level = 100
        elif code == 2 or code == 3:
            level = 200
        else:
            level = 0
        return level
    field = PicField(total_digits=5, decimal_digits=0)
    legacy_grade.field_types = {"return": field}

    print("=" * 78)
    print("TEST 3: Go switch (Go does NOT need break -- no fall-through by default)")
    print("=" * 78)
    correct_fn = load_go_as_fn(GO_SWITCH_SOURCE, "Grade", {"return": field}, ["code"])
    res = verify(legacy_grade, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_go_as_fn(GO_SWITCH_BUGGY, "Grade", {"return": field}, ["code"])
    res = verify(legacy_grade, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (case 3 missing): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> switch works end-to-end\n")


def test_array_param():
    print("=" * 78)
    print("TEST 4: Go []int slice as a table parameter")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    table_spec = TableField(element=field, occurs=5)

    def legacy_sum_array(items):
        total = 0
        for i in range(5):
            total = total + items[i]
        return total
    legacy_sum_array.field_types = {"return": field}
    legacy_sum_array.table_types = {"items": table_spec}

    correct_fn = load_go_as_fn(GO_ARRAY_SOURCE, "SumArray", {"return": field}, ["items"], table_types={"items": table_spec})
    res = verify(legacy_sum_array, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_go_as_fn(GO_ARRAY_BUGGY, "SumArray", {"return": field}, ["items"], table_types={"items": table_spec})
    res = verify(legacy_sum_array, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (only 4 elements instead of 5): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> []int slice as a table parameter works end-to-end\n")


def test_string_param():
    print("=" * 78)
    print("TEST 5: Go string as a parameter/return type")
    print("=" * 78)
    field = PicX(10)

    def legacy_pick(a, b, use_first):
        if use_first > 0:
            r = a
        else:
            r = b
        return r
    legacy_pick.field_types = {"a": field, "b": field, "return": field}

    correct_fn = load_go_as_fn(GO_STRING_SOURCE, "Pick", {"a": field, "b": field, "return": field}, ["a", "b", "use_first"])
    res = verify(legacy_pick, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load_go_as_fn(GO_STRING_BUGGY, "Pick", {"a": field, "b": field, "return": field}, ["a", "b", "use_first"])
    res = verify(legacy_pick, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (>= instead of >): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> string as a parameter/return type works end-to-end\n")


def test_record_param():
    print("=" * 78)
    print("TEST 6: Go struct with multiple fields as a record parameter")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=2)
    record_spec = {"balance": field, "fee": field}

    def legacy_apply_fee(acc):
        return acc.balance - acc.fee
    legacy_apply_fee.field_types = {"return": field}
    legacy_apply_fee.record_types = {"acc": record_spec}

    correct_fn = load_go_as_fn(GO_RECORD_SOURCE, "ApplyFee", {"return": field}, ["acc"],
                                record_types={"acc": record_spec},
                                field_rename={"Balance": "balance", "Fee": "fee"})
    res = verify(legacy_apply_fee, correct_fn, arg_type=z3.IntSort())
    print(f"vs. Go record parameter: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> Go struct as a record parameter works end-to-end\n")


if __name__ == "__main__":
    test_if_elif()
    test_for_loop()
    test_switch()
    test_array_param()
    test_string_param()
    test_record_param()
    print("All six Go bridge tests passed -- third target language reaches parity with Java/C#.")
