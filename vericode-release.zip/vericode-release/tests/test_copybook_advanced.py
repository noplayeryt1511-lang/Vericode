import os
from cobol_extract import extract_data_items, extract_record_and_table_types
from full_pipeline import build_legacy_fn_from_cobol

COPYBOOK_DIR = "/tmp/copybook_test2"


def setup_copybooks():
    os.makedirs(COPYBOOK_DIR, exist_ok=True)
    with open(f"{COPYBOOK_DIR}/INNER.CPY", "w") as f:
        f.write("       05  INNER-FIELD    PIC 9(4).\n")
    with open(f"{COPYBOOK_DIR}/OUTER.CPY", "w") as f:
        f.write("       01  OUTER-RECORD.\n           COPY INNER.\n           05  OUTER-FIELD    PIC 9(4).\n")
    with open(f"{COPYBOOK_DIR}/GENERIC.CPY", "w") as f:
        f.write("       05  :PREFIX:-AMOUNT    PIC 9(7)V99.\n       05  :PREFIX:-COUNT     PIC 9(3).\n")


# Run once at import/collection time (not only in the `__main__` block below)
# so the fixture files exist regardless of whether this file is executed
# directly or collected by pytest.
setup_copybooks()


NESTED_COPY_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. NESTEDTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY OUTER.
       PROCEDURE DIVISION.
       P.
           STOP RUN.
"""

REPLACING_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. REPLTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INVOICE.
           COPY GENERIC REPLACING :PREFIX: BY INV.
       01  WS-PAYMENT.
           COPY GENERIC REPLACING :PREFIX: BY PAY.
       01  WS-TOTAL     PIC 9(9)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-TOTAL = INV-AMOUNT OF WS-INVOICE + PAY-AMOUNT OF WS-PAYMENT.
           STOP RUN.
"""

# Same business logic, but split into two simple statements instead of a
# combined expression with two OF-qualifications -- this works around the
# cobol-py truncation bug demonstrated below in TEST 2a, without fixing it
# (that bug lives in the library, not in our code).
REPLACING_SOURCE_SPLIT = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. REPLTEST2.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INVOICE.
           COPY GENERIC REPLACING :PREFIX: BY INV.
       01  WS-PAYMENT.
           COPY GENERIC REPLACING :PREFIX: BY PAY.
       01  WS-TOTAL     PIC 9(9)V99.
       PROCEDURE DIVISION.
       P.
           MOVE INV-AMOUNT OF WS-INVOICE TO WS-TOTAL.
           ADD PAY-AMOUNT OF WS-PAYMENT TO WS-TOTAL.
           STOP RUN.
"""


def test_nested_copy():
    print("=" * 78)
    print("TEST 1: Nested COPY (a copybook that itself contains a COPY statement)")
    print("=" * 78)
    items = extract_data_items(NESTED_COPY_SOURCE, copy_book_dirs=[COPYBOOK_DIR])
    names = [it["cobol_name"] for it in items]
    print("Extracted fields:", names)
    assert "OUTER-RECORD" in names
    assert "INNER-FIELD" in names
    assert "OUTER-FIELD" in names

    result = extract_record_and_table_types(NESTED_COPY_SOURCE, copy_book_dirs=[COPYBOOK_DIR])
    print("record_types:", result["record_types"])
    assert "outer_record" in result["record_types"]
    assert "inner_field" in result["record_types"]["outer_record"]
    assert "outer_field" in result["record_types"]["outer_record"]
    print("-> nested COPY works fully through our pipeline\n")


def test_copy_replacing_truncation_caught():
    print("=" * 78)
    print("TEST 2a: COPY ... REPLACING + combined expression -- known cobol-py bug MUST be caught cleanly")
    print("=" * 78)
    from cobol_transpile import UnsupportedCobolConstruct
    try:
        build_legacy_fn_from_cobol(
            REPLACING_SOURCE, "repl_test", [], "ws_total", copy_book_dirs=[COPYBOOK_DIR],
        )
        raise AssertionError("Should have raised UnsupportedCobolConstruct (known cobol-py truncation bug)!")
    except UnsupportedCobolConstruct as e:
        print(f"Caught cleanly instead of being silently mistranslated: {e}")
    print("-> the safety net works correctly, even with two REPLACING instances of the same copybook\n")


def test_copy_replacing_working():
    print("=" * 78)
    print("TEST 2b: COPY ... REPLACING works (a phrasing that avoids the cobol-py bug)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        REPLACING_SOURCE_SPLIT, "repl_test2", [], "ws_total", copy_book_dirs=[COPYBOOK_DIR],
    )
    print(source)
    print("-> COPY ... REPLACING works fully through our pipeline "
          "(two independent record instances from the SAME copybook, named differently)\n")


if __name__ == "__main__":
    setup_copybooks()
    test_nested_copy()
    test_copy_replacing_truncation_caught()
    test_copy_replacing_working()
    print("All COPY extension tests passed.")
