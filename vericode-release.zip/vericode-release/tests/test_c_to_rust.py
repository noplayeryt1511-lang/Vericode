"""
A direct answer to the question "can we also do C to Rust?":
yes -- using exactly the same building blocks as COBOL-to-X, just with
the roles swapped. Here, C takes the LEGACY role (new c_bridge.py,
proof-of-concept) while Rust remains the MODERN side (existing
rust_bridge.py, unchanged). engine.py itself is not modified.
"""
import linecache
import z3
from c_bridge import transpile_c_function
from rust_bridge import transpile_rust_function
from engine import verify, PicField

C_SOURCE = """
int safe_divide(int a, int b) {
    if (b == 0) {
        return 0;
    } else {
        return a / b;
    }
}
"""

RUST_SOURCE_CORRECT = """
fn safe_divide(a: i64, b: i64) -> i64 {
    if b == 0 {
        0
    } else {
        a / b
    }
}
"""

RUST_SOURCE_BUGGY = """
fn safe_divide(a: i64, b: i64) -> i64 {
    if b == 0 {
        1
    } else {
        a / b
    }
}
"""


def _load(py_source, fn_name, tag):
    filename = f"<{tag}:{fn_name}>"
    linecache.cache[filename] = (len(py_source), None, py_source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py_source, filename, "exec"), ns)
    return ns[fn_name]


def run():
    print("=" * 78)
    print("C (Legacy) vs. Rust (Modern) -- the same verification pipeline as COBOL-to-X")
    print("=" * 78)

    c_py_source = transpile_c_function(C_SOURCE, "safe_divide", param_names=["a", "b"])
    print("C -> Python (via the new c_bridge.py):")
    print(c_py_source)
    legacy_fn = _load(c_py_source, "safe_divide", "c")
    field = PicField(total_digits=9, decimal_digits=0)
    legacy_fn.field_types = {"return": field}

    rust_py_source_correct = transpile_rust_function(RUST_SOURCE_CORRECT, "safe_divide", param_names=["a", "b"])
    print("Rust -> Python (via the existing rust_bridge.py):")
    print(rust_py_source_correct)
    modern_correct = _load(rust_py_source_correct, "safe_divide", "rust_correct")
    modern_correct.field_types = {"return": field}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"C vs. CORRECT Rust: {res.label.value}")
    assert res.label.value == "PROVEN"

    rust_py_source_buggy = transpile_rust_function(RUST_SOURCE_BUGGY, "safe_divide", param_names=["a", "b"])
    modern_buggy = _load(rust_py_source_buggy, "safe_divide", "rust_buggy")
    modern_buggy.field_types = {"return": field}

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"C vs. BUGGY Rust (fallback value 1 instead of 0): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"

    print("\n-> Yes: C-to-Rust verification works, using the same building blocks as COBOL-to-X.")
    print("   engine.py was not modified for this -- only a new, narrowly scoped C bridge was built.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
