"""
Third step towards a "hybrid mode" for file I/O (after OPEN/CLOSE as a
no-op): 'READ <file> INTO <target>' is now a safe no-op WHEN <target> is
already a declared function parameter -- in that case the symbolic value
is already free/unconstrained, which is exactly what a real READ means
(the file contents are arbitrary). If <target> is NOT a parameter, it
remains clearly rejected (no silently incorrect no-op).
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from cobol_transpile import UnsupportedCobolConstruct
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC       PIC X(10).
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(3).
       01  WS-RESULT  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           OPEN INPUT MYFILE.
           READ MYFILE INTO WS-A.
           COMPUTE WS-RESULT = WS-A * 2.
           CLOSE MYFILE.
           STOP RUN.
"""

COBOL_NON_PARAM_TARGET = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC       PIC X(10).
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(3).
       01  WS-B       PIC 9(3).
       01  WS-RESULT  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           OPEN INPUT MYFILE.
           READ MYFILE INTO WS-B.
           COMPUTE WS-RESULT = WS-A * 2.
           CLOSE MYFILE.
           STOP RUN.
"""


def modern_correct(ws_a):
    return ws_a * 2


def test_read_into_parameter_target_is_safe_noop():
    print("=" * 78)
    print("TEST 1: READ ... INTO <parameter> -- safe no-op")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_a"], "ws_result")
    print(source)
    modern_correct.field_types = dict(legacy_fn.field_types)
    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"Result: {res.label.value}")
    assert res.label.value == "PROVEN"
    print("-> READ INTO targeting a parameter no longer blocks the surrounding computation\n")


def test_read_into_non_parameter_target_rejected():
    print("=" * 78)
    print("TEST 2: READ ... INTO <non-parameter> -- remains clearly rejected")
    print("=" * 78)
    try:
        build_legacy_fn_from_cobol(COBOL_NON_PARAM_TARGET, "x", ["ws_a"], "ws_result")
        raise AssertionError("Should have raised UnsupportedCobolConstruct!")
    except UnsupportedCobolConstruct as e:
        print(f"Correctly rejected: {e}")
    print("-> no silently incorrect no-op for a non-parameter target\n")


if __name__ == "__main__":
    test_read_into_parameter_target_is_safe_noop()
    test_read_into_non_parameter_target_rejected()
    print("Both tests passed.")
