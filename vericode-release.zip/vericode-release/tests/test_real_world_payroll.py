import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_transpile import transpile_procedure_division
from engine import verify, PicField

# Real excerpt from adrianotelesc/crud-payroll (GitHub, sourced externally,
# not authored here) -- INSS tax bracket calculation, DECIMAL-POINT IS COMMA.
SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. INSSCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  FS-SALBR  PIC 9(6)V9(2).
       01  FS-INSS   PIC 9(6)V9(2).
       PROCEDURE DIVISION.
       P.
           EVALUATE TRUE
           WHEN (FS-SALBR > 0) AND (FS-SALBR <= 1556,94)
               COMPUTE FS-INSS = FS-SALBR * 0,08
           WHEN (FS-SALBR > 1556,94) AND (FS-SALBR <= 2594,92)
               COMPUTE FS-INSS = FS-SALBR * 0,09
           WHEN (FS-SALBR > 2594,92)
               COMPUTE FS-INSS = FS-SALBR * 0,11
           WHEN OTHER
               COMPUTE FS-INSS = 0
           END-EVALUATE.
           STOP RUN.
"""


def build():
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(SRC, params)
    field_scales = {"fs_salbr": 2, "fs_inss": 2}
    source = transpile_procedure_division(program, "inss_calc", ["fs_salbr"], "fs_inss", field_scales)
    print(source)
    filename = "<inss_calc>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(source, filename, "exec"), ns)
    fn = ns["inss_calc"]
    fn.field_types = {"return": PicField(8, 2)}
    return fn


def modern_correct(fs_salbr):
    if fs_salbr > 0 and fs_salbr <= 155694:
        fs_inss = fs_salbr * 2 // 25
    elif fs_salbr > 155694 and fs_salbr <= 259492:
        fs_inss = fs_salbr * 9 // 100
    elif fs_salbr > 259492:
        fs_inss = fs_salbr * 11 // 100
    else:
        fs_inss = 0
    return fs_inss


modern_correct.field_types = {"return": PicField(8, 2)}


def modern_buggy(fs_salbr):
    if fs_salbr > 0 and fs_salbr < 155694:  # cliff-edge bug: < instead of <=
        fs_inss = fs_salbr * 2 // 25
    elif fs_salbr > 155694 and fs_salbr <= 259492:
        fs_inss = fs_salbr * 9 // 100
    elif fs_salbr > 259492:
        fs_inss = fs_salbr * 11 // 100
    else:
        fs_inss = 0
    return fs_inss


modern_buggy.field_types = {"return": PicField(8, 2)}


def run():
    legacy_fn = build()

    print("=" * 78)
    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print("vs CORRECT:", res.label.value)
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print("vs BUGGY:  ", res.label.value)
    if res.counterexample:
        print("Counterexample:", {k: v.as_long() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Real, externally-sourced COBOL code (not authored here)")
    print("   successfully transpiled AND mathematically proven.")


if __name__ == "__main__":
    run()
