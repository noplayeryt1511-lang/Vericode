import z3
from full_pipeline import verify_cobol_against_modern
from engine import PicField

COBOL_CONSTANT_BOUND = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(3).
       01  WS-RESULT  PIC 9(6).
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT = WS-A * 2.
           STOP RUN.
"""

COBOL_VARIABLE_BOUND = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-COUNT   PIC 9(3).
       01  WS-TABLE.
           05  WS-ITEM PIC S9(5) OCCURS 100 TIMES.
       01  WS-I       PIC 9(3).
       01  WS-TOTAL   PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-TOTAL.
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > WS-COUNT
               ADD WS-ITEM (WS-I) TO WS-TOTAL
           END-PERFORM.
           STOP RUN.
"""


def modern_constant_correct(ws_a):
    return ws_a * 2


def modern_variable_correct(ws_item, ws_count):
    ws_total = 0
    for i in range(ws_count):
        ws_total = ws_total + ws_item[i]
    return ws_total


def modern_variable_buggy(ws_item, ws_count):
    ws_total = 0
    for i in range(ws_count):
        ws_total = ws_total + ws_item[i] * 2  # Bug
    return ws_total


def test_standard_path_unchanged():
    print("=" * 78)
    print("TEST 1: constant loop bound -- runs through the standard path, as before")
    print("=" * 78)
    field = PicField(total_digits=6, decimal_digits=0)
    modern_constant_correct.field_types = {"return": field}
    res = verify_cobol_against_modern(COBOL_CONSTANT_BOUND, "x", ["ws_a"], "ws_result", modern_constant_correct)
    print(f"Result: {res.label} (path: {res.path})")
    assert res.label == "PROVEN"
    assert res.path == "standard"
    print("-> the standard path remains usable unchanged\n")


def test_variable_bound_auto_switches():
    print("=" * 78)
    print("TEST 2: variable loop bound -- switches AUTOMATICALLY to loop_induction")
    print("=" * 78)
    res = verify_cobol_against_modern(COBOL_VARIABLE_BOUND, "x", ["ws_item", "ws_count"], "ws_total", modern_variable_correct)
    print(f"Result: {res.label} (path: {res.path}, pattern: {res.pattern})")
    assert res.label == "PROVEN"
    assert res.path == "loop_induction"
    assert res.pattern == "single"

    res = verify_cobol_against_modern(COBOL_VARIABLE_BOUND, "x", ["ws_item", "ws_count"], "ws_total", modern_variable_buggy)
    print(f"vs. BUGGY: {res.label} (path: {res.path}), counterexample: {res.counterexample}")
    assert res.label == "FLAGGED FOR MANUAL REVIEW"
    print("-> the automatic switch works end-to-end, the caller did NOT need to know "
          "in advance that loop_induction would be needed here\n")


if __name__ == "__main__":
    test_standard_path_unchanged()
    test_variable_bound_auto_switches()
    print("Both tests for the unified entry point passed.")
