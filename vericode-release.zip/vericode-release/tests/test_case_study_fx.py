# -*- coding: utf-8 -*-
"""
Case study 4: cross-rate currency conversion (e.g. EUR -> USD -> GBP).

Realistic bug: when converting via an intermediate currency, the legacy
system actually posts an intermediate amount (to a real GL account, with
real rounding to 2 decimal places). An "optimized" LLM migration performs
both conversion steps in one go without the intermediate rounding step --
mathematically more precise, but not identical to the legacy behavior that
was historically posted. A classic "we made it more technically correct,
but now the books don't reconcile" bug.
"""

import z3
from engine import verify, PicField


AMOUNT_FIELD = PicField(total_digits=9, decimal_digits=2)   # amounts up to 9,999,999.99
RATE_FIELD = PicField(total_digits=7, decimal_digits=4)      # FX rates with 4 decimal places


def legacy_cross_convert(amount_scaled, rate1_scaled, rate2_scaled):
    # Step 1: source currency -> intermediate currency, posted as a real GL
    # intermediate amount -> must be rounded/truncated to 2 decimal places
    intermediate = (amount_scaled * rate1_scaled) // 10_000
    # Step 2: intermediate currency -> target currency
    final = (intermediate * rate2_scaled) // 10_000
    return final


legacy_cross_convert.field_types = {
    "amount_scaled": AMOUNT_FIELD,
    "rate1_scaled": RATE_FIELD,
    "rate2_scaled": RATE_FIELD,
    "intermediate": AMOUNT_FIELD,   # <- the crucial intermediate rounding step
    "return": AMOUNT_FIELD,
}


def modern_cross_convert_buggy(amount_scaled, rate1_scaled, rate2_scaled):
    # "Optimization": both rates applied in a single step, no intermediate rounding
    combined = (amount_scaled * rate1_scaled * rate2_scaled) // 100_000_000
    return combined


modern_cross_convert_buggy.field_types = {
    "amount_scaled": AMOUNT_FIELD,
    "rate1_scaled": RATE_FIELD,
    "rate2_scaled": RATE_FIELD,
    "return": AMOUNT_FIELD,
    # deliberately no "intermediate" -> this is exactly the missing rounding step
}


def modern_cross_convert_correct(amount_scaled, rate1_scaled, rate2_scaled):
    # Correct migration: explicitly replicates the intermediate rounding
    intermediate = (amount_scaled * rate1_scaled) // 10_000
    final = (intermediate * rate2_scaled) // 10_000
    return final


modern_cross_convert_correct.field_types = dict(legacy_cross_convert.field_types)


def run():
    print("=" * 78)
    print("4a. Cross-rate conversion, FULL value range: LEGACY vs. MODERN without intermediate rounding")
    print("-" * 78)
    res = verify(legacy_cross_convert, modern_cross_convert_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        a = res.counterexample["amount_scaled"].as_long()
        r1 = res.counterexample["rate1_scaled"].as_long()
        r2 = res.counterexample["rate2_scaled"].as_long()
        modulus = AMOUNT_FIELD.modulus
        legacy_intermediate = ((a * r1) // 10_000) % modulus
        legacy_final = ((legacy_intermediate * r2) // 10_000) % modulus
        modern_final = ((a * r1 * r2) // 100_000_000) % modulus
        print(f"  Counterexample: amount={a/100:.2f}, rate1={r1/10000:.4f}, rate2={r2/10000:.4f}")
        print(f"    legacy (with intermediate rounding, field-truncated)    = {legacy_final/100:.2f}")
        print(f"    modern (without intermediate rounding, field-truncated) = {modern_final/100:.2f}")
        print(f"    -> this case is overflow-driven (amounts near the field limit), not the typical everyday case")
    print()

    print("=" * 78)
    print("4a'. Cross-rate conversion, REALISTIC everyday values (amounts up to 10,000, rates 0.5-2.0)")
    print("-" * 78)
    res = verify(
        legacy_cross_convert, modern_cross_convert_buggy, arg_type=z3.IntSort(),
        input_bounds={
            "amount_scaled": (1, 1_000_000),
            "rate1_scaled": (5_000, 20_000),
            "rate2_scaled": (5_000, 20_000),
        },
    )
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        a = res.counterexample["amount_scaled"].as_long()
        r1 = res.counterexample["rate1_scaled"].as_long()
        r2 = res.counterexample["rate2_scaled"].as_long()
        modulus = AMOUNT_FIELD.modulus
        legacy_intermediate = ((a * r1) // 10_000) % modulus
        legacy_final = ((legacy_intermediate * r2) // 10_000) % modulus
        modern_final = ((a * r1 * r2) // 100_000_000) % modulus
        print(f"  Counterexample: amount={a/100:.2f}, rate1={r1/10000:.4f}, rate2={r2/10000:.4f}")
        print(f"    legacy = {legacy_final/100:.2f}, modern = {modern_final/100:.2f}  <- a pure 1-cent rounding difference,")
        print(f"    no overflow -> this is the case that is actually encountered in practice, not the extreme values above")
    print()

    print("=" * 78)
    print("4b. Cross-rate conversion: LEGACY vs. MODERN correct (intermediate rounding replicated)")
    print("-" * 78)
    res = verify(legacy_cross_convert, modern_cross_convert_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()


if __name__ == "__main__":
    run()
