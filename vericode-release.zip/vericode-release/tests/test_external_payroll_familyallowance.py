"""
External validation #5: the same Brazilian payroll project as the very
first external finding in this validation series (INSS tax brackets),
but a COMPLETELY DIFFERENT calculation fragment from the same source --
the statutory family allowance ("salário família", Brazilian labor law:
a fixed amount per dependent child).

Source: src/payroll.cbl, line 304:

    COMPUTE FS-TOTAL-DEP = FS-DEP * 189,59.

(COBOL DECIMAL-POINT IS COMMA -- "189,59" means 189.59, not a thousands
separator.) FS-DEP = number of dependent children, FS-TOTAL-DEP = total
allowance.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. FAMALLOW.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  FS-DEP         PIC 99.
       01  FS-TOTAL-DEP   PIC 9(6)V9(2).
       PROCEDURE DIVISION.
       P.
           COMPUTE FS-TOTAL-DEP = FS-DEP * 189,59.
           STOP RUN.
"""


def modern_correct(fs_dep):
    return fs_dep * 18959


def modern_buggy_wrong_rate(fs_dep):
    # Bug: outdated/incorrect rate -- a realistic error when a translator
    # uses an older version of the statutory amount.
    return fs_dep * 18500


def run():
    print("=" * 78)
    print("External validation #5: Brazilian payroll project -- family allowance")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "family_allowance", ["fs_dep"], "fs_total_dep")
    print("Auto-generated reference (from real payroll code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_wrong_rate.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_wrong_rate, arg_type=z3.IntSort())
    print(f"vs. BUGGY (incorrect rate): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Fifth external source proven -- a different fragment "
          "(family allowance instead of tax brackets) from the same source project.")


if __name__ == "__main__":
    run()
    print("\nExternal validation #5 passed.")
