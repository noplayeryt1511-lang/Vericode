import z3
from engine import verify, PicField, PicX

CUSTOMER_ID_FIELD = PicField(total_digits=6, decimal_digits=0)
CUSTOMER_NAME_FIELD = PicX(length=20)
TOTAL_FIELD = PicField(total_digits=7, decimal_digits=2)

INVOICE_RECORD = {
    "customer_info": {
        "customer_id": CUSTOMER_ID_FIELD,
        "customer_name": CUSTOMER_NAME_FIELD,
    },
    "total_amount": TOTAL_FIELD,
}


def legacy_apply_discount(invoice):
    # Customers with ID < 1000 (VIP tier) get a 10% discount
    if invoice.customer_info.customer_id < 1000:
        discounted = invoice.total_amount * 9 // 10
    else:
        discounted = invoice.total_amount
    return discounted


legacy_apply_discount.record_types = {"invoice": INVOICE_RECORD}
legacy_apply_discount.field_types = {"return": TOTAL_FIELD}


def modern_apply_discount_buggy(invoice):
    # Bug: boundary at <= 1000 instead of < 1000 (off-by-one at the threshold)
    if invoice.customer_info.customer_id <= 1000:
        discounted = invoice.total_amount * 9 // 10
    else:
        discounted = invoice.total_amount
    return discounted


modern_apply_discount_buggy.record_types = {"invoice": INVOICE_RECORD}
modern_apply_discount_buggy.field_types = {"return": TOTAL_FIELD}


def modern_apply_discount_correct(invoice):
    if invoice.customer_info.customer_id < 1000:
        discounted = invoice.total_amount * 9 // 10
    else:
        discounted = invoice.total_amount
    return discounted


modern_apply_discount_correct.record_types = {"invoice": INVOICE_RECORD}
modern_apply_discount_correct.field_types = {"return": TOTAL_FIELD}


def run():
    print("=" * 78)
    print("N1. Multi-level nesting: LEGACY vs. MODERN with an off-by-one at the threshold")
    print("-" * 78)
    res = verify(legacy_apply_discount, modern_apply_discount_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        cid = res.counterexample.get("invoice.customer_info.customer_id")
        amt = res.counterexample.get("invoice.total_amount")
        print(f"  Counterexample: invoice.customer_info.customer_id={cid}, invoice.total_amount={amt}")
    print()

    print("=" * 78)
    print("N2. Multi-level nesting: LEGACY vs. MODERN correct")
    print("-" * 78)
    res = verify(legacy_apply_discount, modern_apply_discount_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")


if __name__ == "__main__":
    run()
