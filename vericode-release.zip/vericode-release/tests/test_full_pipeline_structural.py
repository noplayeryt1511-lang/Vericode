import z3
from full_pipeline import full_auto_pipeline

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INC     PIC 9(7)V99.
       01  WS-TAX     PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           IF WS-INC <= 10000.00
               COMPUTE WS-TAX = WS-INC * 10
           ELSE
               IF WS-INC <= 50000.00
                   COMPUTE WS-TAX = WS-INC * 20
               ELSE
                   COMPUTE WS-TAX = WS-INC * 30
               END-IF
           END-IF.
           STOP RUN.
"""


def mock_correct_translation(prompt, attempt):
    return """
def tax_calc(ws_inc):
    if ws_inc <= 1000000:
        ws_tax = ws_inc * 10
    elif ws_inc <= 5000000:
        ws_tax = ws_inc * 20
    else:
        ws_tax = ws_inc * 30
    return ws_tax
"""


def mock_buggy_then_correct(prompt, attempt):
    if attempt == 0:
        return """
def tax_calc(ws_inc):
    if ws_inc < 1000000:
        ws_tax = ws_inc * 10
    elif ws_inc <= 5000000:
        ws_tax = ws_inc * 20
    else:
        ws_tax = ws_inc * 30
    return ws_tax
"""
    return mock_correct_translation(prompt, attempt)


def test_full_circle_correct():
    print("=" * 78)
    print("TEST 1: both sides auto-generated, LLM gets it right immediately")
    print("=" * 78)
    result = full_auto_pipeline(
        COBOL_SOURCE, "tax_calc", ["ws_inc"], "ws_tax",
        llm_fix_fn=mock_correct_translation, arg_type=z3.IntSort(),
    )
    print("Auto-generated legacy reference:")
    print(result.legacy_source)
    print("Success:", result.success, "Rounds:", result.attempts, "LLM calls:", result.repairs_used)
    assert result.success is True
    assert result.repairs_used == 1  # just the translation itself, no repair needed
    print()


def test_full_circle_needs_repair():
    print("=" * 78)
    print("TEST 2: both sides auto-generated, LLM needs one repair round")
    print("=" * 78)
    result = full_auto_pipeline(
        COBOL_SOURCE, "tax_calc", ["ws_inc"], "ws_tax",
        llm_fix_fn=mock_buggy_then_correct, arg_type=z3.IntSort(),
    )
    print("Success:", result.success, "Rounds:", result.attempts, "LLM calls:", result.repairs_used)
    for h in result.history:
        print(" ", h[0], h[1])
    assert result.success is True
    assert result.repairs_used == 2  # translation + one repair
    print()


if __name__ == "__main__":
    test_full_circle_correct()
    test_full_circle_needs_repair()
    print("Both structural tests passed.")
