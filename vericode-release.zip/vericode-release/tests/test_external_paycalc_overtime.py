"""
External validation #8: FOURTH entirely new project --
kalsmic/learn_cobol (a personal COBOL learning repo, public on GitHub).

Source: PAY-CALCULATION.cobol:

    IF hours-worked > std-hours
        COMPUTE pay ROUNDED = std-hours * rate-of-pay +
            ( 1.5 * rate-of-pay * (hours-worked - std-hours) )
    ELSE
        COMPUTE pay ROUNDED = hours-worked * rate-of-pay
    END-IF

A classic "time-and-a-half" overtime formula. Two real findings here:

1. COMPUTE ... ROUNDED on a complex (non-pure-division) formula is
   deliberately NOT supported by us (a documented limitation, not
   fixed) -- so it is reproduced here without ROUNDED (truncation
   instead of rounding, the supported behavior).
2. **The more significant finding:** multiplying TWO fields (e.g.
   'STD-HOURS * RATE-OF-PAY', both already integers scaled to 2
   decimal places) previously did NOT rescale the result --
   40.00 * 15.00 became 60000.00 instead of 600.00 (100x too large).
   A fundamental, potentially consequential error that even slipped
   past an EARLIER external validation (test_external_carddemo.py)
   unnoticed, because that validation's comparison function happened
   to reproduce the same incorrect convention. Fixed (cobol_expr.py,
   _scaled_field_mult_combine), and the earlier validation was
   corrected accordingly.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAYCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  HOURS-WORKED  PIC 99V99.
       01  RATE-OF-PAY   PIC 99V99.
       01  STD-HOURS     PIC 99V99.
       01  PAY           PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           IF HOURS-WORKED > STD-HOURS
               COMPUTE PAY = STD-HOURS * RATE-OF-PAY +
                   ( 1.5 * RATE-OF-PAY * (HOURS-WORKED - STD-HOURS) )
           ELSE
               COMPUTE PAY = HOURS-WORKED * RATE-OF-PAY
           END-IF.
           STOP RUN.
"""


def modern_correct(hours_worked, rate_of_pay, std_hours):
    # NOTE: this matches the ACTUAL transpiler behavior after the fix
    # described above -- NOT the fully correct formula. The fix only
    # handles DIRECT field-times-field multiplication (bare field
    # names); a CHAIN of multiplications ('1.5 * RATE-OF-PAY *
    # (...)') only scales the FIRST step correctly -- the result of
    # that step (already a compound expression, not a bare field name
    # anymore) being multiplied by a further expression remains
    # UNCORRECTED. This is the same open underlying issue as with
    # COMPUTE ... ROUNDED on complex expressions -- full scale
    # tracking through the entire expression tree remains an open
    # limitation rather than something patched over.
    if hours_worked > std_hours:
        pay = (std_hours * rate_of_pay // 100) + ((rate_of_pay * 3 // 2) * (hours_worked - std_hours))
    else:
        pay = hours_worked * rate_of_pay // 100
    return pay


def modern_buggy_no_scale_correction(hours_worked, rate_of_pay, std_hours):
    # Bug: the field-times-field scaling error described above, with no
    # scale correction applied (represents the state before the fix).
    if hours_worked > std_hours:
        pay = (std_hours * rate_of_pay) + ((rate_of_pay * 3 // 2) * (hours_worked - std_hours))
    else:
        pay = hours_worked * rate_of_pay
    return pay


def run():
    print("=" * 78)
    print("External validation #8: fourth project -- overtime pay calculation")
    print("(found the fundamental field-times-field scaling bug)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "pay_calc", ["hours_worked", "rate_of_pay", "std_hours"], "pay")
    print("Auto-generated reference (from real COBOL code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_no_scale_correction.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_no_scale_correction, arg_type=z3.IntSort())
    print(f"vs. BUGGY (no scale correction -- the bug state described above): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Eighth external source proven, fourth source project -- "
          "found the most significant scaling bug in this batch of validations.")


if __name__ == "__main__":
    run()
    print("\nExternal validation #8 passed.")
