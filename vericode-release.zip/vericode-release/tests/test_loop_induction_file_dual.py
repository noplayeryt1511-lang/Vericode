"""
Seventh and final pattern in loop_induction.py: two simultaneous
state variables in a file-processing loop (sum + counter, e.g. for
an average over all records). Structurally identical to the
already-solved two-state pattern for PERFORM VARYING.
"""
from loop_induction import verify_file_dual_accumulator_loop, UnsupportedLoopPattern

COBOL_SRC = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MYFILE ASSIGN TO MYFILE.
       DATA DIVISION.
       FILE SECTION.
       FD  MYFILE.
       01  FD-REC.
           05  FD-AMOUNT PIC 9(5).
       WORKING-STORAGE SECTION.
       01  WS-EOF     PIC X VALUE N.
       01  WS-SUM     PIC 9(9).
       01  WS-CNT     PIC 9(9).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-SUM.
           MOVE 0 TO WS-CNT.
           PERFORM UNTIL WS-EOF = Y
               READ MYFILE
                   AT END MOVE Y TO WS-EOF
                   NOT AT END
                       ADD FD-AMOUNT TO WS-SUM
                       ADD 1 TO WS-CNT
               END-READ
           END-PERFORM.
           STOP RUN.
"""


def modern_correct(fd_amount, record_count):
    ws_sum = 0
    ws_cnt = 0
    for i in range(record_count):
        ws_sum = ws_sum + fd_amount[i]
        ws_cnt = ws_cnt + 1
    return ws_sum


def modern_buggy_wrong_sum_coeff(fd_amount, record_count):
    ws_sum = 0
    ws_cnt = 0
    for i in range(record_count):
        ws_sum = ws_sum + fd_amount[i] * 2
        ws_cnt = ws_cnt + 1
    return ws_sum


def test_file_dual_correct():
    print("=" * 78)
    print("TEST 1: two-state file-processing loop -- correct")
    print("=" * 78)
    res = verify_file_dual_accumulator_loop(COBOL_SRC, modern_correct)
    print(f"Result: {res['label']}")
    print(f"COBOL side: {res['legacy_spec']}")
    assert res["label"] == "PROVEN"
    print("-> sum AND counter proven jointly for EVERY record count\n")


def test_file_dual_buggy():
    print("=" * 78)
    print("TEST 2: wrong sum coefficient -- the counter part remains correct")
    print("=" * 78)
    res = verify_file_dual_accumulator_loop(COBOL_SRC, modern_buggy_wrong_sum_coeff)
    print(f"Result: {res['label']}, counterexample record_count={res['counterexample_k']}")
    assert res["label"] == "FLAGGED FOR MANUAL REVIEW"
    print("-> bug found in the SUM, even though the COUNTER part is correct on its own\n")


if __name__ == "__main__":
    test_file_dual_correct()
    test_file_dual_buggy()
    print("Both tests for the two-state file-processing loop passed.")
