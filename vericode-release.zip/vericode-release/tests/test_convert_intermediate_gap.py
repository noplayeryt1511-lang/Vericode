import z3
from engine import PicField
from patch_loop import convert_and_verify

AMOUNT_FIELD = PicField(total_digits=9, decimal_digits=2)
RATE_FIELD = PicField(total_digits=7, decimal_digits=4)


def legacy_fx_convert(amount_scaled, rate1_scaled, rate2_scaled):
    # The intermediate rounding happens on 'intermediate' -- we know this
    # name because we wrote this function ourselves.
    intermediate = (amount_scaled * rate1_scaled) // 10_000
    final = (intermediate * rate2_scaled) // 10_000
    return final


legacy_fx_convert.field_types = {
    "amount_scaled": AMOUNT_FIELD, "rate1_scaled": RATE_FIELD, "rate2_scaled": RATE_FIELD,
    "intermediate": AMOUNT_FIELD, "return": AMOUNT_FIELD,
}

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. FXCONVERT.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-AMOUNT          PIC 9(7)V99.
       01  WS-RATE1           PIC 9(3)V9999.
       01  WS-RATE2           PIC 9(3)V9999.
       01  WS-INTERMEDIATE    PIC 9(7)V99.
       01  WS-FINAL           PIC 9(7)V99.

       PROCEDURE DIVISION.
       CONVERT-CURRENCY.
           COMPUTE WS-INTERMEDIATE = WS-AMOUNT * WS-RATE1 / 10000.
           COMPUTE WS-FINAL = WS-INTERMEDIATE * WS-RATE2 / 10000.
           STOP RUN.
"""


def mock_translate_no_intermediate_truncation(prompt, attempt):
    """Simulates a PLAUSIBLE LLM translation that reproduces the COBOL
    structure with two COMPUTE steps -- including an 'intermediate' variable,
    just like the original. The point: the caller code cannot know this in
    advance and cannot safely assume it -- so it only passes
    field_types={'return': ...}, the way a real user would who does not yet
    know the final COBOL code."""
    return '''
def fx_convert(amount_scaled, rate1_scaled, rate2_scaled):
    intermediate = amount_scaled * rate1_scaled // 10000
    final = intermediate * rate2_scaled // 10000
    return final
'''


if __name__ == "__main__":
    # Only "return" is known -- realistic, since the variable name in the
    # LLM code cannot be known ahead of time.
    result = convert_and_verify(
        legacy_fn=legacy_fx_convert, cobol_source=COBOL_SOURCE,
        function_name="fx_convert", param_names=["amount_scaled", "rate1_scaled", "rate2_scaled"],
        llm_fix_fn=mock_translate_no_intermediate_truncation, arg_type=z3.IntSort(),
        field_types={"return": AMOUNT_FIELD},  # NO "intermediate" here!
    )
    print("Success:", result.success)
    print("Verify rounds:", result.attempts)
    for h in result.history:
        print(" ", h[0], h[1])
