import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

ROUNDED_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ROUNDTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(7)V99.
       01  WS-B       PIC 9(5).
       01  WS-RESULT  PIC 9(7)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT ROUNDED = WS-A / WS-B.
           STOP RUN.
"""


def test_rounded_runtime():
    print("=" * 78)
    print("TEST 1: COMPUTE ... ROUNDED -- concrete values")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        ROUNDED_SOURCE, "round_test", ["ws_a", "ws_b"], "ws_result")
    print(source)
    # 700 (=7.00 scaled) / 2 = 350 (3.50) -- exact, no rounding needed
    assert legacy_fn(700, 2) == 350
    # 750 (7.50) / 2 = 375 (3.75) exact
    assert legacy_fn(750, 2) == 375
    # 7 (0.07) / 2 = 3.5 -> rounds up to 4 (0.04)
    assert legacy_fn(7, 2) == 4
    print("-> ROUNDED produces correct, rounded results\n")


def test_rounded_verify():
    print("=" * 78)
    print("TEST 2: COMPUTE ... ROUNDED -- Z3 proof (bug: plain division without rounding)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        ROUNDED_SOURCE, "round_test2", ["ws_a", "ws_b"], "ws_result")

    def modern_correct(ws_a, ws_b):
        if ws_a >= 0:
            return (2 * ws_a + ws_b) // (2 * ws_b)
        return -((2 * (-ws_a) + ws_b) // (2 * ws_b))
    modern_correct.field_types = dict(legacy_fn.field_types)

    def modern_buggy(ws_a, ws_b):
        return ws_a // ws_b  # Bug: plain (truncated) division instead of rounded
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort(),
                  input_bounds={"ws_b": (1, 99999)})
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort(),
                  input_bounds={"ws_b": (1, 99999)})
    print(f"vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> COMPUTE ... ROUNDED works end-to-end with a Z3 proof\n")


if __name__ == "__main__":
    test_rounded_runtime()
    test_rounded_verify()
    print("Both ROUNDED tests passed.")
