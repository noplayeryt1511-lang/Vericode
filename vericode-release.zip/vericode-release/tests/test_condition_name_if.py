import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

IF_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. IFCONDTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-STATUS   PIC X.
           88 IS-ACTIVE VALUE "A".
           88 IS-INACTIVE VALUE "I".
       01  WS-RESULT   PIC 9(3).
       PROCEDURE DIVISION.
       P.
           IF IS-ACTIVE
               MOVE 1 TO WS-RESULT
           ELSE
               MOVE 0 TO WS-RESULT
           END-IF.
           STOP RUN.
"""

EVAL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. EVALCONDTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-STATUS   PIC X.
           88 IS-ACTIVE VALUE "A".
           88 IS-INACTIVE VALUE "I".
       01  WS-RESULT   PIC 9(3).
       PROCEDURE DIVISION.
       P.
           EVALUATE TRUE
               WHEN IS-ACTIVE
                   MOVE 1 TO WS-RESULT
               WHEN IS-INACTIVE
                   MOVE 2 TO WS-RESULT
               WHEN OTHER
                   MOVE 0 TO WS-RESULT
           END-EVALUATE.
           STOP RUN.
"""


def test_if_condition_name():
    print("=" * 78)
    print("TEST 1: IF <condition-name>")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(IF_SOURCE, "if_cond", ["ws_status"], "ws_result")
    print(source)

    def modern_correct(ws_status):
        if ws_status == "A":
            r = 1
        else:
            r = 0
        return r
    modern_correct.field_types = {"ws_status": field_types["ws_status"], "return": field_types["ws_result"]}

    def modern_buggy(ws_status):
        if ws_status == "I":  # Bug: wrong value
            r = 1
        else:
            r = 0
        return r
    modern_buggy.field_types = {"ws_status": field_types["ws_status"], "return": field_types["ws_result"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> IF <condition-name> works end-to-end\n")


def test_evaluate_true_condition_name():
    print("=" * 78)
    print("TEST 2: EVALUATE TRUE / WHEN <condition-name>")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(EVAL_SOURCE, "eval_cond", ["ws_status"], "ws_result")
    print(source)

    def modern_correct(ws_status):
        if ws_status == "A":
            r = 1
        elif ws_status == "I":
            r = 2
        else:
            r = 0
        return r
    modern_correct.field_types = {"ws_status": field_types["ws_status"], "return": field_types["ws_result"]}

    def modern_buggy(ws_status):
        if ws_status == "A":
            r = 1
        elif ws_status == "I":
            r = 3  # Bug: wrong return value
        else:
            r = 0
        return r
    modern_buggy.field_types = {"ws_status": field_types["ws_status"], "return": field_types["ws_result"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {{k: v.as_string()}} ->", {k: v.as_string() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> EVALUATE TRUE / WHEN <condition-name> works end-to-end\n")


if __name__ == "__main__":
    test_if_condition_name()
    test_evaluate_true_condition_name()
    print("Both condition-name tests passed.")
