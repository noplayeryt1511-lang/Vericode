"""
Extension of COMPUTE ... ROUNDED: previously ANY additional
parenthesization in the numerator/denominator was blocked, even when
the single division still stood at the top level ('(A + B) / C'). Now
modestly extended (parenthesis-aware top-level parsing), NOT generalized
to arbitrary expressions -- 'A / B + C' remains rejected.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from cobol_transpile import UnsupportedCobolConstruct
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(4)V99.
       01  WS-B       PIC 9(4)V99.
       01  WS-C       PIC 9(2).
       01  WS-RESULT  PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT ROUNDED = (WS-A + WS-B) / WS-C.
           STOP RUN.
"""

COBOL_STILL_REJECTED = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(4)V99.
       01  WS-B       PIC 9(4)V99.
       01  WS-C       PIC 9(2).
       01  WS-RESULT  PIC 9(4)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT ROUNDED = WS-A / WS-C + WS-B.
           STOP RUN.
"""


def modern_correct(ws_a, ws_b, ws_c):
    num = ws_a + ws_b
    if num >= 0:
        return (2 * num + ws_c) // (2 * ws_c)
    return -((2 * -num + ws_c) // (2 * ws_c))


def modern_buggy_truncate_instead_of_round(ws_a, ws_b, ws_c):
    return (ws_a + ws_b) // ws_c


def test_bracketed_numerator_rounds_correctly():
    print("=" * 78)
    print("TEST 1: parenthesized numerator '(A + B) / C' -- now supported, rounds correctly")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_a", "ws_b", "ws_c"], "ws_result")
    print(source)
    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_truncate_instead_of_round.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT (rounded): {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_truncate_instead_of_round, arg_type=z3.IntSort())
    print(f"vs. BUGGY (truncated instead of rounded): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> parenthesized numerator works end-to-end, with real rounding\n")


def test_top_level_multi_operator_still_rejected():
    print("=" * 78)
    print("TEST 2: 'A / C + B' -- remains deliberately rejected")
    print("=" * 78)
    try:
        build_legacy_fn_from_cobol(COBOL_STILL_REJECTED, "x", ["ws_a", "ws_b", "ws_c"], "ws_result")
        raise AssertionError("Should have raised UnsupportedCobolConstruct!")
    except UnsupportedCobolConstruct as e:
        print(f"Correctly rejected: {e}")
    print("-> The basic restriction still holds\n")


if __name__ == "__main__":
    test_bracketed_numerator_rounds_correctly()
    test_top_level_multi_operator_still_rejected()
    print("Both tests passed.")
