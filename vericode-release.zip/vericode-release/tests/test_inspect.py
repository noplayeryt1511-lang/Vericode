import linecache
import z3
from cobol_py import CobolParserRunner, CobolParserParams, CobolSourceFormatEnum
from cobol_extract import extract_data_items
from cobol_transpile import transpile_procedure_division
from engine import verify, PicX, PicField


def char_at(s, i):
    return s[i:i + 1]


def build(src, function_name, param_names, return_field_py):
    params = CobolParserParams(format=CobolSourceFormatEnum.FIXED)
    program = CobolParserRunner().analyze(src, params)
    items = extract_data_items(src)
    field_types = {it["name"]: it["field"] for it in items if it["field"]}
    field_scales = {k: (v.decimal_digits if hasattr(v, "decimal_digits") else 0) for k, v in field_types.items()}
    field_lengths = {k: v.length for k, v in field_types.items() if isinstance(v, PicX)}
    source = transpile_procedure_division(program, function_name, param_names, return_field_py,
                                           field_scales, field_lengths=field_lengths)
    print(source)
    filename = f"<{function_name}>"
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(source, filename, "exec"), ns)
    fn = ns[function_name]
    fn.field_types = {p: field_types[p] for p in param_names if p in field_types}
    fn.field_types["return"] = field_types[return_field_py]
    return fn


TALLY_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TALLYTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-TEXT    PIC X(6).
       01  WS-COUNT   PIC 9(3).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-COUNT.
           INSPECT WS-TEXT TALLYING WS-COUNT FOR ALL "A".
           STOP RUN.
"""

REPLACE_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. REPLTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-TEXT    PIC X(4).
       PROCEDURE DIVISION.
       P.
           INSPECT WS-TEXT REPLACING ALL "A" BY "B".
           STOP RUN.
"""


def test_tallying():
    print("=" * 78)
    print("TEST 1: INSPECT TALLYING FOR ALL")
    print("=" * 78)
    legacy_fn = build(TALLY_SOURCE, "tally_legacy", ["ws_text"], "ws_count")

    def modern_correct(ws_text):
        count = 0
        count = count + (1 if char_at(ws_text, 0) == "A" else 0)
        count = count + (1 if char_at(ws_text, 1) == "A" else 0)
        count = count + (1 if char_at(ws_text, 2) == "A" else 0)
        count = count + (1 if char_at(ws_text, 3) == "A" else 0)
        count = count + (1 if char_at(ws_text, 4) == "A" else 0)
        count = count + (1 if char_at(ws_text, 5) == "A" else 0)
        return count
    modern_correct.field_types = dict(legacy_fn.field_types)

    def modern_buggy(ws_text):
        count = 0
        count = count + (1 if char_at(ws_text, 0) == "B" else 0)  # Bug: wrong letter
        count = count + (1 if char_at(ws_text, 1) == "B" else 0)
        count = count + (1 if char_at(ws_text, 2) == "B" else 0)
        count = count + (1 if char_at(ws_text, 3) == "B" else 0)
        count = count + (1 if char_at(ws_text, 4) == "B" else 0)
        count = count + (1 if char_at(ws_text, 5) == "B" else 0)
        return count
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> INSPECT TALLYING works end-to-end\n")


def test_replacing():
    print("=" * 78)
    print("TEST 2: INSPECT REPLACING ALL (deliberately a SHORT field -- see")
    print("        the empirically confirmed Z3 performance limit in cobol_transpile.py)")
    print("=" * 78)
    legacy_fn = build(REPLACE_SOURCE, "replace_legacy", ["ws_text"], "ws_text")

    def modern_correct(ws_text):
        r = ("B" if char_at(ws_text, 0) == "A" else char_at(ws_text, 0))
        r = r + ("B" if char_at(ws_text, 1) == "A" else char_at(ws_text, 1))
        r = r + ("B" if char_at(ws_text, 2) == "A" else char_at(ws_text, 2))
        r = r + ("B" if char_at(ws_text, 3) == "A" else char_at(ws_text, 3))
        return r
    modern_correct.field_types = dict(legacy_fn.field_types)

    def modern_buggy(ws_text):
        r = ("C" if char_at(ws_text, 0) == "A" else char_at(ws_text, 0))  # Bug: wrong replacement letter
        r = r + ("C" if char_at(ws_text, 1) == "A" else char_at(ws_text, 1))
        r = r + ("C" if char_at(ws_text, 2) == "A" else char_at(ws_text, 2))
        r = r + ("C" if char_at(ws_text, 3) == "A" else char_at(ws_text, 3))
        return r
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {{k: v.as_string()}} ->", {k: v.as_string() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> INSPECT REPLACING works end-to-end\n")


if __name__ == "__main__":
    test_tallying()
    test_replacing()
    print("Both INSPECT tests passed.")
