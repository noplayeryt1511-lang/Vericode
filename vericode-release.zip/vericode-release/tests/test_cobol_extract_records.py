from cobol_extract import extract_record_and_table_types

FLAT_RECORD_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTPROG.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  ACCOUNT-RECORD.
           05  BALANCE        PIC S9(7)V99.
           05  FEE            PIC 9(3)V99.
       01  SCORES             PIC 9(3) OCCURS 5 TIMES.
       01  STANDALONE-AMOUNT  PIC 9(5)V99.

       PROCEDURE DIVISION.
           STOP RUN.
"""

NESTED_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. NESTEDPROG.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  INVOICE.
           05  CUSTOMER-INFO.
               10  CUSTOMER-ID    PIC 9(6).
               10  CUSTOMER-NAME  PIC X(20).
           05  TOTAL-AMOUNT       PIC 9(7)V99.
       01  LINE-ITEMS.
           05  LINE-ITEM OCCURS 10 TIMES.
               10  QUANTITY       PIC 9(4).
               10  UNIT-PRICE     PIC 9(5)V99.

       PROCEDURE DIVISION.
           STOP RUN.
"""


def run_flat():
    print("=" * 78)
    print("1. Flat record + flat table + scalar (everything should work)")
    print("-" * 78)
    result = extract_record_and_table_types(FLAT_RECORD_SOURCE)
    print("field_types:", result["field_types"])
    print("record_types:", result["record_types"])
    print("table_types:", result["table_types"])
    print("unresolved:", result["unresolved"])
    assert "account_record" in result["record_types"]
    assert "balance" in result["record_types"]["account_record"]
    assert "scores" in result["table_types"]
    assert "standalone_amount" in result["field_types"]
    assert result["unresolved"] == []
    print("-> all assertions passed")
    print()


def run_nested():
    print("=" * 78)
    print("2. Nested group (INVOICE.CUSTOMER-INFO) + table of records (LINE-ITEMS)")
    print("-" * 78)
    result = extract_record_and_table_types(NESTED_SOURCE)
    print("field_types:", result["field_types"])
    print("record_types:", result["record_types"])
    print("table_types:", result["table_types"])
    print("unresolved:", result["unresolved"])
    # INVOICE is resolvable (multi-level nesting)
    assert "invoice" in result["record_types"]
    assert "customer_info" in result["record_types"]["invoice"]
    assert "customer_id" in result["record_types"]["invoice"]["customer_info"]
    # LINE-ITEMS is now ALSO resolvable (table of records via Z3 datatypes)
    assert "line_items" in result["table_types"]
    assert "quantity" in result["table_types"]["line_items"].element
    assert result["unresolved"] == []
    print("-> both cases are now fully resolved automatically")


if __name__ == "__main__":
    run_flat()
    run_nested()
