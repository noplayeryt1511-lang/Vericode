"""
External validation #2: AWS CardDemo (aws-samples/aws-mainframe-modernization-carddemo)

An official AWS reference application, EXPLICITLY built for mainframe
migration demos (Apache 2.0, public, widely used in the industry as a
standard test corpus for migration tools). A different domain than the
previous external case (payroll/tax bracket): here it is credit-card
interest calculation.

Source: app/cbl/CBACT04C.cbl, paragraph '1300-COMPUTE-INTEREST':

    COMPUTE WS-MONTHLY-INT
        = ( TRAN-CAT-BAL * DIS-INT-RATE) / 1200
    ADD WS-MONTHLY-INT TO WS-TOTAL-INT

The full program has extensive file I/O around it (VSAM files, copybooks
for the record structures) -- categorically outside our model. Only the
computational core is extracted, with plausible PIC clauses for the
fields TRAN-CAT-BAL/DIS-INT-RATE (defined in copybooks not shown here) --
a balance and an interest rate, both standard financial field formats.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. INTCALC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  TRAN-CAT-BAL       PIC S9(9)V99.
       01  DIS-INT-RATE       PIC S9(4)V99.
       01  WS-MONTHLY-INT     PIC S9(9)V99.
       01  WS-TOTAL-INT       PIC S9(9)V99.
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-MONTHLY-INT = (TRAN-CAT-BAL * DIS-INT-RATE) / 1200.
           ADD WS-MONTHLY-INT TO WS-TOTAL-INT.
           STOP RUN.
"""


def modern_correct(tran_cat_bal, dis_int_rate, ws_total_int):
    # CORRECTED (a real scaling bug this case surfaced): TRAN-CAT-BAL and
    # DIS-INT-RATE are BOTH already integers scaled up by 2 decimal places
    # -- their product is scaled by 4 decimal places (100*100), not 2. An
    # earlier version of this function had EXACTLY THIS bug (dividing only
    # by 1200, without an additional divide by 100 for the double
    # pre-scaling) -- and because the transpiler made the same mistake at
    # the time, it was incorrectly waved through as PROVEN. After the fix
    # in the transpiler, THIS version is the correct one.
    ws_monthly_int = (tran_cat_bal * dis_int_rate // 100) // 1200
    ws_total_int = ws_total_int + ws_monthly_int
    return ws_total_int


def modern_buggy_divisor(tran_cat_bal, dis_int_rate, ws_total_int):
    # Bug: divided by 100 instead of 1200 (after the scale correction) --
    # a translator that forgets the annual-to-monthly conversion (12) and
    # only keeps the percentage scaling (100). A realistic, non-contrived
    # error.
    ws_monthly_int = (tran_cat_bal * dis_int_rate // 100) // 100
    ws_total_int = ws_total_int + ws_monthly_int
    return ws_total_int


def run():
    print("=" * 78)
    print("External validation #2: AWS CardDemo -- real interest calculation")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "int_calc", ["tran_cat_bal", "dis_int_rate", "ws_total_int"], "ws_total_int")
    print("Automatically generated reference (from real CardDemo code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_divisor.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_divisor, arg_type=z3.IntSort())
    print(f"vs. BUGGY (/100 instead of /1200): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Second external source successfully proven -- a different domain "
          "(credit card interest instead of payroll), a different origin (AWS "
          "instead of a Brazilian community project).")


if __name__ == "__main__":
    run()
    print("\nExternal validation #2 passed.")
