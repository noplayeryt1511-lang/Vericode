import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify, PicX

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-SRC-NAME    PIC X(30).
       01  NAME-1         PIC X(30).
       01  UNQUAL-NAME-1  PIC X(30).
       PROCEDURE DIVISION.
       P.
           MOVE WS-SRC-NAME TO NAME-1  UNQUAL-NAME-1.
           STOP RUN.
"""


def modern_correct(ws_src_name):
    name_1 = ws_src_name
    unqual_name_1 = ws_src_name
    return unqual_name_1


def modern_buggy_only_one_target(ws_src_name):
    # Bug: only ONE target receives the value -- a realistic mistake when
    # a translator overlooks the multi-target MOVE pattern.
    unqual_name_1 = "unchanged"
    return unqual_name_1


def run():
    print("=" * 78)
    print("TEST: multi-target MOVE ('MOVE source TO target1 target2') -- real NIST finding (DB205A.CBL)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_src_name"], "unqual_name_1")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_only_one_target.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_only_one_target, arg_type=z3.IntSort())
    print(f"vs. BUGGY (target never receives the value): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> multi-target MOVE works end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
