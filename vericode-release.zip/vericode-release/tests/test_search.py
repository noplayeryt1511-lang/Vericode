import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

SEARCH_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SEARCHTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-TABLE.
           05  WS-ITEM PIC 9(5) OCCURS 5 TIMES INDEXED BY WS-IDX.
       01  WS-TARGET  PIC 9(5).
       01  WS-FOUND   PIC 9(1).
       PROCEDURE DIVISION.
       P.
           MOVE 0 TO WS-FOUND.
           SEARCH WS-ITEM
               AT END
                   MOVE 0 TO WS-FOUND
               WHEN WS-ITEM (WS-IDX) = WS-TARGET
                   MOVE 1 TO WS-FOUND
           END-SEARCH.
           STOP RUN.
"""


def test_search_runtime():
    print("=" * 78)
    print("TEST 1: SEARCH -- concrete execution")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        SEARCH_SOURCE, "search_test", ["ws_item", "ws_target"], "ws_found")
    print(source)

    table = [10, 20, 30, 40, 50]
    print("Match (30 is present):", legacy_fn(table, 30))
    assert legacy_fn(table, 30) == 1
    print("No match (99 not present):", legacy_fn(table, 99))
    assert legacy_fn(table, 99) == 0
    print("-> SEARCH runs correctly for concrete values\n")


def test_search_verify():
    print("=" * 78)
    print("TEST 2: SEARCH -- Z3 proof (bug: wrong initial value for 'found')")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        SEARCH_SOURCE, "search_test2", ["ws_item", "ws_target"], "ws_found")

    def modern_correct(ws_item, ws_target):
        found = False
        for i in range(5):
            if not found:
                if ws_item[i] == ws_target:
                    found = True
        return 1 if found else 0
    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_correct.table_types = dict(legacy_fn.table_types)

    def modern_buggy(ws_item, ws_target):
        found = True  # Bug: wrong initial value instead of False
        for i in range(5):
            if not found:
                if ws_item[i] == ws_target:
                    found = True
        return 1 if found else 0
    modern_buggy.field_types = dict(legacy_fn.field_types)
    modern_buggy.table_types = dict(legacy_fn.table_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> SEARCH works end-to-end with a Z3 proof\n")


if __name__ == "__main__":
    test_search_runtime()
    test_search_verify()
    print("Both SEARCH tests passed.")
