"""
Confirmation, not a new feature: Go has no try/catch -- the idiomatic
form for "division with a zero guard" is a plain
'if b == 0 { return 0 }', which works through our EXISTING if/return
support without go_bridge.py needing anything new. This test confirms
that end-to-end rather than just asserting it.
"""
import z3
from go_bridge import transpile_go_function
from engine import verify, PicField

GO_SAFE_DIVIDE_SOURCE = """
package main
func safeDivide(a int, b int) int {
    if b == 0 {
        return 0
    }
    return a / b
}
"""

GO_SAFE_DIVIDE_BUGGY = """
package main
func safeDivide(a int, b int) int {
    if b == 0 {
        return 1
    }
    return a / b
}
"""


def legacy_safe_divide(a, b):
    if b == 0:
        result = 0
    else:
        result = a // b
    return result


def load(src):
    py = transpile_go_function(src, "safeDivide", param_names=["a", "b"])
    filename = f"<go_safe_divide:{id(src)}>"
    import linecache
    linecache.cache[filename] = (len(py), None, py.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py, filename, "exec"), ns)
    return ns["safeDivide"]


def run():
    print("=" * 78)
    print("TEST: Go -- division with a zero guard, no new code (existing if/return)")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    legacy_safe_divide.field_types = {"return": field}

    correct_fn = load(GO_SAFE_DIVIDE_SOURCE)
    correct_fn.field_types = {"return": field}
    res = verify(legacy_safe_divide, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = load(GO_SAFE_DIVIDE_BUGGY)
    buggy_fn.field_types = {"return": field}
    res = verify(legacy_safe_divide, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (fallback value 1 instead of 0): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Go reaches parity with Java/C#'s try/catch WITHOUT new code -- "
          "different language, different idiom, same result.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
