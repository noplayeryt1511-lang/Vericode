"""
External validation #7: a COMPLETELY NEW project (not CardDemo/Payroll
again) -- continuous-copilot/modernize-legacy-cobol-app, a real, public,
MIT-licensed COBOL accounting system that was EXPLICITLY built as a demo
repo for AI-assisted COBOL modernization.

Source: operations.cob, DEBIT branch:

    IF FINAL-BALANCE >= AMOUNT
        SUBTRACT AMOUNT FROM FINAL-BALANCE
        CALL 'DataProgram' USING 'WRITE', FINAL-BALANCE
        DISPLAY "Amount debited. New balance: " FINAL-BALANCE
    ELSE
        DISPLAY "Insufficient funds for this debit."
    END-IF

A solvency/threshold check BEFORE a state change -- a different pattern
than the previous six external cases covered (neither a pure arithmetic
formula, nor STRING concatenation, nor plain ADD/MOVE). Only the
computational core is extracted; DISPLAY/ACCEPT/CALL (screen I/O,
subprogram calls) are left out, as always.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. DEBITOP.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  AMOUNT          PIC 9(6)V99.
       01  FINAL-BALANCE   PIC 9(6)V99.
       PROCEDURE DIVISION.
       P.
           IF FINAL-BALANCE >= AMOUNT
               SUBTRACT AMOUNT FROM FINAL-BALANCE
           END-IF.
           STOP RUN.
"""


def modern_correct(amount, final_balance):
    if final_balance >= amount:
        final_balance = final_balance - amount
    return final_balance


def modern_buggy_strict_gt(amount, final_balance):
    # Bug: '>' instead of '>=' -- an exact balance (final_balance == amount)
    # would be incorrectly treated as "insufficient", even though it is
    # exactly enough. A realistic boundary-case error.
    if final_balance > amount:
        final_balance = final_balance - amount
    return final_balance


def run():
    print("=" * 78)
    print("External validation #7: new project -- solvency check before debit")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "debit_op", ["amount", "final_balance"], "final_balance")
    print("Automatically generated reference (from real, new COBOL code):")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy_strict_gt.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy_strict_gt, arg_type=z3.IntSort())
    print(f"vs. BUGGY (> instead of >=, exact-balance boundary case): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> Seventh external source successfully proven -- a completely new "
          "project, different origin, different pattern (threshold check before "
          "a state change) than the six previous cases.")


if __name__ == "__main__":
    run()
    print("\nExternal validation #7 passed.")
