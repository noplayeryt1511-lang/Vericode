# -*- coding: utf-8 -*-
"""
PIC X test: alphanumeric fixed-length fields.

  01 CUSTOMER-RECORD.
     05 STATUS-CODE   PIC X(2).      -> e.g. "A ", "IN", "CL"
     05 CUSTOMER-NAME PIC X(10).     -> left-justified, space-padded/truncated
"""

import z3
from engine import verify, PicX, PicField


STATUS_FIELD = PicX(length=2)
NAME_FIELD = PicX(length=10)

CUSTOMER_RECORD = {
    "status": STATUS_FIELD,
    "name": NAME_FIELD,
}


# --- Test 1: MOVE truncation/padding on direct assignment -----------------

def legacy_normalize_status(raw_status):
    # COBOL: MOVE RAW-STATUS TO STATUS-CODE (PIC X(2))
    status = raw_status
    return status


legacy_normalize_status.field_types = {"raw_status": PicX(length=10), "status": STATUS_FIELD, "return": STATUS_FIELD}


def modern_normalize_status_buggy(raw_status):
    # Bug: the migration forgot to truncate to 2 characters (Rust/Go
    # strings have no implicit fixed-length semantics like COBOL PIC X)
    status = raw_status
    return status


modern_normalize_status_buggy.field_types = {"raw_status": PicX(length=10), "return": PicX(length=10)}
# deliberate: return is NOT constrained to STATUS_FIELD (length 2) -> bug


def modern_normalize_status_correct(raw_status):
    status = raw_status
    return status


modern_normalize_status_correct.field_types = {"raw_status": PicX(length=10), "status": STATUS_FIELD, "return": STATUS_FIELD}


def run_move_test():
    print("=" * 78)
    print("X1. MOVE truncation: LEGACY (PIC X(2)) vs. MODERN without truncation")
    print("-" * 78)
    res = verify(legacy_normalize_status, modern_normalize_status_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        raw = res.counterexample["raw_status"]
        raw_str = raw.as_string()
        legacy_str = (raw_str + " " * STATUS_FIELD.length)[:STATUS_FIELD.length]
        print(f"  Counterexample: raw_status={raw_str!r}")
        print(f"    legacy (PIC X(2), truncated) = {legacy_str!r}")
        print(f"    modern (no truncation)       = {raw_str!r}")
    print()

    print("=" * 78)
    print("X2. MOVE truncation: LEGACY vs. MODERN correct")
    print("-" * 78)
    res = verify(legacy_normalize_status, modern_normalize_status_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()


# --- Test 2: status comparison within a record -----------------------

def legacy_is_active(customer):
    # COBOL: IF STATUS-CODE = "A " ...  (PIC X(2), right-padded!)
    if customer.status == "A":
        result = 1
    else:
        result = 0
    return result


legacy_is_active.record_types = {"customer": CUSTOMER_RECORD}
legacy_is_active.field_types = {"return": PicField(total_digits=1, decimal_digits=0)}


def modern_is_active_buggy(customer):
    # Bug: the LLM compares against "A" (1 character) instead of the
    # correctly 2-character-normalized "A " (COBOL right-pads PIC X(2)
    # with a space) -- since our STATUS_FIELD.normalize() already handles
    # that, we instead simulate the MORE REALISTIC bug here: comparing
    # with the wrong case ("a" instead of "A")
    if customer.status == "a":
        result = 1
    else:
        result = 0
    return result


modern_is_active_buggy.record_types = {"customer": CUSTOMER_RECORD}
modern_is_active_buggy.field_types = {"return": PicField(total_digits=1, decimal_digits=0)}


def modern_is_active_correct(customer):
    if customer.status == "A":
        result = 1
    else:
        result = 0
    return result


modern_is_active_correct.record_types = {"customer": CUSTOMER_RECORD}
modern_is_active_correct.field_types = {"return": PicField(total_digits=1, decimal_digits=0)}


def run_compare_test():
    print("=" * 78)
    print("X3. Status comparison in the record: LEGACY ('A') vs. MODERN ('a', bug)")
    print("-" * 78)
    res = verify(legacy_is_active, modern_is_active_buggy, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    if res.counterexample:
        st = res.counterexample["customer.status"]
        print(f"  Counterexample: customer.status={st.as_string()!r}")
    print()

    print("=" * 78)
    print("X4. Status comparison in the record: LEGACY vs. MODERN correct")
    print("-" * 78)
    res = verify(legacy_is_active, modern_is_active_correct, arg_type=z3.IntSort())
    print(f"  LABEL:  {res.label.value}")
    print(f"  Detail: {res.detail}")
    print()


if __name__ == "__main__":
    run_move_test()
    run_compare_test()
