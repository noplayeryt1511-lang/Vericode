import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

MAX_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. MAXTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(5).
       01  WS-B       PIC 9(5).
       01  WS-RESULT  PIC 9(5).
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-RESULT = FUNCTION MAX(WS-A WS-B).
           STOP RUN.
"""

LENGTH_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LENTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-NAME    PIC X(12).
       01  WS-LEN     PIC 9(3).
       PROCEDURE DIVISION.
       P.
           COMPUTE WS-LEN = FUNCTION LENGTH(WS-NAME).
           STOP RUN.
"""


def test_function_max():
    print("=" * 78)
    print("TEST 1: FUNCTION MAX")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(MAX_SOURCE, "max_test", ["ws_a", "ws_b"], "ws_result")
    print(source)

    def modern_correct(ws_a, ws_b):
        return ws_a if ws_a > ws_b else ws_b
    modern_correct.field_types = {"return": field_types["ws_result"]}

    def modern_buggy(ws_a, ws_b):
        return ws_a  # Bug: ignores ws_b entirely
    modern_buggy.field_types = {"return": field_types["ws_result"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> FUNCTION MAX works end-to-end\n")


def test_function_length():
    print("=" * 78)
    print("TEST 2: FUNCTION LENGTH")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(LENGTH_SOURCE, "len_test", [], "ws_len")
    print(source)

    def modern_correct():
        return 12
    modern_correct.field_types = {"return": field_types["ws_len"]}

    def modern_buggy():
        return 10  # Bug: incorrect (guessed) length
    modern_buggy.field_types = {"return": field_types["ws_len"]}

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY:   {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("-> FUNCTION LENGTH works end-to-end\n")


if __name__ == "__main__":
    test_function_max()
    test_function_length()
    print("Both FUNCTION tests passed.")
