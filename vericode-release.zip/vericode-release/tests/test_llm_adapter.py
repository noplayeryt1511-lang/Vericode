import io
import json
import os
import unittest.mock as mock

from llm_adapter import extract_code, call_anthropic, LLMCallError


def test_extract_code_variants():
    print("=" * 78)
    print("A1. extract_code() with various response formats")
    print("-" * 78)

    with_python_fence = '''Here is the corrected function:

```python
def modern_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled
    return total
```

This fixes the sign error.'''
    result = extract_code(with_python_fence)
    assert "def modern_invoice_total" in result
    assert "Here is" not in result
    assert "This fixes" not in result
    print("  ✓ ```python fence correctly extracted, explanatory text removed")

    plain_fence = '''```
def modern_invoice_total(quantity, unit_price_scaled):
    return quantity * unit_price_scaled
```'''
    result = extract_code(plain_fence)
    assert "def modern_invoice_total" in result
    print("  ✓ fence with no language tag works")

    no_fence = '''def modern_invoice_total(quantity, unit_price_scaled):
    return quantity * unit_price_scaled'''
    result = extract_code(no_fence)
    assert "def modern_invoice_total" in result
    print("  ✓ no fence (model follows instructions) -> raw text unchanged")
    print()


def _fake_http_response(json_body, status=200):
    """Builds a mock object that behaves like urllib's response object
    (supports 'with ... as response' and .read())."""
    fake = mock.MagicMock()
    fake.read.return_value = json.dumps(json_body).encode("utf-8")
    fake.__enter__.return_value = fake
    fake.__exit__.return_value = False
    return fake


def test_call_anthropic_missing_key():
    print("=" * 78)
    print("A2. call_anthropic() without an API key")
    print("-" * 78)
    old = os.environ.pop("ANTHROPIC_API_KEY", None)
    try:
        try:
            call_anthropic("test prompt")
            assert False, "should have raised LLMCallError"
        except LLMCallError as e:
            print(f"  ✓ Clean error instead of a crash: {e}")
    finally:
        if old is not None:
            os.environ["ANTHROPIC_API_KEY"] = old
    print()


def test_call_anthropic_success_mocked():
    print("=" * 78)
    print("A3. call_anthropic() with a mocked successful response")
    print("-" * 78)
    fake_response = _fake_http_response({
        "content": [{"type": "text", "text": "def foo():\n    return 42"}]
    })
    with mock.patch("urllib.request.urlopen", return_value=fake_response):
        result = call_anthropic("test prompt", api_key="fake-key-for-test")
    assert "def foo" in result
    print(f"  ✓ Response correctly extracted: {result!r}")
    print()


def test_call_anthropic_http_error_mocked():
    print("=" * 78)
    print("A4. call_anthropic() with a mocked HTTP 429 (rate limit)")
    print("-" * 78)
    import urllib.error
    err = urllib.error.HTTPError(
        url="https://api.anthropic.com/v1/messages", code=429, msg="Too Many Requests",
        hdrs=None, fp=io.BytesIO(b'{"error": {"message": "rate limited"}}'),
    )
    with mock.patch("urllib.request.urlopen", side_effect=err):
        try:
            call_anthropic("test prompt", api_key="fake-key-for-test")
            assert False, "should have raised LLMCallError"
        except LLMCallError as e:
            print(f"  ✓ Rate limit cleanly surfaced as LLMCallError: {e}")
    print()


def test_run_patch_loop_survives_api_failure():
    print("=" * 78)
    print("A5. run_patch_loop() with an llm_fix_fn that raises a real exception")
    print("-" * 78)
    import z3
    from engine import PicField
    from patch_loop import run_patch_loop

    INVOICE_FIELD = PicField(total_digits=5, decimal_digits=2)

    def legacy_invoice_total(quantity, unit_price_scaled):
        total = quantity * unit_price_scaled
        return total

    legacy_invoice_total.field_types = {"return": INVOICE_FIELD}

    BROKEN_SOURCE = '''
def modern_invoice_total(quantity, unit_price_scaled):
    total = quantity * unit_price_scaled * -1
    return total
'''

    def failing_fix_fn(prompt, attempt):
        raise LLMCallError("simulated network failure")

    result = run_patch_loop(
        legacy_fn=legacy_invoice_total, initial_modern_source=BROKEN_SOURCE,
        function_name="modern_invoice_total", llm_fix_fn=failing_fix_fn,
        arg_type=z3.IntSort(), field_types={"return": INVOICE_FIELD},
        max_attempts=5,
    )
    assert result.success is False
    assert "API ERROR" in result.history[-1][1]
    assert result.final_source.strip() == BROKEN_SOURCE.strip()
    print(f"  ✓ Loop stopped cleanly: {result.history[-1][1]}")
    print(f"  ✓ final_source still holds the last CHECKED state (no crash, no data loss)")
    print()


if __name__ == "__main__":
    test_extract_code_variants()
    test_call_anthropic_missing_key()
    test_call_anthropic_success_mocked()
    test_call_anthropic_http_error_mocked()
    test_run_patch_loop_survives_api_failure()
    print("All adapter tests passed.")
