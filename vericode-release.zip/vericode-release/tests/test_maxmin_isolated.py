import z3
from engine import verify, PicField


def legacy_max3(a, b, c):
    return max(a, b, c)


legacy_max3.field_types = {"return": PicField(5, 0)}


def modern_correct(a, b, c):
    return max(a, b, c)


modern_correct.field_types = {"return": PicField(5, 0)}


def modern_buggy(a, b, c):
    return max(a, b)  # Bug: c is ignored


modern_buggy.field_types = {"return": PicField(5, 0)}


if __name__ == "__main__":
    res = verify(legacy_max3, modern_correct, arg_type=z3.IntSort())
    print("vs correct:", res.label.value)
    assert res.label.value == "PROVEN"

    res = verify(legacy_max3, modern_buggy, arg_type=z3.IntSort())
    print("vs buggy:", res.label.value)
    if res.counterexample:
        print("Counterexample:", {k: v.as_long() for k, v in res.counterexample.items()})
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("max/min work correctly.")
