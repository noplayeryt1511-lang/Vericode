"""
A real finding from the attempt to verify CBACT04C.cbl (an actual AWS
CardDemo program) as a complete program: PERFORM targeting a paragraph
with a NUMERIC prefix ('9910-DISPLAY-IO-STATUS', '1300-COMPUTE-INTEREST'
-- a VERY common COBOL naming convention, used throughout this real
program) was previously rejected outright because the regular
expression incorrectly required a LETTER at the start.
"""
import z3
from full_pipeline import build_legacy_fn_from_cobol
from engine import verify

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(3).
       01  WS-RESULT  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           PERFORM 9910-DOUBLE-IT.
           STOP RUN.
       9910-DOUBLE-IT.
           COMPUTE WS-RESULT = WS-A * 2.
"""

COBOL_SOURCE_BUGGY = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. X.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-A       PIC 9(3).
       01  WS-RESULT  PIC 9(3).
       PROCEDURE DIVISION.
       P.
           PERFORM 9910-DOUBLE-IT.
           STOP RUN.
       9910-DOUBLE-IT.
           COMPUTE WS-RESULT = WS-A * 3.
"""


def modern_correct(ws_a):
    return ws_a * 2


def modern_buggy(ws_a):
    return ws_a * 3


def run():
    print("=" * 78)
    print("TEST: PERFORM targeting a numerically-prefixed paragraph name (real finding, CBACT04C.cbl)")
    print("=" * 78)
    legacy_fn, source, field_types = build_legacy_fn_from_cobol(
        COBOL_SOURCE, "x", ["ws_a"], "ws_result")
    print(source)

    modern_correct.field_types = dict(legacy_fn.field_types)
    modern_buggy.field_types = dict(legacy_fn.field_types)

    res = verify(legacy_fn, modern_correct, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    res = verify(legacy_fn, modern_buggy, arg_type=z3.IntSort())
    print(f"vs. BUGGY (*3 instead of *2): {res.label.value}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> PERFORM targeting numerically-named paragraphs works end-to-end.")


if __name__ == "__main__":
    run()
    print("\nTest passed.")
