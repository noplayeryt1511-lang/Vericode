import z3
from engine import PicField
from patch_loop import convert_and_verify

WEIGHT_FIELD = PicField(total_digits=7, decimal_digits=2)
DISTANCE_FIELD = PicField(total_digits=5, decimal_digits=0)
COST_FIELD = PicField(total_digits=9, decimal_digits=2)


def legacy_shipping_cost(weight_kg_scaled, distance_km):
    base_rate_scaled = 250  # 2.50, COBOL VALUE constant
    if weight_kg_scaled <= 500:
        cost = base_rate_scaled * distance_km
    elif weight_kg_scaled <= 2000:
        cost = base_rate_scaled * distance_km * 3 // 2
    else:
        cost = base_rate_scaled * distance_km * 2
    return cost


legacy_shipping_cost.field_types = {
    "weight_kg_scaled": WEIGHT_FIELD, "distance_km": DISTANCE_FIELD, "return": COST_FIELD,
}

COBOL_SOURCE = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SHIPCOST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-WEIGHT-KG       PIC 9(5)V99.
       01  WS-DISTANCE-KM     PIC 9(5).
       01  WS-BASE-RATE       PIC 9(3)V99 VALUE 2.50.
       01  WS-SHIPPING-COST   PIC 9(7)V99.

       PROCEDURE DIVISION.
       CALCULATE-SHIPPING.
           IF WS-WEIGHT-KG <= 5.00
               COMPUTE WS-SHIPPING-COST =
                   WS-BASE-RATE * WS-DISTANCE-KM
           ELSE
               IF WS-WEIGHT-KG <= 20.00
                   COMPUTE WS-SHIPPING-COST =
                       WS-BASE-RATE * WS-DISTANCE-KM * 1.5
               ELSE
                   COMPUTE WS-SHIPPING-COST =
                       WS-BASE-RATE * WS-DISTANCE-KM * 2
               END-IF
           END-IF.
           STOP RUN.
"""


def mock_translate(prompt, attempt):
    """Simulates a CORRECT first attempt from the LLM (structural test --
    should yield PROVEN directly on the first verify())."""
    return '''
def shipping_cost(weight_kg_scaled, distance_km):
    base_rate_scaled = 250
    if weight_kg_scaled <= 500:
        cost = base_rate_scaled * distance_km
    elif weight_kg_scaled <= 2000:
        cost = base_rate_scaled * distance_km * 3 // 2
    else:
        cost = base_rate_scaled * distance_km * 2
    return cost
'''


if __name__ == "__main__":
    result = convert_and_verify(
        legacy_fn=legacy_shipping_cost, cobol_source=COBOL_SOURCE,
        function_name="shipping_cost", param_names=["weight_kg_scaled", "distance_km"],
        llm_fix_fn=mock_translate, arg_type=z3.IntSort(),
        field_types={"return": COST_FIELD},
    )
    print("Success:", result.success)
    print("Verify rounds:", result.attempts)
    print("Actual LLM calls:", result.repairs_used)
    for h in result.history:
        print(" ", h[0], h[1])
    assert result.success is True
    print("Structural test passed.")
