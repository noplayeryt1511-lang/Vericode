import linecache
import z3
from csharp_bridge import transpile_csharp_method, UnsupportedCSharpConstruct
from engine import verify, PicField

CSHARP_TRY_CATCH_SOURCE = """
public class X {
    public static int SafeDivide(int a, int b) {
        int result;
        try {
            result = a / b;
        } catch (DivideByZeroException e) {
            result = 0;
        }
        return result;
    }
}
"""

CSHARP_TRY_CATCH_BUGGY = """
public class X {
    public static int SafeDivide(int a, int b) {
        int result;
        try {
            result = a / b;
        } catch (DivideByZeroException e) {
            result = 1;
        }
        return result;
    }
}
"""


def legacy_safe_divide(a, b):
    if b == 0:
        result = 0
    else:
        result = a // b
    return result


def _load(src):
    py = transpile_csharp_method(src, "SafeDivide", param_names=["a", "b"])
    filename = f"<csharp:SafeDivide:{id(src)}>"
    linecache.cache[filename] = (len(py), None, py.splitlines(keepends=True), filename)
    ns = {}
    exec(compile(py, filename, "exec"), ns)
    return ns["SafeDivide"]


def test_try_catch_division_by_zero():
    print("=" * 78)
    print("TEST: C# try/catch -- division with zero protection (DivideByZeroException)")
    print("=" * 78)
    field = PicField(total_digits=9, decimal_digits=0)
    legacy_safe_divide.field_types = {"return": field}

    correct_fn = _load(CSHARP_TRY_CATCH_SOURCE)
    correct_fn.field_types = {"return": field}
    print(transpile_csharp_method(CSHARP_TRY_CATCH_SOURCE, "SafeDivide", param_names=["a", "b"]))

    res = verify(legacy_safe_divide, correct_fn, arg_type=z3.IntSort())
    print(f"vs. CORRECT: {res.label.value}")
    assert res.label.value == "PROVEN"

    buggy_fn = _load(CSHARP_TRY_CATCH_BUGGY)
    buggy_fn.field_types = {"return": field}
    res = verify(legacy_safe_divide, buggy_fn, arg_type=z3.IntSort())
    print(f"vs. BUGGY (fallback value 1 instead of 0): {res.label.value}")
    if res.counterexample:
        print(f"Counterexample: {res.counterexample}")
    assert res.label.value == "FLAGGED FOR MANUAL REVIEW"
    print("\n-> try/catch with zero protection works end-to-end -- parity with Java.")


if __name__ == "__main__":
    test_try_catch_division_by_zero()
    print("\nTest passed.")
