# VeriCode — Test File Overview

107 test files. Grouped by topic, roughly in the order they were created
(older core tests first, newer extensions after). For every new extension
the rule is: a dedicated test for the new capability AND a full regression
run over the entire existing suite.

**Known failing test:** `test_smt2_patch_loop.py::test_smt2_through_patch_loop`
expects `PatchLoopResult` to expose an `smt2` attribute, but `run_patch_loop()`
never wires the SMT-LIB2 export from the underlying `verify()` call through to
its result object — a genuine gap, not a translation artifact. Everything
else (106 files) passes under `pytest tests/`.

---

## 1. Core engine (Z3 equivalence proof, field semantics)

| File | Covers |
|---|---|
| `test_scenarios.py` | Basic scenario: the three result labels (PROVEN/FLAGGED/VERIFIED-BY-TESTING) on a simple interest-calculation example |
| `test_pic_fields.py` | PIC field widths, overflow truncation |
| `test_signed_fields.py` | Signed/unsigned fields |
| `test_case_study_tax.py` | Tax-bracket case study (COMPUTE with multiple conditions) |
| `test_case_study_fx.py` | Currency-conversion case study |
| `test_case_study_y2k.py` | Y2K case study (2- vs. 4-digit years) |
| `test_records.py` | Records (nested field groups) |
| `test_nested_records.py` | Multiply nested records |
| `test_pic_x.py` | PIC X (Z3 string theory) |
| `test_tables.py` | Tables (OCCURS), Z3 arrays |
| `test_table_of_records.py` | Tables of records (combined) |
| `test_nested_table_element.py` | Access to an element of a nested table |
| `test_index_bounds.py` | Table index bounds |
| `test_ifexp_charat.py` | Ternary expressions (z3.If), single-character access |
| `test_early_return_bug.py` | An early `return` inside `if` branches — a bug class that could have affected any earlier verification written in that style |
| `test_smt2_export.py` | SMT-LIB2 audit export |
| `test_smt2_patch_loop.py` / `test_smt2_in_patchloop.py` | SMT2 export interacting with the patch loop |

## 2. Verification fallback (when a full proof is not possible)

| File | Covers |
|---|---|
| `test_concolic.py` | Concolic search (branch negation) vs. random fuzzing on unbounded-while code |
| `test_fuzzing_limit.py` | Limits of the fuzzing fallback |
| `test_loop_summarization.py` | Early exploration of loop summarization (precursor to the `loop_induction.py` work) |

## 3. Automated migration + repair loop

| File | Covers |
|---|---|
| `test_convert_structural.py` | Automated migration, structural cases |
| `test_convert_table_limit.py` | Automated migration with table bounds |
| `test_convert_intermediate_gap.py` | Automated migration with intermediate-step gaps |
| `test_convert_record.py` | Automated migration of records |
| `test_patch_loop.py` | Patch loop: automated repair of a faulty LLM migration |
| `test_patch_loop_failure.py` | Patch loop when the repair does NOT succeed |
| `test_sandbox.py` | Isolated subprocess execution of LLM-generated code |
| `test_llm_adapter.py` | Real Anthropic API adapter |

## 4. COBOL extraction (DATA DIVISION)

| File | Covers |
|---|---|
| `test_cobol_extract_e2e.py` | End-to-end extraction |
| `test_cobol_extract_records.py` | Extraction of records |
| `test_copybook.py` | `COPY` nesting |
| `test_copybook_advanced.py` | `COPY ... REPLACING` |
| `test_redefines.py` | `REDEFINES` (read-only) |
| `test_occurs_depending_on.py` | `OCCURS ... DEPENDING ON` |

## 5. COBOL transpiler (PROCEDURE DIVISION) — later extensions

| File | Covers |
|---|---|
| `test_transpile_e2e.py` | Basic end-to-end transpilation |
| `test_transpile_expanded.py` | Expanded statement coverage |
| `test_transpile_perform.py` | `PERFORM` variants |
| `test_transpile_string.py` | `STRING` |
| `test_transpile_unstring.py` | `UNSTRING` |
| `test_full_pipeline_structural.py` | Full pipeline, structural cases |
| `test_continue_exit.py` | `CONTINUE`/`EXIT` |
| `test_inspect.py` | `INSPECT TALLYING`/`REPLACING` |
| `test_condition_name_if.py` | 88-level condition names in `IF`/`EVALUATE TRUE` |
| `test_maxmin_isolated.py` | `FUNCTION MAX`/`MIN` |
| `test_intrinsic_functions.py` | Intrinsic functions in general |
| `test_search.py` | `SEARCH` (linear table search) |
| `test_rounded.py` | `COMPUTE ... ROUNDED` |
| `test_rounded_bracketed.py` | `COMPUTE ... ROUNDED` extended — parenthesized numerator/denominator expressions, as long as division alone is the top-level operation |
| `test_is_numeric.py` | `IS [NOT] NUMERIC` (individual PicX fields) |
| `test_is_numeric_group.py` | `IS NUMERIC` on pure PicX **group fields** — a bug found and fixed during development |
| `test_move_multi_target.py` | Multi-target `MOVE` (`MOVE x TO a b`) |
| `test_set_index.py` | `SET <index> TO`/`UP BY`/`DOWN BY` (COBOL index assignment) |
| `test_length_literal.py` | `FUNCTION LENGTH` on string literals |
| `test_abbreviated_relops.py` | `IS` optional before `EQUAL TO`/etc.; also documents the counter-case for `EQ`/`NE`/etc. (blocked by `cobol-py` itself) |
| `test_nested_object.py` | Nested objects (Java) |
| `test_nested_object_csharp.py` | Nested objects (C#) |

## 6. Language bridges (Java, C#, Go, Rust)

| File | Covers |
|---|---|
| `test_java_bridge.py` | Java: if/elif/else, for, record, switch, ternary, while-counting loop, array, string |
| `test_java_try_catch.py` | Java: `try`/`catch` (narrowly scoped to divide-by-zero guards) |
| `test_csharp_try_catch.py` | C#: `try`/`catch`, same scope as Java |
| `test_csharp_bridge.py` | C#: same feature scope as Java |
| `test_go_bridge.py` | Go: same feature scope, plus Go's `for cond {}` idiom |
| `test_go_safe_divide.py` | Go: divide-by-zero guard — **no new code needed**, already works via existing if/return support |
| `test_rust_bridge.py` | Rust: same feature scope, plus Rust's `if`-as-expression (implicit return) |
| `test_rust_safe_divide.py` | Rust: divide-by-zero guard — **no new code needed**, already works via existing if-as-value support |

## 7. `loop_induction.py` — loops with a variable bound

| File | Covers |
|---|---|
| `test_loop_induction.py` | Simple accumulator loop (unconditional) |
| `test_loop_induction_conditional.py` | Conditional accumulation (`IF ... ADD ... END-IF`) |
| `test_loop_induction_nested.py` | Nested loops (outer variable, inner fixed) |
| `test_loop_induction_dual.py` | Two simultaneous state variables (sum + counter) |
| `test_loop_induction_auto.py` | Unified entry point that automatically detects the matching pattern out of the four |
| `test_loop_induction_file_accumulator.py` | File-processing loop pattern (`READ...AT END`), unconditional AND conditional — reuses the same induction machinery as `PERFORM VARYING` |
| `test_loop_induction_file_nested.py` | Nested file-processing loop pattern (table per record) — reuses `NestedAccumulatorLoopSpec` |
| `test_loop_induction_file_dual.py` | Two-state file-processing loop pattern (sum + counter) — all four file-loop variants now complete |
| `test_loop_induction_file_auto.py` | Unified dispatcher for file loops, analogous to `test_loop_induction_auto.py` for `PERFORM VARYING` |
| `test_unified_verification.py` | `full_pipeline.py`'s `verify_cobol_against_modern()` — automatically switches between the standard path and `loop_induction` |

## 8. External validation (seven real-world, third-party COBOL sources)

| File | Source | Construct |
|---|---|---|
| `test_real_world_payroll.py` | Brazilian payroll project | INSS tax bracket (`EVALUATE`) |
| `test_external_carddemo.py` | AWS CardDemo, `CBACT04C.cbl` | Interest calculation (arithmetic formula) |
| `test_external_carddemo_string.py` | AWS CardDemo, `CBACT04C.cbl` | Transaction-ID construction (`STRING`) — found two real bugs |
| `test_external_carddemo_update.py` | AWS CardDemo, `CBACT04C.cbl` | Balance update (`ADD`+`MOVE`) |
| `test_external_payroll_familyallowance.py` | Brazilian payroll project (second fragment) | Family allowance — found the scaling bug for mixed-scale multiplication |
| `test_external_carddemo_isnumeric.py` | AWS CardDemo, `CBACT04C.cbl` | `IS NOT NUMERIC`/`OR` — found the group-field issue |
| `test_external_accounting_debit.py` | `continuous-copilot/modernize-legacy-cobol-app` (third project) | Solvency check before a debit |
| `test_external_paycalc_overtime.py` | `kalsmic/learn_cobol` (fourth project) | Overtime pay calculation — found the most significant scaling bug (field × field multiplication) |
| `test_external_gpa_calculator.py` | `marvinjason/cobol` (fifth project) | GPA calculator — found missing `MULTIPLY`/`DIVIDE` short forms AND the same scaling bug again in `ADD` |
| `test_external_digit_extraction.py` | `DoHITB/COBOL-Examples` (sixth project) | Digit extraction — found missing `DIVIDE...GIVING...REMAINDER` support |
| `test_external_docalc.py` | `Apress/beg-cobol-for-programmers` (seventh project) | DoCalc — companion code to Coughlan's published COBOL textbook |
| `test_comparison_scale_fix.py` | Found proactively | Comparison scaling bug — third instance of the same bug class (multiplication, `ADD`, now comparisons) |
| `test_move_scale_fix.py` | Found proactively | `MOVE` scaling bug — fourth, likely most common instance of the same bug class |
| `test_evaluate_scale_fix.py` | Found proactively | `EVALUATE`-against-field scaling bug — fifth instance, its own comparison path (distinct from `IF`) |
| `test_open_close_noop.py` | Found during a full-program attempt on CBACT04C.cbl | `OPEN`/`CLOSE` as a no-op |
| `test_perform_numeric_paragraph.py` | Found during a full-program attempt on CBACT04C.cbl | `PERFORM` on paragraph names with a numeric prefix (`9910-...`) |
| `test_read_into_noop.py` | Third step toward hybrid mode | `READ ... INTO <parameter>` as a conditionally safe no-op |
| `test_write_noop.py` | Fourth step toward hybrid mode | `WRITE` as an unconditionally safe no-op |
| `test_rewrite_noop.py` | Fifth step toward hybrid mode | `REWRITE` as an unconditionally safe no-op (same case as `WRITE`) |
| `test_delete_noop.py` | Sixth step toward hybrid mode | `DELETE` as an unconditionally safe no-op |
| `test_start_noop.py` | Seventh and final step toward hybrid mode | `START` as an unconditionally safe no-op — all seven file I/O statement types now covered |
| `test_division_scale_fix.py` | Found proactively | Division scaling bug — a later instance, the implicit `DIVIDE` form (`SLASH`), a gap deliberately left open from the original multiplication finding |
| `test_subtract_scale_confirm.py` | Checked proactively | Confirmation (no new bug): `SUBTRACT` correctly shares the same fix as `ADD` |
| `test_table_element_scale_fix.py` | Found proactively | Table-element scaling bug — an instance that affected all nine previous fixes simultaneously (shared `_scale_lookup_key` helper) |
| `test_of_qualified_scale_fix.py` | Found proactively | OF-qualified field-reference scaling bug — same helper extended to cover dot notation |
| `test_table_of_records_scale_confirm.py` | Checked proactively | Confirmation (no new bug): table of records already works correctly |

---

## A pattern that proved valuable repeatedly

For every extension: a dedicated test for the control case (correct →
`PROVEN`) AND for a deliberately introduced, realistic bug (→
`FLAGGED FOR MANUAL REVIEW`, with a counterexample) — a control case
alone never proves that a mechanism actually CHECKS anything rather
than just passing through (see the lesson from `loop_induction.py`'s
conditional accumulation, where the first bug test case itself
contained an error that happened to cancel out at the boundary case).
