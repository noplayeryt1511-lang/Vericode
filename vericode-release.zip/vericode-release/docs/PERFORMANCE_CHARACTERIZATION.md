# VeriCode — Performance Characterization

**Question:** Where does Z3 proof time break down as program size grows?

**Method:** A synthetic but realistically structured COBOL program
(`EVALUATE TRUE` with N `WHEN` branches, each with a `COMPUTE`
assignment — structurally similar to a long tax bracket or fee table)
at increasing size, each proven against a correct Python reference.
Script: `benchmarks/perf_test.py`.

**An important methodological finding along the way:** the first
version of the test used a Python closure variable as the loop bound in
the comparison code — this was incorrectly rejected as "not symbolically
provable" (falling back to `VERIFIED-BY-TESTING`), because the engine
reads loop bounds from the ACTUAL source text (`inspect.getsource`),
not from runtime closures — a sensible, documented limitation, but one
that only became apparent through careful checking, not simply by
reading off the result numbers. After correcting this (real source text
with the number embedded literally instead of a closure), all sizes
correctly went through the symbolic PROVEN path.

## Results

| Branches (WHEN clauses) | ~COBOL lines | Z3 proof time | Result |
|---|---|---|---|
| 5 | ~20 | 0.03 s | PROVEN |
| 10 | ~30 | 0.07 s | PROVEN |
| 20 | ~50 | 0.56 s | PROVEN |
| 40 | ~90 | 0.78 s | PROVEN |
| 80 | ~170 | 0.98 s | PROVEN |
| 160 | ~330 | 3.51 s | PROVEN |
| 320 | ~650 | 6.73 s | PROVEN |
| 640 | ~1,290 | 25.82 s | PROVEN |
| 1,280 | ~2,570 | **> 280 s (no result)** | — |

## Interpretation

- Up to ~160 branches (~330 lines): proof time in the low single-digit
  seconds, entirely practical for interactive use.
- Between 320 and 640 branches: already noticeably super-linear growth
  (doubling the size almost quadruples the time) — a sign of at least
  quadratic, possibly worse, scaling in the number of branches.
- **Between 640 and 1,280 branches the proof effectively breaks down
  entirely** — more than ten times the time for double the size,
  without producing a result within 280 seconds.

**This is clearly below the eventual target of 10,000+ lines** that a
larger-scale rollout would require — for the program structure tested
here (deliberately "worst-case-like", since it is purely
branch-heavy), the practical limit sits at a few thousand lines, not
ten thousand. This is an honest, important limitation, not something
to gloss over — exactly the kind of finding this kind of
characterization work is meant to surface.

## Important caveat on this measurement

These numbers apply to ONE specific program structure (a flat chain of
branches). Other structures (e.g. many independent, short paragraphs
instead of one long branch chain) could behave differently — Z3's
runtime behavior depends strongly on the exact shape of the formula,
not just on the raw line count. This measurement is an initial, honest
data point, not an exhaustive characterization.

## Sensible next steps

- Repeat the same measurement with other program structures (many
  `PERFORM`s of different paragraphs, deeply nested records, large
  tables) to see whether the branch-chain structure is the special case
  or the general pattern.
- Systematically vary Z3's own solver parameters (timeout, tactics) to
  see whether a different solver configuration shifts the limit.
- ~~Investigate whether simplifying the generated Z3 formula itself
  (the current output visibly contains a lot of redundant `And(True,
  Not(False))` noise from the has_returned tracking) meaningfully
  improves runtime, before tuning solver configuration.~~
  **TRIED, NO GAIN:** `z3.simplify()` was added at the two obvious
  places (`cond` combination, `has_returned`/`returned` update on every
  `return`) and measured against the same benchmark series. Result: no
  clear benefit, and at 640 branches even slightly slower (46.5 s
  instead of 25.8 s) — likely because Z3 already performs its own,
  more efficient internal simplification, and the additional
  Python-side `simplify()` calls only add overhead without benefit.
  Cleanly reverted (no unproven change left in the most central code
  path of the whole engine). **This suggests the actual bottleneck
  likely sits deeper in the Z3 solving process itself** (the
  combinatorial structure of the formula, not its raw tree size) — an
  indication that a real fix would more likely be found in solver
  tactics/parameters than in formula construction, which would be worth
  pursuing in future work.
