# VeriCode — Formal Documentation of Verification Guarantees

**Purpose of this document:** a precise, honest answer to the question
"what does PROVEN actually mean, and what is that confidence based on?"
— written for someone who should not simply take the result on faith,
but needs to be able to follow and independently check it (e.g. an
auditor or an internal review/compliance function).

---

## 1. What "PROVEN" actually means, mathematically

Given two functions — a reference function `legacy_fn` automatically
derived from COBOL, and a target function `modern_fn` to be checked —
VeriCode constructs a logical formula:

```
∃ x. legacy_fn(x) ≠ modern_fn(x)
```

("There exists an input `x` for which the two functions differ.") This
formula is handed to the Z3 SMT solver.

- **If Z3 answers UNSAT** ("unsatisfiable"), this means: **no** input
  `x` exists for which the functions differ. This is the case VeriCode
  reports as **PROVEN**.
- Important: this is **not** "we tested many inputs and found no
  difference" — Z3 proves the absence of a counterexample over the
  **entire** input space, mathematically exactly, not by sampling.
- **If Z3 answers SAT** ("satisfiable"), Z3 returns a **concrete
  model** — an actual input for which the results differ. This is the
  case VeriCode reports as **FLAGGED FOR MANUAL REVIEW**, together with
  the counterexample.

The SMT-LIB2 export (`export_smt2=True`) makes this exact formula
**independently re-checkable** — any other SMT solver (not just Z3) can
check the same formula and must arrive at the same result, provided the
formula was constructed correctly. This is the core reason "PROVEN" is
a load-bearing word here, not a marketing claim.

---

## 2. What is NOT proven (the limits that actually matter)

**PROVEN does NOT prove that the COBOL reference function was correctly
derived from the COBOL source.** The transpiler (`cobol_transpile.py`)
is itself unverified Python code — it is not verified by Z3, but is
instead validated through testing (72+ dedicated test cases, nine
external real-world COBOL sources, a full NIST-85 sample run). A bug in
the transpiler itself (such as the scaling-bug class described below,
found and fixed during development) would, before the fix, have led to
an **incorrect result that was nonetheless reported as "PROVEN"** — not
because the proof itself was mathematically wrong, but because the
REFERENCE itself was wrong. **PROVEN proves equivalence to the
reference, not correctness of the reference itself.**

**PROVEN only proves equivalence over the declared field model**, not
over arbitrary bit patterns. VeriCode models COBOL numeric fields as
scaled integers with a defined width (the `PIC` clause), including
overflow truncation. If the actual runtime environment (compiler, byte
order, packed-decimal formats) deviates from this model, the proof
holds for the MODEL, not necessarily for every bit of the real
execution.

**PROVEN only holds for the part of the program that was proven**, not
for the whole program. File I/O, `CALL`/`CANCEL` of external
subprograms, `GO TO` jumps, and several other COBOL constructs are
deliberately, categorically rejected (see section 4) — a program that
contains such constructs can currently only be partially proven (the
pure computation logic), not proven as a whole.

---

## 3. The three result levels in detail

| Label | Meaning | Reliability |
|---|---|---|
| `PROVEN` | Z3 proved UNSAT for the negation of equivalence | Mathematically exact over the entire declared input space, independently re-checkable via the SMT2 export |
| `FLAGGED FOR MANUAL REVIEW` | Z3 found a concrete counterexample (SAT) | The counterexample itself is exact and reproducible — the two functions REALLY differ at this input value |
| `VERIFIED-BY-TESTING` | Code contains constructs outside the symbolically provable range (e.g. unbounded loops) → falls back to differential fuzzing (concolic search or random sampling) | **Weaker than PROVEN** — a finite number of concrete test cases, NOT a proof over the entire input space. Should NEVER be mistaken for PROVEN |

**Important note:** `VERIFIED-BY-TESTING` is the only one of the three
levels that provides NO formal guarantee — it is deliberately named
this way to set it apart from the other two, but it is the user's
responsibility to take this difference seriously and not treat it as
"just as good as PROVEN".

---

## 4. Precise scope (what is actually checked)

**Supported** (see `TEST_OVERVIEW.md` for the full, test-backed list):
arithmetic COBOL computation logic including `COMPUTE`,
`ADD`/`SUBTRACT`/`MULTIPLY`/`DIVIDE`, conditional branching
(`IF`/`EVALUATE`), counting loops with constant OR (via
`loop_induction.py`) specific patterns of data-dependent bounds,
records, tables, `STRING`/`UNSTRING`, `INSPECT`, `SEARCH`, and five
target languages for comparison (Python, Java, C#, Go, Rust).

**Partially supported (hybrid mode):** all seven file I/O statement
types (`OPEN`, `CLOSE`, `READ`, `WRITE`, `REWRITE`, `DELETE`, `START`)
are covered as (conditionally) safe no-ops — `READ ... INTO <target>`
only when `<target>` is already a function parameter (in which case its
symbolic value is already free/unconstrained, which is exactly what a
real `READ` means); the other six unconditionally, since they never
write back into a tracked field. **Important limitation:** our model
does NOT represent `INVALID KEY`/`AT END`/error conditions — a `READ`
is always treated as successful in our model. This covers the PURE
computation logic of a program, not its complete file-processing
behavior.

**Categorically excluded** (leads to a clear rejection, never to a
silently wrong result): `CALL`/`CANCEL` of external subprograms,
`GO TO`, `SORT`/`MERGE`, CICS/DB2 interactions, interactive screen
I/O.

**Confirmed empirically, over a full NIST COBOL85 test run** (459
files, 26 minutes, not a single unexpected crash): the dominant reason
for rejection is file I/O (`OpenStatement`, 126/459 files, 27%) — the
majority of a compiler-conformance suite tests areas outside the
current scope. This is an honest, important observation: real-world
COBOL programs (not just the conformance suite) typically also involve
substantial file/database access — the current approach covers the
PURE computation logic, not necessarily a complete production program.

---

## 5. Known, still-open limitations

- **Scaling-bug class**: currently checked across seven statement types
  (multiplication, `ADD`/`SUBTRACT`, comparisons, `MOVE`, `EVALUATE`,
  `SEARCH`, `PERFORM ... UNTIL`) — five had the bug and were fixed, two
  were already safe. There is no guarantee this covers ALL conceivable
  cases; the search was thorough, but not formally complete.
- **`COMPUTE ... ROUNDED`** now covers division with arbitrarily
  complex, parenthesized numerator/denominator expressions
  (`(A + B) / C`), as long as division is the ONLY top-level operation
  — parenthesis-aware parsing now recognizes this correctly (previously
  ANY additional parenthesis blocked it). Real expressions with
  MULTIPLE top-level operators (`A / B + C`) as well as **chains of
  multiplications** (more than two factors) are deliberately not yet
  fully scale-correct — full scale tracking through an arbitrary
  expression tree remains open.
- **`loop_induction.py`** covers four (plus three file-processing
  variants, seven total) specific accumulator patterns, not a general
  derivation from an arbitrary loop body.
- **No performance characterization at large scale** (see
  `PERFORMANCE_CHARACTERIZATION.md`) — how Z3 proof time behaves for
  programs of several thousand lines has empirically been measured for
  one synthetic worst-case structure, but not for arbitrary real-world
  program shapes.

---

## 6. Summary in one sentence

**"PROVEN" is an exact, independently re-checkable mathematical result
over a precisely defined but deliberately limited field/language model
— it proves equivalence between the reference and the target code, not
the correctness of the reference itself, and it holds only for the part
of a program that lies within the documented scope.**
